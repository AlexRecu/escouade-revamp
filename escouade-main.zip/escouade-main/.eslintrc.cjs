module.exports = {
  env: {
    browser: true,
    es2020: true,
    node: true,
  },
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:react-hooks/recommended',
    'plugin:react/recommended',
  ],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    ecmaFeatures: {
      jsx: true,
    },
    project: './tsconfig.json',
  },
  plugins: [
    'react',
    'react-refresh',
    'import',
    '@typescript-eslint',
  ],
  settings: {
    react: {
      version: 'detect',
    },
  },
  rules: {
    '@typescript-eslint/explicit-function-return-type': 'error',
    '@typescript-eslint/no-explicit-any': 'error',
    'react/jsx-filename-extension': [1, { 'extensions': ['.tsx'] }],
    'import/order': ['error', {
      'groups': ['builtin', 'external', 'parent', 'sibling', 'index'],
      'newlines-between': 'always',
    }],
    'no-console': 'error',
    'eqeqeq': ['error', 'always'],
    'react/react-in-jsx-scope': 'off',
    'quotes': ['error', 'single'],
    'semi': ['error', 'always'],
    'curly': ['error', 'all'],
    'no-unused-vars': 'error',
    'no-var': 'error',
    'prefer-const': 'error',
    'no-const-assign': 'error',
    'prefer-arrow-callback': 'error',
    '@typescript-eslint/no-unused-vars': 'error',
    'react-hooks/exhaustive-deps': 'error',
    'react/jsx-key': 'error',
    '@typescript-eslint/member-delimiter-style': ['error', {
      multiline: {
        delimiter: 'semi',
        requireLast: true
      },
      singleline: {
        delimiter: 'semi',
        requireLast: false
      }
    }],
    '@typescript-eslint/type-annotation-spacing': 'error',
    'object-curly-spacing': ['error', 'always'],
    'complexity': ['error', 10],
    'max-len': ['error', { 'code': 120 }],
    'no-param-reassign': 'error',
    'react/jsx-props-no-spreading': 'error',
    'react/jsx-no-duplicate-props': 'error',
    'import/no-anonymous-default-export': 'error',
    'require-jsdoc': 'error',
    'react-hooks/rules-of-hooks': 'error',
    '@typescript-eslint/naming-convention': [
      'error',
      {
        'selector': 'variableLike',
        'format': ['camelCase']
      },
      {
        'selector': 'typeLike',
        'format': ['PascalCase']
      },
      {
        'selector': 'function',
        'format': ['PascalCase', 'camelCase'],
        'custom': {
          'regex': '^([A-Z][a-zA-Z0-9]*)|([a-z][a-zA-Z0-9]*)$',
          'match': true
        }
      },
      {
        'selector': 'variable',
        'types': ['function'],
        'format': ['camelCase', 'PascalCase']
      },
      {
        'selector': 'parameter',
        'format': ['camelCase'],
        'leadingUnderscore': 'allow'
      }
    ],
    '@typescript-eslint/no-unnecessary-condition': 'error',
    '@typescript-eslint/consistent-type-imports': 'error',
    'react/jsx-no-constructed-context-values': 'error',
    '@typescript-eslint/no-floating-promises': 'error',
    'no-implicit-coercion': 'error',
    'padding-line-between-statements': [
      'error',
      { blankLine: 'always', prev: '*', next: 'return' },
    ],
    'import/no-extraneous-dependencies': 'error',
    'prefer-destructuring': ['error', { object: true, array: false }],
    'arrow-body-style': ['error', 'as-needed'],
    'prefer-template': 'error'
  },
};