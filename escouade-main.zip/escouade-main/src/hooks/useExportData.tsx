import { useCallback } from 'react';
import { useGameInfo } from '@contexts/GameInfoContext';
import { useInventory } from '@contexts/ItemContext';
import { useCharacters } from '@contexts/CharacterContext';
import { useBattle } from '@contexts/BattleContext';

/**
 * Custom hook for exporting game data.
 * 
 * @returns {Function} A function to trigger the export of game data.
 */
export function useExportData(): () => void {
  const { gameInfo } = useGameInfo();
  const { inventory } = useInventory();
  const { characters } = useCharacters();
  const { tokenPositions, currentTurn } = useBattle();

  const handleExport = useCallback((): void => {
    const dataToExport = {
      inventory: Array.from(inventory),
      characters,
      gameInfo,
      battle: {
        tokenPositions,
        currentTurn
      }
    };

    const dataStr = JSON.stringify(dataToExport);
    const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
    const exportFileDefaultName = 'gameData.json';

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    document.body.appendChild(linkElement);
    linkElement.click();
    document.body.removeChild(linkElement);
  }, [inventory, characters, gameInfo, tokenPositions, currentTurn]);

  return handleExport;
}