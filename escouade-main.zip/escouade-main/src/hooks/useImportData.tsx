import { useCallback } from 'react';
import { useGameInfo } from '@contexts/GameInfoContext';
import { useInventory } from '@contexts/ItemContext';
import { useCharacters } from '@contexts/CharacterContext';
import { useBattle } from '@contexts/BattleContext';

/**
 * Custom hook for importing game data.
 * 
 * @returns {Function} A function to handle the import of game data from a file input.
 */
export function useImportData(): (e: React.ChangeEvent<HTMLInputElement>) => void {
  const { setGameInfoFromImport } = useGameInfo();
  const { setInventoryFromImport } = useInventory();
  const { setCharactersFromImport } = useCharacters();
  const { updateBattleDataInFirestore } = useBattle();

  const handleImport = useCallback((e: React.ChangeEvent<HTMLInputElement>): void => {
    if (e.target.files) {
      const file = e.target.files[0];
      const reader = new FileReader();

      reader.onload = (e): void => {
        const contents = e.target?.result;
        if (typeof contents === 'string') {
          const importedData = JSON.parse(contents);
          setGameInfoFromImport(importedData.gameInfo || {});
          setCharactersFromImport(importedData.characters || []);
          setInventoryFromImport(new Map(importedData.inventory));
          void updateBattleDataInFirestore(
            { ...importedData.battle.tokenPositions }, importedData.battle.currentTurn, importedData.battle.turnOrder
          );
          localStorage.setItem('gameData', JSON.stringify(importedData));
        }
      };
      reader.readAsText(file);
    }
  }, [setGameInfoFromImport, setCharactersFromImport, setInventoryFromImport, updateBattleDataInFirestore]);

  return handleImport;
}