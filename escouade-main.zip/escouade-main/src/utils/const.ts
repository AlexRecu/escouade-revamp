export const superAdminIds = ['0DqliilKzISPDp47w01SjePonhQ2', 'vx2EHD3E7ZPUv0Ka6aaI1tyWv9n2'];

export const classesOptions = [
  { label: 'Mage Bleu', value: 'mageBleu' },
  { label: 'Mage Rouge', value: 'mageRouge' },
  { label: 'Mage Blanc', value: 'mageBlanc' },
  { label: 'Mage Noir', value: 'mageNoir' },
  { label: 'Voleur', value: 'voleur' },
];

export const statLabels = {
  'strength': 'Force',
  'dexterity': 'Dextérité',
  'endurance': 'Endurance',
  'mana': 'Mana',
  'intelligence': 'Intelligence',
  'perception': 'Perception',
  'charisma': 'Charisme'
};

export const listType = [
  'Arme',
  'Consommable',
];

export const trashTalkComments: string[] = [
  '{characterName}, un échec critique ? Bravo, tu réussis à être aussi incompétent dans le jeu que dans la vie réelle.',
  '{characterName}, je suis impressionné, vraiment. \
  Qui aurait pensé qu\'on pouvait être aussi mauvais même avec un coup de dés ?'
];