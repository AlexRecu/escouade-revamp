import type { TokenPosition, TokenPositions } from '@interfaces/interfaces';
import type { Creature } from '@interfaces/interfaces';
import bestiaryData from '@data/bestiary_data.json';
import type { Zones } from '@interfaces/types';

/**
 * Generates an array of random creatures from a specific zone with a specified number of creatures.
 *
 * @param {Zones} zone - The zone from which to randomly select creatures.
 * @param {number} numberOfCreatures - The desired number of random creatures to generate.
 * @returns {Creature[]} An array of random Creature objects from the specified zone.
 */
export function getRandomCreatures(
  zone: Zones, numberOfCreatures: number
): Creature[] {
  const creaturesInZone: Creature[] = bestiaryData.filter((creature) => creature.spawn_rates[zone] > 0);

  const weightedCreatures: { creature: Creature; weight: number }[] =
    creaturesInZone.map((creature) => ({ creature, weight: creature.spawn_rates[zone] }));

  const randomCreatures = [];

  while (randomCreatures.length < numberOfCreatures) {
    const totalWeight = weightedCreatures.reduce((acc, cur) => acc + cur.weight, 0);
    let randomValue = Math.random() * totalWeight;

    let chosenCreature = null;

    for (const weightedCreature of weightedCreatures) {
      if (randomValue < weightedCreature.weight) {
        chosenCreature = weightedCreature.creature;
        break;
      }
      randomValue -= weightedCreature.weight;
    }

    if (chosenCreature) {
      randomCreatures.push(chosenCreature);
    }
  }

  return randomCreatures;
}

/**
 * Calculates the Euclidean distance between two token positions.
 * @param {TokenPosition} pos1 The first position.
 * @param {TokenPosition} pos2 The second position.
 * @returns {number} The Euclidean distance between the two positions.
 */
export const distance = (pos1: TokenPosition, pos2: TokenPosition): number =>
  Math.trunc(Math.sqrt(Math.pow(pos1.row - pos2.row, 2) + Math.pow(pos1.col - pos2.col, 2)));

/**
 * Checks if two token positions are adjacent.
 * @param {TokenPosition} pos1 The first position.
 * @param {TokenPosition} pos2 The second position.
 * @returns {boolean} true if positions are adjacent, otherwise false.
 */
export const isAdjacent = (pos1: TokenPosition, pos2: TokenPosition): boolean =>
  Math.abs(pos1.row - pos2.row) <= 1 && Math.abs(pos1.col - pos2.col) <= 1;

/**
 * Checks if a position is occupied by a token.
 * @param {TokenPosition} position The position to check.
 * @param {TokenPositions} tokenPositions The positions of existing tokens.
 * @returns {boolean} true if the position is occupied, otherwise false.
 */
export const isOccupied = (position: TokenPosition, tokenPositions: TokenPositions): boolean =>
  Object.values(tokenPositions).some(pos => pos.row === position.row && pos.col === position.col);

/**
 * Gets the accessible neighboring cells from a given position on the grid.
 * 
 * This function calculates adjacent positions (up, down, left, right) from the given position
 * and checks if these positions are within the grid boundaries and are not occupied by other tokens.
 * 
 * @param {TokenPosition} position - The current position from which to find neighbors.
 * @param {TokenPositions} tokenPositions - The positions of all tokens on the grid.
 * @returns {TokenPosition[]} An array of accessible neighboring positions.
 */
export function getAccessibleNeighbors(
  position: TokenPosition,
  tokenPositions: TokenPositions
): TokenPosition[] {
  const directions: [number, number][] = [
    [1, 0], [0, 1], [-1, 0], [0, -1],
    [1, 1], [-1, 1], [1, -1], [-1, -1]
  ];

  const neighbors: TokenPosition[] = [];

  for (const [dx, dy] of directions) {
    const newRow = position.row + dx;
    const newCol = position.col + dy;

    if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8
      && !isOccupied({ row: newRow, col: newCol }, tokenPositions)) {
      neighbors.push({ row: newRow, col: newCol });
    }
  }

  return neighbors;
}

/**
 * Determines if a position is adjacent (including diagonally) to a target position.
 * 
 * @param {TokenPosition} position - The position to check for adjacency.
 * @param {TokenPosition} goal - The target position to compare against.
 * @returns {boolean} True if the position is adjacent to the goal, false otherwise.
 */
export function isAdjacentToGoal(position: TokenPosition, goal: TokenPosition): boolean {
  return Math.abs(position.row - goal.row) <= 1 && Math.abs(position.col - goal.col) <= 1;
}

/**
 * Finds the shortest path from a start position to a position adjacent to the goal, 
 * considering the positions of other tokens on the grid.
 * 
 * @param {TokenPosition} start - The starting position of the path search.
 * @param {TokenPosition} goal - The target position near which a path is sought.
 * @param {TokenPositions} tokenPositions - The positions of all tokens on the grid,
 *                                          used to avoid paths that would collide with other tokens.
 * @returns {TokenPosition[]} An array of positions representing the shortest path
 *                            to a position adjacent to the goal. If no path is found,
 *                            returns an empty array.
 */
export function findShortestPath(
  start: TokenPosition,
  goal: TokenPosition,
  tokenPositions: TokenPositions
): TokenPosition[] {
  // Typage explicite de la queue
  const queue: [TokenPosition, TokenPosition[]][] = [[start, []]];
  const visited = new Set<string>();

  while (queue.length > 0) {
    const [current, path] = queue.shift()!;
    const positionKey = `${current.row}-${current.col}`;

    if (isAdjacentToGoal(current, goal)) {
      return path;
    }

    if (!visited.has(positionKey)) {
      visited.add(positionKey);

      const neighbors = getAccessibleNeighbors(current, tokenPositions);
      for (const neighbor of neighbors) {
        const nextPath = path.concat([neighbor]);
        queue.push([neighbor, nextPath]);
      }
    }
  }

  return [];
}