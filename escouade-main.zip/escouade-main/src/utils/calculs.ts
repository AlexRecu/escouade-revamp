import type { Character, Spell } from '@interfaces/interfaces';
import levelsData from '@data/level_data.json';

/**
 * Calculates the maximum health and mana based on character stats.
 * @param {Character['stats']} stats - The character's statistics.
 * @returns {{ maxHealth: number; maxMana: number }} An object containing the calculated maxHealth and maxMana.
 */
export function calculateMaxHealthAndMana(stats: Character['stats']): { maxHealth: number; maxMana: number } {
  const maxHealth = 10 + stats['endurance'];
  const maxMana = 10 + stats['mana'];

  return { maxHealth, maxMana };
}

/**
 * Calculates the experience points required to reach the next level.
 * @param {number} level - The current character level.
 * @returns {number} The experience points needed to reach the next level.
 */
export function calculateXpToNextLevel(level: number): number {
  const currentLevelData = levelsData.find(lvl => lvl.level === level);

  return currentLevelData ? currentLevelData.xp : 0;
}

/**
 * Calculates the new level and total experience points after adding XP to the character.
 * @param {number} currentXp - The current character's experience points.
 * @param {number} xpToAdd - The experience points to be added.
 * @param {number} level - The current character level.
 * @param {number} maxLevel - The maximum character level.
 * @returns {{ newLevel: number; newTotalXp: number; levelIncreased: boolean }} 
 * An object containing the new level, new total experience points, and whether the level increased.
 */
export function calculateNewXpAndLevel(currentXp: number, xpToAdd: number, level: number, maxLevel: number): {
  newLevel: number;
  newTotalXp: number;
  levelIncreased: boolean;
} {
  let newTotalXp = currentXp + xpToAdd;
  let newLevel = level;
  let levelIncreased = false;

  while (newTotalXp >= calculateXpToNextLevel(newLevel) && newLevel < maxLevel) {
    newTotalXp -= calculateXpToNextLevel(newLevel);
    newLevel += 1;
    levelIncreased = true;
  }

  return { newLevel, newTotalXp, levelIncreased };
}

/**
 * Calculates the cost of casting a spell for a given character.
 * @param {Spell} spell - The spell object to calculate the cost for.
 * @param {Character} character - The character casting the spell.
 * @returns {boolean} - Returns true if the character can afford 
 * to cast the spell or has sufficient health to cast it, otherwise false.
 */
export function costCalculation(spell: Spell, character: Character): boolean {
  if (spell.cost && (character.currentMana >= spell.cost)) {
    return true;
  }
  if (character.currentHealth > 1) {
    return true;
  }

  return false;
}