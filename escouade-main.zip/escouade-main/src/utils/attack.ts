/* eslint-disable complexity */
import attackData from '@data/attack_data.json';
import bestiaryData from '@data/bestiary_data.json';
import type { Character, Creature, TokenPosition, TokenPositions } from '@interfaces/interfaces';
import type { PerformAttackFunction } from '@interfaces/types';

import { distance, isAdjacent } from './battle';
import { trashTalkComments } from './const';

/**
 */
export function calculateDamageMultiplier(element: string, monster: Creature): number {
  if (monster.immunity.includes(element)) {
    return 0;
  } else if (monster.resistance.includes(element)) {
    return 0.5;
  } else if (monster.weakness.includes(element)) {
    return 2;
  }

  return 1;
}

/**
 * Selects a random trash talk comment and replaces '{characterName}' with the specified character name.
 * @param characterName The name of the character.
 * @returns A randomly selected trash talk comment with '{characterName}' replaced by the character name.
 */
export function selectRandomTrashTalk(characterName: string): string {
  // Select a random index
  const randomIndex: number = Math.floor(Math.random() * trashTalkComments.length);
  // Get the selected comment and replace '{characterName}' with the specified character name
  const selectedComment: string = trashTalkComments[randomIndex].replace('{characterName}', characterName);

  return selectedComment;
}

/**
 */
export function deathMessage(attackName: string, characterName: string): string {
  const filteredAttackDeathMessage = attackData.filter(item => item.attack === attackName);

  return `${characterName} ${filteredAttackDeathMessage[0].deathMessage}`;
}

/**
 */
export function generateNewCreature(
  creatureName: string, tokenPositions: TokenPositions, zoneLevel: number): TokenPosition | null {
  const creatureData = bestiaryData.find(creature => creature.name === creatureName);

  const occupiedPositions = new Set<string>();

  for (const token of Object.values(tokenPositions)) {
    const positionKey = `${token.row}-${token.col}`;
    occupiedPositions.add(positionKey);
  }

  const availablePositions = [];

  for (let row = 2; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const positionKey = `${row}-${col}`;

      if (!occupiedPositions.has(positionKey)) {
        availablePositions.push(positionKey);
      }
    }
  }

  if (availablePositions.length === 0) {
    return null;
  }

  const randomPositionKey = availablePositions[Math.floor(Math.random() * availablePositions.length)];

  const creatureHealth = creatureData?.pv[zoneLevel];

  return {
    row: parseInt(randomPositionKey.split('-')[0], 10),
    col: parseInt(randomPositionKey.split('-')[1], 10),
    creatureName: creatureData?.name,
    currentHealth: creatureHealth,
    maxHealth: creatureHealth,
    status: [],
    isDead: false,
    hasAttacked: false,
    hasMoved: false,
    turnPass: false
  };
}

/**
 */
export function commonAttack(
  enemy: Creature,
  enemyPosition: TokenPosition,
  updatedPositions: Record<string, TokenPosition>,
  nearestCharacterId: string,
  performEnemyAttack: PerformAttackFunction
): void {
  const enemyAttack = enemy.attack[0];
  if (isAdjacent(enemyPosition, updatedPositions[nearestCharacterId])) {
    const attack = attackData.find(enemy => enemy.attack === enemyAttack);
    if (attack) {
      performEnemyAttack(
        enemy,
        nearestCharacterId,
        enemyAttack,
        attack.status ? { status: { name: attack.status, chance: attack.chance } } : undefined
      );
    }
  }
}

/**
 */
export function attackGobelin(
  enemy: Creature,
  enemyPosition: TokenPosition,
  updatedPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let closestCharacterId: string | null = null;
  let closestDistance: number = Infinity;

  for (const [characterId, characterPos] of Object.entries(updatedPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        closestDistance = distance(characterPos, enemyPosition);
        closestCharacterId = characterId;
      }
    }
  }

  if (closestCharacterId && closestDistance <= 7) {
    performEnemyAttack(enemy, closestCharacterId, enemy.attack[0]);
  }
}

/**
 */
export function attackVautour(
  vulture: Creature,
  vulturePosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): TokenPosition | null {
  let furthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, vulturePosition);
        if (dist <= 4 && dist > maxDistance) {
          maxDistance = dist;
          furthestCharacterId = characterId;
        }
      }
    }
  }

  if (furthestCharacterId) {
    const furthestCharacterPosition = tokenPositions[furthestCharacterId];

    if (isAdjacent(vulturePosition, furthestCharacterPosition)) {
      performEnemyAttack(vulture, furthestCharacterId, vulture.attack[0]);

      return null;
    }

    let minDistanceToVulture = Infinity;
    let closestAdjacentPos: TokenPosition | null = null;

    for (let row = furthestCharacterPosition.row - 1; row <= furthestCharacterPosition.row + 1; row++) {
      for (let col = furthestCharacterPosition.col - 1; col <= furthestCharacterPosition.col + 1; col++) {
        if ((row !== furthestCharacterPosition.row || col !== furthestCharacterPosition.col) &&
          row >= 0 && row < 8 && col >= 0 && col < 8) {
          const distanceToVulture = distance({ row, col }, vulturePosition);
          if (distanceToVulture < minDistanceToVulture) {
            minDistanceToVulture = distanceToVulture;
            closestAdjacentPos = { row, col, hasMoved: true, turnPass: false };
          }
        }
      }
    }

    if (closestAdjacentPos) {
      performEnemyAttack(vulture, furthestCharacterId, vulture.attack[0]);

      return closestAdjacentPos;
    }
  }

  return null;
}

/**
 * 
 */
export function attackOursElastique(
  ours: Creature,
  oursPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let closestCharacterId: string | null = null;
  let closestDistance: number = Infinity;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, oursPosition);
        if (dist < closestDistance) {
          closestDistance = dist;
          closestCharacterId = characterId;
        }
      }
    }
  }

  if (closestCharacterId && closestDistance === 1) {
    performEnemyAttack(ours, closestCharacterId, ours.attack[1]);
  }

  else if (closestCharacterId && closestDistance <= 3) {
    performEnemyAttack(ours, closestCharacterId, ours.attack[0]);
  }
}

/**
 * 
 */
export function attackBombo(
  bombo: Creature,
  bomboPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  if (bomboPosition.currentHealth &&
    bomboPosition.maxHealth &&
    bomboPosition.currentHealth <
    bomboPosition.maxHealth / 3) {
    for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
      if (!characterId.startsWith('enemy')) {
        const character = characters.find(c => c.id === characterId);
        if (character && !character.isDead && distance(characterPos, bomboPosition) <= 2) {
          performEnemyAttack(
            bombo, characterId,
            bombo.attack[1],
            { damage: bomboPosition.currentHealth, enemyId: bomboPosition.id });
        }
      }
    }
  } else {
    let furthestCharacterId: string | null = null;
    let maxDistance: number = 0;
    for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
      if (!characterId.startsWith('enemy')) {
        const character = characters.find(c => c.id === characterId);
        if (character && !character.isDead) {
          const dist = distance(characterPos, bomboPosition);
          if (dist > maxDistance) {
            maxDistance = dist;
            furthestCharacterId = characterId;
          }
        }
      }
    }

    if (furthestCharacterId) {
      performEnemyAttack(bombo, furthestCharacterId, bombo.attack[0]);
    }
  }
}

/**
 * 
 */
export function attackMageGobelin(
  gobelinMage: Creature,
  gobelinMagePosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let furthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, gobelinMagePosition);
        if (dist > maxDistance) {
          maxDistance = dist;
          furthestCharacterId = characterId;
        }
      }
    }
  }

  if (furthestCharacterId) {
    performEnemyAttack(gobelinMage, furthestCharacterId, gobelinMage.attack[0]);
  }
}

/**
 * 
 */
export function attackAhriman(
  ahriman: Creature,
  ahrimanPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let closestCharacterId: string | null = null;
  let closestDistance: number = Infinity;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, ahrimanPosition);
        if (dist < closestDistance) {
          closestDistance = dist;
          closestCharacterId = characterId;
        }
      }
    }
  }
  const enemyAttack = ahriman.attack[0];
  const attack = attackData.find(enemy => enemy.attack === enemyAttack);

  if (closestCharacterId && attack) {
    performEnemyAttack(
      ahriman,
      closestCharacterId,
      enemyAttack,
      attack.status ? { status: { name: attack.status, chance: attack.chance } } : undefined
    );
  }
}

/**
 * 
 */
export function attackChimere(
  chimera: Creature,
  chimeraPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let furthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, chimeraPosition);
        if (dist > maxDistance) {
          maxDistance = dist;
          furthestCharacterId = characterId;
        }
      }
    }
  }

  if (furthestCharacterId) {
    performEnemyAttack(chimera, furthestCharacterId, chimera.attack[0]);
  }
}

/**
 * 
 */
export function attackDragonRouge(
  redDragon: Creature,
  redDragonPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let furthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, redDragonPosition);
        if (dist > maxDistance) {
          maxDistance = dist;
          furthestCharacterId = characterId;
        }
      }
    }
  }

  if (furthestCharacterId) {
    performEnemyAttack(redDragon, furthestCharacterId, redDragon.attack[0]);
  }
}

/**
 * 
 */
export function attackDragonBleu(
  blueDragon: Creature,
  blueDragonPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let furthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, blueDragonPosition);
        if (dist > maxDistance) {
          maxDistance = dist;
          furthestCharacterId = characterId;
        }
      }
    }
  }

  if (furthestCharacterId) {
    performEnemyAttack(blueDragon, furthestCharacterId, blueDragon.attack[0]);
  }
}

/**
 * 
 */
export function attackDragonGlace(
  iceDragon: Creature,
  iceDragonPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let closestCharacterId: string | null = null;
  let closestDistance: number = Infinity;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(characterPos, iceDragonPosition);
        if (dist < closestDistance && dist <= 2) {
          closestDistance = dist;
          closestCharacterId = characterId;
        }
      }
    }
  }

  if (closestCharacterId) {
    const enemyAttack = iceDragon.attack[0];
    const attack = attackData.find(enemy => enemy.attack === enemyAttack);
    if (attack) {
      performEnemyAttack(
        iceDragon,
        closestCharacterId,
        enemyAttack,
        attack.status ? { status: { name: attack.status, chance: attack.chance } } : undefined
      );
    }
  }
}

/**
 * 
 */
export function attackCoeurl(
  coeurl: Creature,
  coeurlPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let farthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(coeurlPosition, characterPos);
        if (dist > maxDistance) {
          maxDistance = dist;
          farthestCharacterId = characterId;
        }
      }
    }
  }

  if (farthestCharacterId) {
    const attackName = coeurl.attack[0];
    performEnemyAttack(coeurl, farthestCharacterId, attackName);
  }
}

/**
 * 
 */
export function attackDragonnet(
  dragonnet: Creature,
  dragonnetPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let farthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(dragonnetPosition, characterPos);
        if (dist > maxDistance) {
          maxDistance = dist;
          farthestCharacterId = characterId;
        }
      }
    }
  }

  if (farthestCharacterId) {
    const attackName = dragonnet.attack[0];
    performEnemyAttack(dragonnet, farthestCharacterId, attackName);
  }
}

/**
 * 
 */
export function attackGriffon(
  griffon: Creature,
  griffonPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let farthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(griffonPosition, characterPos);
        if (dist > maxDistance) {
          maxDistance = dist;
          farthestCharacterId = characterId;
        }
      }
    }
  }

  if (farthestCharacterId) {
    const attackName = griffon.attack[0];
    performEnemyAttack(griffon, farthestCharacterId, attackName);
  }
}

/**
 * 
 */
export function attackBruleur(
  bruleur: Creature,
  bruleurPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let farthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  // Parcourir tous les personnages pour trouver le plus éloigné
  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(bruleurPosition, characterPos);
        if (dist > maxDistance) {
          maxDistance = dist;
          farthestCharacterId = characterId;
        }
      }
    }
  }

  if (farthestCharacterId) {
    const attackName = bruleur.attack[0];
    performEnemyAttack(bruleur, farthestCharacterId, attackName);
  }
}

/**
 * 
 */
export function attackDullahan(
  dullahan: Creature,
  dullahanPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  let closestCharacterId: string | null = null;
  let minDistance: number = Infinity;

  // Parcourir tous les personnages pour trouver le plus proche
  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(dullahanPosition, characterPos);
        if (dist < minDistance) {
          minDistance = dist;
          closestCharacterId = characterId;
        }
      }
    }
  }

  if (closestCharacterId) {
    const attackName = dullahan.attack[0];
    performEnemyAttack(dullahan, closestCharacterId, attackName);
  }
}

/**
 * 
 */
export function attackChevalierMortVivant(
  chevalier: Creature,
  chevalierPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): TokenPosition | null {
  let targetCharacterId = null;
  let maxDistance = 0;

  // Trouver le personnage le plus éloigné en ligne ou en diagonale dans un rayon de 5 cases
  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(chevalierPosition, characterPos);
        const isInlineOrDiagonal = characterPos.row === chevalierPosition.row ||
          characterPos.col === chevalierPosition.col ||
          Math.abs(characterPos.row - chevalierPosition.row) === Math.abs(characterPos.col - chevalierPosition.col);
        if (isInlineOrDiagonal && dist > maxDistance && dist <= 5) {
          maxDistance = dist;
          targetCharacterId = characterId;
        }
      }
    }
  }

  // Déplacer le chevalier et attaquer si possible
  if (targetCharacterId) {
    const targetCharacterPos = tokenPositions[targetCharacterId];
    let steps = 0;

    while (steps < 5 && !isAdjacent(chevalierPosition, targetCharacterPos)) {
      const rowDiff = targetCharacterPos.row - chevalierPosition.row;
      const colDiff = targetCharacterPos.col - chevalierPosition.col;
      const rowStep = rowDiff !== 0 ? rowDiff / Math.abs(rowDiff) : 0;
      const colStep = colDiff !== 0 ? colDiff / Math.abs(colDiff) : 0;

      // Se déplacer seulement si le personnage est en ligne ou en diagonale
      if (rowDiff === 0 || colDiff === 0 || Math.abs(rowDiff) === Math.abs(colDiff)) {
        chevalierPosition.row += rowStep;
        chevalierPosition.col += colStep;
        steps++;
      }

      // Attaquer si adjacent après chaque pas
      if (isAdjacent(chevalierPosition, targetCharacterPos)) {
        performEnemyAttack(chevalier, targetCharacterId, chevalier.attack[0]);

        return chevalierPosition; // Retourner la nouvelle position après l'attaque
      }
    }

    return chevalierPosition; // Retourner la nouvelle position même si pas d'attaque
  }

  return null; // Retourner null si aucune action n'a été effectuée
}

/**
 * 
 */
export function attackYeti(
  yeti: Creature,
  yetiPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): TokenPosition | null {
  let farthestCharacterId: string | null = null;
  let maxDistance: number = 0;

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(yetiPosition, characterPos);
        if (dist > maxDistance) {
          maxDistance = dist;
          farthestCharacterId = characterId;
        }
      }
    }
  }

  if (farthestCharacterId) {
    const targetCharacterPos = tokenPositions[farthestCharacterId];

    if (maxDistance <= 2) {
      performEnemyAttack(yeti, farthestCharacterId, yeti.attack[0]);
    } else if (maxDistance >= 3) {
      let steps = 0;
      while (steps < 5 && !isAdjacent(yetiPosition, targetCharacterPos)) {
        const rowStep = targetCharacterPos.row > yetiPosition.row ? 1 :
          (targetCharacterPos.row < yetiPosition.row ? -1 : 0);
        const colStep = targetCharacterPos.col > yetiPosition.col ? 1 :
          (targetCharacterPos.col < yetiPosition.col ? -1 : 0);

        yetiPosition.row += rowStep;
        yetiPosition.col += colStep;
        steps++;
      }

      // Si adjacent après s'être déplacé, attaquer avec la seconde attaque
      if (isAdjacent(yetiPosition, targetCharacterPos)) {
        performEnemyAttack(yeti, farthestCharacterId, yeti.attack[1]);

        return yetiPosition;
      }

      return yetiPosition;
    }
  }

  return null;
}

/**
 * 
 */
export function attackTroll(
  troll: Creature,
  trollPosition: TokenPosition,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  performEnemyAttack: PerformAttackFunction
): void {
  const adjacentCharacters = [];
  const charactersWithinTwoCases = [];

  for (const [characterId, characterPos] of Object.entries(tokenPositions)) {
    if (!characterId.startsWith('enemy')) {
      const character = characters.find(c => c.id === characterId);
      if (character && !character.isDead) {
        const dist = distance(trollPosition, characterPos);
        if (dist === 1) {
          adjacentCharacters.push(characterId);
        }
        if (dist <= 2) {
          charactersWithinTwoCases.push(characterId);
        }
      }
    }
  }

  if (adjacentCharacters.length === 1 && charactersWithinTwoCases.length === 1) {
    performEnemyAttack(troll, adjacentCharacters[0], troll.attack[0]);
  } else if (charactersWithinTwoCases.length > 1) {
    charactersWithinTwoCases.forEach(characterId => {
      performEnemyAttack(troll, characterId, troll.attack[1]);
    });
  }
}