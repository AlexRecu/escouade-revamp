import type { Character } from '@interfaces/interfaces';

export const initCharacter: Character = {
  id: '',
  userId: '',
  name: '',
  classe: '',
  weapon: '',
  stats: {
    'strength': 0,
    'dexterity': 0,
    'endurance': 0,
    'mana': 0,
    'intelligence': 0,
    'perception': 0,
    'charisma': 0
  },
  currentHealth: 0,
  currentMana: 0,
  maxHealth: 0,
  maxMana: 0,
  tempStats: {
    'strength': 0,
    'dexterity': 0,
    'endurance': 0,
    'mana': 0,
    'intelligence': 0,
    'perception': 0,
    'charisma': 0
  },
  isCommitted: false,
  creationDate: 0,
  isDead: false,
  status: []
};
