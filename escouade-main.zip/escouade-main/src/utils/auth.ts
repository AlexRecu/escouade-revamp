
import type { NotificationOptions } from '@interfaces/types';
import { getAuth } from 'firebase/auth';

import { superAdminIds } from './const';

/**
 * Returns the current user's ID if available, otherwise returns an empty string.
 * @returns {string} The current user's ID, or an empty string if not available.
 */
export function userId(): string {
  const auth = getAuth();

  return auth.currentUser?.uid ?? '';
}

/**
 * Checks if a user is authorized to perform actions on a character.
 * @param {string} userId - The ID of the user.
 * @param {string} characterOwnerId - The ID of the character's owner.
 * @param {(message: string, options: NotificationOptions) => void} notify - The function to notify the user.
 * @param {boolean} shouldNotify - Whether to notify the user if not authorized (default is true).
 * @returns {boolean} True if the user is authorized; otherwise, false.
 */
export function isUserAuthorizedCharacter(
  userId: string,
  characterOwnerId: string,
  notify: (message: string, options: NotificationOptions) => void,
  shouldNotify: boolean = true
): boolean {
  const isAuthorized = userId === characterOwnerId || superAdminIds.includes(userId);
  if (!isAuthorized && shouldNotify) {
    notify('Action non autorisée.', { variant: 'error' });
  }

  return isAuthorized;
}

/**
 * Checks if a user is authorized as a super admin.
 * @param {string} userId - The ID of the user.
 * @returns {boolean} True if the user is a super admin; otherwise, false.
 */
export function isUserAuthorized(userId: string): boolean {
  const isAuthorized = superAdminIds.includes(userId);

  return isAuthorized;
}