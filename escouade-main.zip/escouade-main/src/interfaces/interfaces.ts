export interface AttackData {
  attack: string;
  description: string | null;
  condition: string | null;
  target: string;
  move: number;
  range: number | null;
  turn: number;
  zoneEffect: number;
  status: string | null;
  chance: number | null;
  deathMessage: string;
}

export interface BattleDataUpdate {
  tokenPositions: { [characterId: string]: TokenPosition };
  currentTurn?: number;
  turnOrder?: string[];
  enemiesGenerated?: boolean;
}

export interface Character {
  id: string;
  userId: string;
  name: string;
  classe: string;
  weapon: string;
  currentHealth: number;
  maxHealth: number;
  currentMana: number;
  maxMana: number;
  stats: Stats;
  tempStats: Stats;
  isCommitted: boolean;
  creationDate: number;
  isDead: boolean;
  status: string[];
}

export interface Characteristics {
  name: string;
  weapons: string;
  defaultStats: Stats;
  item: string[];
  gold: number;
  spells: SpellLevel;
}

export interface ClassCounts {
  [key: string]: number;
}

export interface Classes {
  mageBleu: Characteristics[];
  voleur: Characteristics[];
  mageRouge: Characteristics[];
  mageBlanc: Characteristics[];
  mageNoir: Characteristics[];
}

export interface Creature {
  name: string;
  type: string;
  weakness: string[];
  immunity: string[];
  resistance: string[];
  attack: string[];
  atk: number[];
  pv: number[];
  xp: number[];
  gold: number[];
  spawn_rates: {
    forest: number;
    cave: number;
    tower: number;
    castle: number;
    gorge: number;
    frozenEarth: number;
  };
}

export interface GameInfo {
  level: number;
  xp: number;
  zoneLevel: number;
  currentMusic: string;
  musicStatus: 'play' | 'pause' | 'stop';
  musicTime: number;
  startTimestamp: number;
  map: string;
  merchantAvailable: boolean;
  battleMapAvailable: boolean;
  gold: number;
}

export interface Item {
  id?: string;
  name: string;
  type: string;
  effect: string;
  purchasePrice: number;
  resaleBase: number;
  assignedTo?: string;
  count?: number;
}

export interface ItemData {
  count: number;
  assignedTo?: string;
}

export interface MapImage {
  name: string;
  url: string;
}

export interface MusicFile {
  name: string;
  file: string;
}

export interface Notification {
  message: string;
  timestamp: number;
  variant: 'success' | 'warning' | 'error' | 'info';
  anchorOrigin?: {
    vertical: 'top' | 'bottom';
    horizontal: 'center' | 'left' | 'right';
  };
}

export interface Spell {
  name: string;
  description: string;
  target: 'enemy' | 'ally';
  element: string;
  cost: number;
  power: number;
  hp: number;
  status: [
    {
      name: string;
      nbTurnEffect: number;
    }
  ];
}

export interface SpellLevel {
  [key: string]: number;
}

export interface Stats {
  strength: number;
  dexterity: number;
  endurance: number;
  mana: number;
  intelligence: number;
  perception: number;
  charisma: number;
}

export interface TokenPosition {
  id?: string;
  row: number;
  col: number;
  hasMoved?: boolean;
  hasAttacked?: boolean;
  hasUsedItem?: boolean;
  hasUsedSpell?: boolean;
  hasJumped?: boolean;
  creatureName?: string;
  turnPass?: boolean;
  currentHealth?: number;
  maxHealth?: number;
  alreadyCall?: boolean;
  isDead?: boolean;
  status?: string[];
}

export interface TokenPositions {
  [key: string]: TokenPosition;
}

export interface Weapon {
  type: string;
  mainStat: string;
  subStat: string | null;
  name: string;
  weaponStat: number;
  weaponSubStat: string | null;
  range: number;
  status: string | null;
  element: string | null;
}

export interface Zone {
  atk: number;
  pv: number;
  xp: number;
}