import type { ReactNode, RefObject } from 'react';

import type {
  Character, Creature, GameInfo, Item, ItemData, MapImage, Notification, Spell, Stats, TokenPosition, TokenPositions
} from './interfaces';

export type ActionMenuProps = {
  onMoveSelect: () => void;
  onAttackSelect: () => void;
  onSpellSelect: () => void;
  disableMove: boolean;
  disableAttack: boolean;
  disableSpell: boolean;
  enemiesAdjacent: boolean;
  anchorEl: HTMLElement | null;
  open: boolean;
  onClose: () => void;
}

export type AudioContextProps = {
  volume: number;
  setVolume: (volume: number) => void;
  currentTrack: string;
  isPlaying: boolean;
  playMusic: (track: string) => void;
  pauseMusic: () => void;
  stopMusic: () => void;
  musicList: Array<{ name: string; file: string }>;
  progress: number;
  uploadMusic: (file: File) => void;
  deleteMusic: (name: string) => void;
};

export type BattleContextProps = {
  tokenPositions: TokenPositions;
  setTokenPositions: React.Dispatch<React.SetStateAction<TokenPositions>>;
  handleSetTokenPositions: (newPositions: TokenPositions) => void;
  updateBattleDataInFirestore: (
    newTokenPositions: TokenPositions, newCurrentTurn: number, turnOrder: string[]) => Promise<void>;
  currentTurn: number;
  advanceTurn: () => void;
  resetTurns: () => void;
  turnOrder: string[];
  advanceTurnOrder: () => void;
  completeTurn?: () => void;
  isPreBattlePlacementAllowed: boolean;
  handlePreBattlePlacementToggle: () => void;
  handleEnemiesGeneratedToggle: () => void;
  enemiesGenerated: boolean;
  setEnemiesGenerated: React.Dispatch<React.SetStateAction<boolean>>;
};

export type BottomNavProps = {
  currentTab: number;
  onTabChange: (event: React.SyntheticEvent, newValue: number) => void;
  onSettingsClick: () => void;
};

export type CardCharacterProps = {
  character: Character;
  index: number;
};

export type CharacterBarProps = {
  character: Character;
};

export type CharacterContextProps = {
  characters: Character[];
  addCharacter: (character: Character) => void;
  deleteCharacter: (index: number) => void;
  updateCharacter: (
    index: number,
    field: string,
    value: string | number | boolean | string[] | Stats,
    attackName?: string,
    status?: string
  ) => void;
  setCharactersFromImport: (importedCharacters: Character[]) => void;
};

export type CharacterCharacteristicsProps = {
  character: Character;
  index: number;
};

export type CharacterStatsProps = {
  statKey: string;
  label: string;
  tempStats: Stats;
}

export type CharacterTokenProps = {
  id: string;
  isOnBoard: boolean;
}

export type ClassAndWeaponSelectorProps = {
  character: Character;
  index: number;
};

export interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  message: string;
}

export type CreatureTokenProps = {
  creature: TokenPosition;
}

export type DetailsCharacterProps = {
  character: Character;
};

export interface DraggableCharacterTokenProps {
  id: string;
  character: Character;
  isOnBoard: boolean;
  handleTokenSelect: (id: string) => void;
  enableAttackMode: () => void;
  openSpell: () => void;
  selectedToken: string;
  isCurrentUserTurn: boolean;
}

export type DroppableSquareProps = {
  row: number;
  col: number;
  onDrop: (row: number, col: number) => void;
  children?: React.ReactNode;
  validMovePositions: { [key: string]: boolean };
  validAttackPositions: { [key: string]: boolean };
  validSpellAttackPositions: { [key: string]: boolean };
};

export type EasterEggModalProps = {
  isOpen: boolean;
  handleClose: () => void;
};

export type FirestoreItem = Item & { itemData: ItemData };

export type GameInfoContextProps = {
  gameInfo: GameInfo;
  updateGameInfo: (newGameInfo: GameInfo) => Promise<void>;
  setGameInfoFromImport: (importedGameInfo: GameInfo) => void;
};

export type ItemCardProps = {
  item: Item;
  onActionClick: () => void;
  actionLabel: string;
  count?: number;
  assignedTo?: string;
};

export type ItemContextProps = {
  inventory: Map<Item, { count: number; assignedTo?: string }>;
  addToInventory: (item: Item, idCharacter?: string) => void;
  removeFromInventory: (item: Item) => void;
  assignWeaponToCharacter: (weaponName: string, characterName: string) => void;
  unassignWeapon: (weaponName: string) => void;
  setInventoryFromImport: (importedInventory: Map<Item, ItemData>) => void;
  filterItems: (items: Item[], searchTerm: string) => Item[];
};

export type ItemListProps = {
  items: Item[];
  currentPage: number;
  itemsPerPage: number;
  setCurrentPage: (page: number) => void;
  onItemAction: (item: Item) => () => void;
  actionLabel: string;
};

export type ItemListSearchBarProps = {
  searchTerm: string;
  setSearchTerm: (searchTerm: string) => void;
  filterType: string[];
  setFilterType: (filterType: string[]) => void;
  setCurrentPage: (currentPage: number) => void;
};

export type ManageCharacterDialogProps = {
  open: boolean;
  onClose: () => void;
  onAddCharacter: () => void;
  newCharacterName: string;
  setNewCharacterName: (name: string) => void;
  newCharacterClass: string;
  setNewCharacterClass: (name: string) => void;
};

export type MapCardProps = {
  image: {
    name: string;
    url: string;
  };
  gameInfo: {
    map: string;
  };
  handleImageClick: (imageUrl: string) => void;
  handleOpenDeleteDialog: (name: string, type: string) => () => void;
};

export type MapImageContextProps = {
  imageList: MapImage[];
  uploadMap: (file: File) => Promise<void>;
  deleteMap: (name: string) => void;
};

export type MusicCardProps = {
  music: {
    name: string;
    file: string;
  };
  isPlaying: boolean;
  currentTrack: string;
  progress: number;
  playMusic: (file: string) => void;
  pauseMusic: () => void;
  stopMusic: () => void;
  handleOpenDeleteDialog: (name: string, type: string) => () => void;
};

export type NotificationContextProps = {
  sendNotification: (message: string, variant: Notification['variant']) => void;
};

export type NotificationOptions = {
  variant: 'default' | 'error' | 'success' | 'warning' | 'info';
};

export type PerformAttackFunction = (
  enemy: Creature,
  targetId: string,
  attackName: string,
  options?: { status?: { name: string; chance: number }; damage?: number; enemyId?: string }
) => void;

export type ProviderProps = {
  children: ReactNode;
};

export type SettingsDrawerProps = {
  drawerOpen: boolean;
  setDrawerOpen: (open: boolean) => void;
  onOpenDialog: () => void;
  onImportClick: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onExportClick: () => void;
  fileInputRef: RefObject<HTMLInputElement>;
};

export type SpellDetail = {
  spell: Spell;
  characterId: string;
}

export type TabMenuProps = {
  currentTab: number;
  onTabChange: (event: React.SyntheticEvent, newValue: number) => void;
};

export type ValidPositions = Record<string, boolean>;

export type Zones = 'forest' | 'cave' | 'tower' | 'castle' | 'gorge' | 'frozenEarth'