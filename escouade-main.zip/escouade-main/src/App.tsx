import { lazy, useEffect, useState } from 'react';
import { Box, CircularProgress, CssBaseline, ThemeProvider, createTheme, responsiveFontSizes } from '@mui/material';
import { GameInfoProvider } from '@contexts/GameInfoContext';
import { ItemProvider } from '@contexts/ItemContext';
import { CharacterProvider } from '@contexts/CharacterContext';
import { SnackbarProvider } from 'notistack';
import { AudioProvider } from '@contexts/AudioContext';
import { BattleProvider } from '@contexts/BattleContext';
import { MapImageProvider } from '@contexts/MapImageContext';
import { NotificationProvider } from '@contexts/NotificationContext';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

const Dashboard = lazy(() => import('./components/dashboard/Dashboard'));
const LoginComponent = lazy(() => import('./auth/LoginPage'));


const darkTheme = responsiveFontSizes(createTheme({
  palette: {
    mode: 'dark',
    background: {
      default: '#000000'
    }
  },
}));

/**
 */
export default function App(): JSX.Element {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setIsAuthenticated(Boolean(user));
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <Box sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '90vh',
        overflow: 'hidden'
      }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <GameInfoProvider>
      <AudioProvider>
        <ThemeProvider theme={darkTheme}>
          <CssBaseline />
          <SnackbarProvider maxSnack={3} autoHideDuration={4000}>
            <NotificationProvider>
              <ItemProvider>
                <MapImageProvider>
                  <BattleProvider>
                    <CharacterProvider>
                      {isAuthenticated ? <Dashboard /> : <LoginComponent />}
                    </CharacterProvider>
                  </BattleProvider>
                </MapImageProvider>
              </ItemProvider>
            </NotificationProvider>
          </SnackbarProvider>
        </ThemeProvider>
      </AudioProvider>
    </GameInfoProvider>
  );
}