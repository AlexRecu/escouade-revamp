import { initializeApp } from 'firebase/app';
import type { DocumentData, DocumentReference } from 'firebase/firestore';
import { getFirestore, doc } from 'firebase/firestore';

import { firebaseConfig } from './config';

export const db = getFirestore(initializeApp(firebaseConfig));

export const getGameUserDataDocument = (
  docName: 'characters' | 'inventory' | 'gameInfo' | 'battle'
): DocumentReference<DocumentData> => doc(db, 'gameUserData', docName);