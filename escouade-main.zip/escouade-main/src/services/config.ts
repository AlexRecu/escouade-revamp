export const firebaseConfig = {
  apiKey: 'AIzaSyAi5YFw2fEMvgO8WfZc3TWbR0-fvjLWiGw',
  authDomain: 'escouade-f2322.firebaseapp.com',
  projectId: 'escouade-f2322',
  storageBucket: 'escouade-f2322.appspot.com',
  messagingSenderId: '932205352477',
  appId: '1:932205352477:web:4581202b09a8235dfed8f4'
};