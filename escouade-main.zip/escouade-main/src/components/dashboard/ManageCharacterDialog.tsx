import React, { useState } from 'react';
import type { ManageCharacterDialogProps } from '@interfaces/types';
import type {
  SelectChangeEvent
} from '@mui/material';
import {
  Unstable_Grid2 as Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  DialogActions,
  Button,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Divider,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { useCharacters } from '@contexts/CharacterContext';
import { isUserAuthorized, userId } from '@utils/auth';
import { classesOptions } from '@utils/const';

/**
 * React component for managing characters including adding, listing, and deleting characters.
 *
 * @param {ManageCharacterDialogProps} props - The props for the component.
 * @param {boolean} props.open - Indicates whether the dialog is open.
 * @param {() => void} props.onClose - Function to handle the dialog close event.
 * @param {() => void} props.onAddCharacter - Function to handle adding a new character.
 * @param {string} props.newCharacterName - The name of the new character.
 * @param {Function} props.setNewCharacterName - Function to set the new character's name.
 * @param {string} props.newCharacterClass - The class of the new character.
 * @param {Function} props.setNewCharacterClass - Function to set the new character's class.
 * @returns {JSX.Element} A React JSX element representing the ManageCharacterDialog.
 */
export function ManageCharacterDialog({
  open,
  onClose,
  onAddCharacter,
  newCharacterName,
  setNewCharacterName,
  newCharacterClass,
  setNewCharacterClass
}: ManageCharacterDialogProps): JSX.Element {
  const { characters, deleteCharacter } = useCharacters();
  const [confirmationDialogOpen, setConfirmationDialogOpen] = useState(false);
  const [characterToDelete, setCharacterToDelete] = useState<number | null>(null);
  const userHasCharacter = characters.some(character => character.userId === userId() && !isUserAuthorized(userId()));
  const userCharacters = characters.filter(character => character.userId === userId());
  const isEmpty = characters.length === 0 || userCharacters.length === 0;
  const [errors, setErrors] = useState({ name: '', class: '' });

  const validateAndAddCharacter = (): void => {
    let isValid = true;
    const newErrors = { name: '', class: '' };

    if (!newCharacterName.trim()) {
      newErrors.name = 'Le nom du personnage est requis.';
      isValid = false;
    }

    if (!newCharacterClass) {
      newErrors.class = 'La classe du personnage est requise.';
      isValid = false;
    }

    setErrors(newErrors);

    if (isValid) {
      onAddCharacter();
    }
  };

  const handleClassChange = (event: SelectChangeEvent): void => {
    setNewCharacterClass(event.target.value as string);
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    setNewCharacterName(e.target.value);
  };

  const openConfirmationDialog = (index: number): void => {
    setCharacterToDelete(index);
    setConfirmationDialogOpen(true);
  };

  const closeConfirmationDialog = (): void => {
    setCharacterToDelete(null);
    setConfirmationDialogOpen(false);
  };

  const confirmDeleteCharacter = (): void => {
    if (characterToDelete !== null) {
      deleteCharacter(characterToDelete);
      closeConfirmationDialog();
    }
  };

  return (
    <>
      <Dialog fullWidth={true} open={open} onClose={onClose}>
        {!userHasCharacter && (
          <>
            <DialogTitle textAlign={'center'}>Créer un personnage</DialogTitle>
            <DialogContent>
              <Grid container spacing={1}>
                <Grid xs={6}>
                  <TextField
                    margin='dense'
                    fullWidth
                    label="Nom du personnage"
                    variant="outlined"
                    value={newCharacterName}
                    onChange={handleNameChange}
                    error={Boolean(errors.name)}
                    helperText={errors.name}
                  />
                </Grid>
                <Grid xs={6}>
                  <FormControl fullWidth margin='dense' error={Boolean(errors.class)}>
                    <InputLabel id="class-select-label">Classe</InputLabel>
                    <Select
                      labelId="class-select-label"
                      id="class-select"
                      value={newCharacterClass}
                      label="Classe"
                      onChange={handleClassChange}
                    >
                      {classesOptions.map(option => (
                        <MenuItem key={option.value} value={option.value}>
                          {option.label}
                        </MenuItem>
                      ))}
                    </Select>
                    {errors.class && <FormHelperText>{errors.class}</FormHelperText>}
                  </FormControl>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={onClose}>Annuler</Button>
              <Button onClick={validateAndAddCharacter}>Ajouter</Button>
            </DialogActions>
          </>
        )}
        {isUserAuthorized(userId()) && (
          <>
            <DialogTitle textAlign={'center'}>Liste des personnages</DialogTitle>
            <DialogContent>
              {isEmpty ? (
                <Typography textAlign="center" color="textSecondary">
                  Aucun personnage à afficher.
                </Typography>
              ) : (
                <List>
                  {characters.map((character, index) => (
                    <React.Fragment key={character.name}>
                      <Divider component="li" />
                      <ListItem>
                        <ListItemText primary={character.name} />
                        <IconButton edge="end" aria-label="delete" onClick={() => openConfirmationDialog(index)}>
                          <DeleteIcon />
                        </IconButton>
                      </ListItem>
                    </React.Fragment>
                  ))}
                </List>
              )}
            </DialogContent>
          </>
        )}
        {!isUserAuthorized(userId()) && (
          <>
            <DialogTitle textAlign={'center'}>Liste des personnages</DialogTitle>
            <DialogContent>
              {isEmpty ? (
                <Typography textAlign="center" color="textSecondary">
                  Aucun personnage à afficher.
                </Typography>
              ) : (
                <List>
                  {characters.filter(character => character.userId === userId()).map((character, index) => (
                    <React.Fragment key={character.name}>
                      <Divider component="li" />
                      <ListItem>
                        <ListItemText primary={character.name} />
                        <IconButton edge="end" aria-label="delete" onClick={() => openConfirmationDialog(index)}>
                          <DeleteIcon />
                        </IconButton>
                      </ListItem>
                    </React.Fragment>
                  ))}
                </List>
              )}
            </DialogContent>
          </>
        )}
      </Dialog >
      <Dialog open={confirmationDialogOpen} onClose={closeConfirmationDialog}>
        <DialogTitle>Confirmation de suppression</DialogTitle>
        <DialogContent>
          Êtes-vous sûr de vouloir supprimer ce personnage ?
        </DialogContent>
        <DialogActions>
          <Button onClick={closeConfirmationDialog}>Annuler</Button>
          <Button onClick={confirmDeleteCharacter} color="error">Supprimer</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

export default ManageCharacterDialog;