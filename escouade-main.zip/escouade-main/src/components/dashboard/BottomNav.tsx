import { BottomNavigation, BottomNavigationAction } from '@mui/material';
import StorefrontIcon from '@mui/icons-material/Storefront';
import InventoryIcon from '@mui/icons-material/Inventory';
import PublicIcon from '@mui/icons-material/Public';
import SettingsIcon from '@mui/icons-material/Settings';
import LibraryMusicIcon from '@mui/icons-material/LibraryMusic';
import AppsIcon from '@mui/icons-material/Apps';
import { isUserAuthorized, userId } from '@utils/auth';
import { useGameInfo } from '@contexts/GameInfoContext';
import { useCharacters } from '@contexts/CharacterContext';
import type { BottomNavProps } from '@interfaces/types';

/**
 * React component for displaying a bottom navigation bar with different tabs and settings.
 *
 * @param {BottomNavProps} props - The props for the component.
 * @param {number} props.currentTab - The currently selected tab index.
 * @param {Function} props.onTabChange - Function to handle tab change events.
 * @param {Function} props.onSettingsClick - Function to handle the settings icon click event.
 * @returns {JSX.Element} A React JSX element representing the BottomNav.
 */
export function BottomNav({ currentTab, onTabChange, onSettingsClick }: BottomNavProps): JSX.Element {
  const { gameInfo } = useGameInfo();
  const { characters } = useCharacters();
  const style = { minWidth: 0 };

  return (
    <BottomNavigation
      value={currentTab}
      onChange={onTabChange}
      showLabels
      sx={{ position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 1000, display: { xs: 'flex', md: 'none' } }}
    >
      <BottomNavigationAction sx={style} icon={<PublicIcon />} />
      <BottomNavigationAction
        sx={style}
        icon={characters.length !== 0 ? <AppsIcon /> : <AppsIcon className="disabled-icon" />}
        disabled={characters.length === 0 || (!gameInfo.battleMapAvailable && !isUserAuthorized(userId()))}
      />
      <BottomNavigationAction sx={style} icon={<InventoryIcon />} />
      <BottomNavigationAction
        sx={style}
        icon={gameInfo.merchantAvailable ? <StorefrontIcon /> : <StorefrontIcon className="disabled-icon" />}
        disabled={!gameInfo.merchantAvailable}
      />
      {isUserAuthorized(userId()) && (
        <BottomNavigationAction sx={style} icon={<LibraryMusicIcon />} />
      )}
      <BottomNavigationAction sx={style} icon={<SettingsIcon />} data-settings-icon onClick={onSettingsClick} />
    </BottomNavigation>
  );
}

export default BottomNav;