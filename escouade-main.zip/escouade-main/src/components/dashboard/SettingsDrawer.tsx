import { Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Slider } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import SaveIcon from '@mui/icons-material/Save';
import VolumeUpIcon from '@mui/icons-material/VolumeUp';
import type { SettingsDrawerProps } from '@interfaces/types';
import { useEffect } from 'react';
import { useAudio } from '@contexts/AudioContext';
import { isUserAuthorized, userId } from '@utils/auth';

/**
 * React component for displaying a settings drawer with various options.
 *
 * @param {SettingsDrawerProps} props - The props for the component.
 * @param {boolean} props.drawerOpen - Indicates whether the settings drawer is open.
 * @param {Function} props.setDrawerOpen - Function to handle opening and closing the drawer.
 * @param {Function} props.onOpenDialog - Function to open a dialog.
 * @param {Function} props.onImportClick - Function to handle the import click event.
 * @param {Function} props.onExportClick - Function to handle the export click event.
 * @param {React.RefObject} props.fileInputRef - Reference to the file input element for import.
 * @returns {JSX.Element} A React JSX element representing the SettingsDrawer.
 */
function SettingsDrawer(
  { drawerOpen, setDrawerOpen, onOpenDialog, onImportClick, onExportClick, fileInputRef }: SettingsDrawerProps
): JSX.Element {
  const { volume, setVolume } = useAudio();

  useEffect(() => {
    localStorage.setItem('volume', volume.toString());
  }, [volume]);

  const handleVolumeChange = (_event: Event, newValue: number | number[]): void => {
    const newVolume = Math.min(Math.max(newValue as number, 0), 100);
    setVolume(newVolume);
  };

  return (
    <>
      <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <List>
          <ListItemButton onClick={() => { onOpenDialog(); setDrawerOpen(false); }}>
            <ListItemIcon><PeopleIcon /></ListItemIcon>
            <ListItemText primary="Gérer les personnages" />
          </ListItemButton>
          {isUserAuthorized(userId()) && (
            <ListItemButton onClick={() => { fileInputRef.current?.click(); setDrawerOpen(false); }}>
              <ListItemIcon><UploadFileIcon /></ListItemIcon>
              <ListItemText primary="Importer" />
            </ListItemButton>
          )}
          <ListItemButton onClick={() => { onExportClick(); setDrawerOpen(false); }}>
            <ListItemIcon><SaveIcon /></ListItemIcon>
            <ListItemText primary="Exporter" />
          </ListItemButton>
          <ListItem sx={{ width: '90%' }} >
            <ListItemIcon><VolumeUpIcon /></ListItemIcon>
            <ListItemText />
            <Slider
              aria-label="Volume"
              value={volume}
              onChange={handleVolumeChange}
              min={0}
              max={100}
            />
          </ListItem>
        </List>
      </Drawer>
      <input
        type="file"
        ref={fileInputRef}
        style={{ display: 'none' }}
        onChange={onImportClick}
      />
    </>
  );
}

export default SettingsDrawer;