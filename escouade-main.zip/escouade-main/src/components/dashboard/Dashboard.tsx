import React, { startTransition, useCallback, useEffect, useRef, useState } from 'react';
import { Box, IconButton } from '@mui/material';
import SettingsIcon from '@mui/icons-material/Settings';
import { useCharacters } from '@contexts/CharacterContext';
import type { Character } from '@interfaces/interfaces';
import { initCharacter } from '@utils/initCharacter';
import { isUserAuthorized, userId } from '@utils/auth';

import { useImportData } from '../../hooks/useImportData';
import { useExportData } from '../../hooks/useExportData';
const Inventory = React.lazy(() => import('../inventory/Inventory'));
const Adventure = React.lazy(() => import('../adventure/Adventure'));
const Merchant = React.lazy(() => import('../merchant/Merchant'));
const BattleMap = React.lazy(() => import('../battlemap/BattleMap'));
const Atmosphere = React.lazy(() => import('../atmosphere/Atmosphere'));

import SettingsDrawer from './SettingsDrawer';
import ManageCharacterDialog from './ManageCharacterDialog';
import TabMenu from './TabMenu';
import BottomNav from './BottomNav';

/**
 * Dashboard component representing the main application dashboard.
 *
 * @returns {JSX.Element} The Dashboard component.
 */
function Dashboard(): JSX.Element {
  const { addCharacter } = useCharacters();
  const [currentTab, setCurrentTab] = useState(() => {
    const savedTab = localStorage.getItem('currentTab');

    return savedTab ? parseInt(savedTab, 10) : 0;
  });
  const [openDialog, setOpenDialog] = useState(false);
  const [newCharacterName, setNewCharacterName] = useState<string>('');
  const [newCharacterClass, setNewCharacterClass] = useState<string>('');
  const handleImport = useImportData();
  const handleExport = useExportData();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('currentTab', currentTab.toString());
  }, [currentTab]);

  const handleTabChange = useCallback((_event: React.SyntheticEvent, newValue: number): void => {
    startTransition(() => {
      if (_event.currentTarget.getAttribute('data-settings-icon') === 'true') {
        setDrawerOpen(true);
      } else {
        setCurrentTab(newValue);
      }
    });
  }, []);

  const handleOpenDialog = useCallback((): void => {
    setOpenDialog(true);
  }, []);

  const handleCloseDialog = useCallback((): void => {
    setOpenDialog(false);
    setNewCharacterName('');
  }, []);

  const handleAddCharacter = useCallback((): void => {
    if (!newCharacterClass) {
      return;
    }
    if (userId()) {
      const newCharacter: Character = {
        ...initCharacter,
        name: newCharacterName,
        classe: newCharacterClass,
        userId: userId()
      };
      addCharacter(newCharacter);
      handleCloseDialog();
    }
  }, [newCharacterName, newCharacterClass, addCharacter, handleCloseDialog]);

  const toggleDrawer = (open: boolean) => (event: React.KeyboardEvent | React.MouseEvent) => {
    if (event.type === 'keydown' && (
      (event as React.KeyboardEvent).key === 'Tab' || (event as React.KeyboardEvent).key === 'Shift')
    ) {
      return;
    }
    setDrawerOpen(open);
  };

  return (
    <Box sx={{ width: '100%', pb: { xs: 7, md: 0 } }}>
      <BottomNav
        currentTab={currentTab}
        onTabChange={handleTabChange}
        onSettingsClick={() => toggleDrawer(true)}
      />
      <TabMenu
        currentTab={currentTab}
        onTabChange={handleTabChange}
      />

      {currentTab === 0 && <Adventure />}
      {currentTab === 1 && <BattleMap />}
      {currentTab === 2 && <Inventory />}
      {currentTab === 3 && <Merchant />}
      {currentTab === 4 && isUserAuthorized(userId()) && <Atmosphere />}

      <IconButton
        onClick={toggleDrawer(true)}
        sx={{
          position: 'fixed',
          bottom: 16,
          right: 16,
          display: { xs: 'none', md: 'block' }
        }}
      >
        <SettingsIcon />
      </IconButton>

      <SettingsDrawer
        drawerOpen={drawerOpen}
        setDrawerOpen={setDrawerOpen}
        onOpenDialog={handleOpenDialog}
        onImportClick={handleImport}
        onExportClick={handleExport}
        fileInputRef={fileInputRef}
      />
      <ManageCharacterDialog
        open={openDialog}
        onClose={handleCloseDialog}
        onAddCharacter={handleAddCharacter}
        newCharacterName={newCharacterName}
        setNewCharacterName={setNewCharacterName}
        newCharacterClass={newCharacterClass}
        setNewCharacterClass={setNewCharacterClass}
      />
    </Box>
  );
}

export default Dashboard;