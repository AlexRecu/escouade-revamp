import { useCharacters } from '@contexts/CharacterContext';
import { useGameInfo } from '@contexts/GameInfoContext';
import type { TabMenuProps } from '@interfaces/types';
import { Tabs, Tab } from '@mui/material';
import { isUserAuthorized, userId } from '@utils/auth';

/**
 * React component for displaying a tab menu with different sections.
 *
 * @param {TabMenuProps} props - The props for the component.
 * @param {number} props.currentTab - The currently selected tab index.
 * @param {Function} props.onTabChange - Function to handle tab change events.
 * @returns {JSX.Element} A React JSX element representing the TabMenu.
 */
function TabMenu({ currentTab, onTabChange }: TabMenuProps): JSX.Element {
  const { gameInfo } = useGameInfo();
  const { characters } = useCharacters();

  return (
    <Tabs value={currentTab} onChange={onTabChange} centered sx={{ display: { xs: 'none', md: 'flex' } }}>
      <Tab label="Aventure" />
      <Tab label="Combat" disabled={
        characters.length === 0 || (!gameInfo.battleMapAvailable && !isUserAuthorized(userId()))
      } />
      <Tab label="Inventaire" />
      <Tab label="Marchand" disabled={!gameInfo.merchantAvailable} />
      {isUserAuthorized(userId()) && (
        <Tab label="Ambiance" />
      )}
    </Tabs>
  );
}

export default TabMenu;