/* eslint-disable no-case-declarations */
/* eslint-disable @typescript-eslint/no-unnecessary-condition */
/* eslint-disable complexity */
import type { ItemCardProps } from '@interfaces/types';
import {
  Card, CardContent, Typography, CardActions, Chip, Button, Tooltip, Box, Modal, Unstable_Grid2 as Grid
} from '@mui/material';
import { memo, useState } from 'react';
import weaponsData from '@data/weapons_data.json';
import type { Character, Item, Weapon } from '@interfaces/interfaces';
import { InfoOutlined } from '@mui/icons-material';
import { useBattle } from '@contexts/BattleContext';
import { useCharacters } from '@contexts/CharacterContext';
import { userId } from '@utils/auth';
import { useInventory } from '@contexts/ItemContext';
import { useNotification } from '@contexts/NotificationContext';
import { useGameInfo } from '@contexts/GameInfoContext';

/**
 * React component representing an item card with details and an action button.
 *
 * @param {ItemCardProps} props - The props for the component.
 * @param {Item} props.item - The item object with details.
 * @param {Function} props.onActionClick - Function to handle the action button click event.
 * @param {string} props.actionLabel - The label for the action button (e.g., "buy" or "inventory").
 * @param {number} props.count - The count of the item (if applicable).
 * @param {string|null} props.assignedTo - The name of the character to whom the item is assigned (if applicable).
 * @returns {JSX.Element} A React JSX element representing the ItemCard.
 */
function ItemCard({ item, onActionClick, actionLabel, count, assignedTo }: ItemCardProps): JSX.Element {
  const { gameInfo } = useGameInfo();
  const { characters, updateCharacter } = useCharacters();
  const { removeFromInventory } = useInventory();
  const {
    tokenPositions,
    handleSetTokenPositions,
    turnOrder,
    resetTurns,
    enemiesGenerated,
    setEnemiesGenerated,
    handlePreBattlePlacementToggle,
    handleEnemiesGeneratedToggle,
    isPreBattlePlacementAllowed,
    currentTurn
  } = useBattle();
  const isCharacterPlaced = (id: string): boolean => Object.keys(tokenPositions).includes(id);
  const currentUserCharacterId = turnOrder.length > 0 ? turnOrder[0] : null;
  const isCurrentUserTurn = characters.some(
    character => character.id === currentUserCharacterId && character.userId === userId());
  const currentCharacterTurn = turnOrder.length > 0 ?
    characters.find(character => character.id === turnOrder[0]) : null;
  const { sendNotification } = useNotification();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Item | null>(null);

  const openModal = (item: Item): void => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const closeModal = (): void => {
    setIsModalOpen(false);
  };

  const handleCharacterSelect = (character: Character): void => {
    setIsModalOpen(false);
    if (selectedItem && character) {
      handleUseItem(selectedItem, character);
    }
  };

  const usableItemsWhenNoEnemies = [
    'Potion',
    'Potion+',
    'Potion X',
    'Éther',
    'Éther +',
    'Éther X'
  ];

  const handleUseItem = (item: Item, character: Character): void => {
    const characterId = character.id;

    if (characterId) {
      const characterIndex = characters.findIndex((c) => c.id === characterId);

      if (characterIndex !== -1 && currentCharacterTurn) {
        if (enemiesGenerated && currentTurn > 0) {
          const updatedTokenPositions = {
            ...tokenPositions,
            [currentCharacterTurn.id]: {
              ...tokenPositions[currentCharacterTurn.id],
              hasUsedItem: true
            }
          };
          handleSetTokenPositions(updatedTokenPositions);
        }

        let message = `${currentCharacterTurn?.name} utilise ${item.name} sur ${character.name}`;

        switch (item.name) {
          case 'Potion':
            const newHealth = character.currentHealth + 5;
            message += ' et se soigne de 5 points de vie';
            updateCharacter(characterIndex, 'currentHealth', Math.min(newHealth, character.maxHealth));
            break;
          case 'Potion+':
            const newHealthPlus = character.currentHealth + Math.floor(character.maxHealth * 0.5);
            message += ` et se soigne ${Math.min(newHealthPlus, character.maxHealth)}`;
            updateCharacter(characterIndex, 'currentHealth', Math.min(newHealthPlus, character.maxHealth));
            break;
          case 'Potion X':
            message += ` et restaure sa santé à ${character.maxHealth}`;
            updateCharacter(characterIndex, 'currentHealth', character.maxHealth);
            break;
          case 'Éther':
            const newMana = character.currentMana + 3;
            message += ` et récupère ${Math.min(newMana, character.maxMana)} points de mana`;
            updateCharacter(characterIndex, 'currentMana', Math.min(newMana, character.maxMana));
            break;
          case 'Éther +':
            const newManaPlus = character.currentMana + 6;
            message += ` et récupère ${Math.min(newManaPlus, character.maxMana)} points de mana`;
            updateCharacter(characterIndex, 'currentMana', Math.min(newManaPlus, character.maxMana));
            break;
          case 'Éther X':
            message += ` et restaure son mana à ${character.maxMana}`;
            updateCharacter(characterIndex, 'currentMana', character.maxMana);
            break;
          case 'Élixir':
            message += ' et restaure entièrement son mana et sa vie';
            updateCharacter(characterIndex, 'currentMana', character.maxMana);
            updateCharacter(characterIndex, 'currentHealth', character.maxHealth);
            break;
          case 'Antidote universel':
            const statusIndex = character.status.indexOf('Poison');
            if (statusIndex !== -1) {
              character.status.splice(statusIndex, 1);
              message += ' et se soigne des empoisonnements';
            }
            updateCharacter(characterIndex, 'status', character.status);
            break;
          case 'Corde Sortie':
            resetTurns();
            setEnemiesGenerated(false);

            if (isPreBattlePlacementAllowed) {
              handlePreBattlePlacementToggle();
              handleEnemiesGeneratedToggle();
            }
            handleSetTokenPositions({});
            message += ' et le groupe décide de fuir le combat, montrant ainsi leur lâcheté';
            break;
          case 'Sérum':
            message += ' et se soigne de tous les effets néfastes';
            updateCharacter(characterIndex, 'status', []);
            break;
          case 'Queue de phénix':
            message += ' et le ramène à la vie';
            updateCharacter(characterIndex, 'isDead', false);
            let newTurnOrder = [...turnOrder, characterId];

            const sortedCharacters = characters
              .filter(character => !character.isDead)
              .sort((a, b) => b.creationDate - a.creationDate)
              .map(character => character.id);

            newTurnOrder = newTurnOrder.filter(id => sortedCharacters.includes(id));

            const currentIndex = newTurnOrder.indexOf(currentUserCharacterId ?? '');
            if (currentIndex > 0) {
              [newTurnOrder[0], newTurnOrder[currentIndex]] = [newTurnOrder[currentIndex], newTurnOrder[0]];
            }
            break;
          default:
            break;
        }

        sendNotification(message, 'info');
        removeFromInventory(item);
      }
    }
  };


  const generateSummaryList = (weapon: Weapon | null): JSX.Element => {
    let liste = '';
    if (weapon) {
      liste += `Nom : ${weapon.name}\n`;
      liste += `Type : ${weapon.type}\n`;
      liste += `Stats principale : ${weapon.mainStat} (${weapon.weaponStat})\n`;
      if (weapon.subStat !== null) {
        liste += `Stats secondaire : ${weapon.subStat} (${weapon.weaponSubStat})\n`;
      }
      liste += `Portée : ${weapon.range} cases\n`;

      if (weapon.status !== null) {
        liste += `Status : ${weapon.status}\n`;
      }

      if (weapon.element !== null) {
        liste += `Élément : ${weapon.element}\n`;
      }
    }

    return <pre style={{ fontFamily: 'inherit', whiteSpace: 'pre-wrap' }}>{liste}</pre>;
  };

  return (
    <Card
      sx={{
        position: 'relative',
        mb: 1,
        boxShadow: 'inset 0 0 0 1px rgba(255, 255, 255, 0.3)',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          right: 0,
          bottom: 0,
          left: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          zIndex: 1
        },
        backgroundImage: `url('/items/${item.name}.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <CardContent sx={{ position: 'relative', zIndex: 2 }}>
        <Box sx={{ float: 'right', display: 'flex' }}>
          {item.type === 'Arme' && (
            <Tooltip
              title={generateSummaryList(weaponsData.find(weapon => weapon.name === item.name) as unknown as Weapon)}
              enterTouchDelay={0}
              leaveTouchDelay={1000}
              sx={{ mt: 0 }}
              PopperProps={{
                modifiers: [
                  {
                    name: 'offset',
                    options: {
                      offset: [0, -10],
                    },
                  },
                ],
              }}
            >
              <InfoOutlined sx={{ cursor: 'pointer', mr: 1 }} />
            </Tooltip>
          )}
          <Chip label={item.type} size="small" color={item.type !== 'Arme' ? 'secondary' : 'info'} />
        </Box>
        <Typography variant="body1" style={{ fontFamily: 'IMFellFrenchCanonSC' }}>
          {item.name}
          {item.type !== 'Arme' && count && <Chip label={`x${count}`} sx={{ ml: 1 }} color='info' size="small" />}
        </Typography>
        <Typography variant="body2" sx={{ fontStyle: 'italic', mt: 2 }}>{item.effect}</Typography>
      </CardContent>
      <CardActions sx={{ position: 'relative', display: 'flex', justifyContent: 'space-between', zIndex: 2 }}>
        {actionLabel === 'inventory' && item.type !== 'Arme' && (
          <Button
            variant="outlined"
            disabled={
              !(item.name === 'Queue de phénix' &&
                characters.some(character => character.userId === userId() && !character.isDead) &&
                characters.some(character => character.isDead)) && (
                !usableItemsWhenNoEnemies.includes(item.name) &&
                !((item.name === 'Corde Sortie' && enemiesGenerated) ||
                  (item.name === 'Repousse' && !enemiesGenerated)) && (
                  !isCharacterPlaced(currentUserCharacterId ?? '') ||
                  !isCurrentUserTurn ||
                  tokenPositions[currentUserCharacterId ?? '']?.hasUsedItem ||
                  tokenPositions[currentUserCharacterId ?? '']?.hasAttacked ||
                  tokenPositions[currentUserCharacterId ?? '']?.hasUsedSpell
                )
              )
            }
            size='small'
            color='info'
            onClick={() => openModal(item)}
            sx={{
              ml: 1,
              mb: 1
            }}
          >
            Utiliser
          </Button>
        )}
        {actionLabel === 'merchant' && (
          <Chip label={`${item.purchasePrice} Or`} size='small' />
        )}
        {assignedTo ? (
          <Typography ml={1} variant="caption" sx={{ fontStyle: 'italic' }}>
            Assigné à {assignedTo}
          </Typography>
        ) : (
          <div style={{ flexGrow: 1 }} />
        )}
        {actionLabel === 'merchant' ? (
          <Button
            disabled={isCharacterPlaced(currentUserCharacterId ?? '') || gameInfo.battleMapAvailable}
            variant="outlined"
            onClick={onActionClick}
            size='small'
            sx={{
              mr: 1
            }}
          >
            Acheter
          </Button>
        ) : (
          <Button
            variant="outlined"
            color='error'
            onClick={onActionClick}
            size='small'
            sx={{
              mr: 1
            }}
          >
            Vendre
          </Button>
        )}
      </CardActions>
      <Modal open={isModalOpen} onClose={closeModal}>
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            bgcolor: 'background.paper',
            border: '2px solid #000',
            boxShadow: 24,
            p: 4,
          }}
        >
          <Typography variant="h5" mb={3}>Choisissez un personnage</Typography>
          <Grid container spacing={2} justifyContent="center">
            {characters.map((character) => (
              <Grid key={character.id}>

                <Button
                  key={character.id}
                  variant='outlined'
                  sx={{ m: 1 }}
                  onClick={() => handleCharacterSelect(character)}>
                  {character.name}
                </Button>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Modal>
    </Card >
  );
}

export default memo(ItemCard);