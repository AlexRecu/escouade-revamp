import React from 'react';
import type { SelectChangeEvent } from '@mui/material';
import {
  Unstable_Grid2 as Grid,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  InputAdornment,
  IconButton
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { listType } from '@utils/const';
import type { ItemListSearchBarProps } from '@interfaces/types';

/**
 * React component for displaying a search bar and filter options for an item list.
 *
 * @param {ItemListSearchBarProps} props - The props for the component.
 * @param {string} props.searchTerm - The current search term.
 * @param {Function} props.setSearchTerm - Function to set the search term.
 * @param {string[]} props.filterType - The current filter type(s).
 * @param {Function} props.setFilterType - Function to set the filter type(s).
 * @param {Function} props.setCurrentPage - Function to set the current page.
 * @returns {JSX.Element} A React JSX element representing the ItemListSearchBar.
 */
function ItemListSearchBar(
  { searchTerm, setSearchTerm, filterType, setFilterType, setCurrentPage }: ItemListSearchBarProps
): JSX.Element {
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
    setSearchTerm(event.target.value);
    setCurrentPage(1);
  };

  const handleFilterChange = (event: SelectChangeEvent<string[]>): void => {
    setFilterType(event.target.value as string[]);
    setCurrentPage(1);
  };

  const handleClearFilter = (): void => {
    setFilterType([]);
  };

  const renderSelectedTypes = (selected: string[]): string => selected.join(', ');

  return (
    <Grid container spacing={1} alignItems="center" sx={{ mb: 2 }}>
      <Grid xs={12} sm={6} lg={4} xl={3}>
        <TextField
          label="Rechercher"
          variant="outlined"
          fullWidth
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </Grid>
      <Grid xs={12} sm={6} lg={4} xl={3}>
        <FormControl fullWidth>
          <InputLabel>Type</InputLabel>
          <Select
            multiple
            value={filterType}
            label="Type"
            onChange={handleFilterChange}
            renderValue={renderSelectedTypes}
            endAdornment={
              filterType.length > 0 && (
                <InputAdornment position="end" sx={{ mr: 1 }}>
                  <IconButton onClick={handleClearFilter}>
                    <CloseIcon />
                  </IconButton>
                </InputAdornment>
              )
            }
          >
            {listType.map((type) => (
              <MenuItem key={type} value={type}>
                {type}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Grid>
    </Grid>
  );
}

export default ItemListSearchBar;