import { Pagination } from '@mui/material';
import { Masonry } from '@mui/lab';
import type { ItemListProps } from '@interfaces/types';
import type { ChangeEvent } from 'react';

import ItemCard from './ItemCard';

/**
 * React component for displaying a list of items with pagination and item cards.
 *
 * @param {ItemListProps} props - The props for the component.
 * @param {Item[]} props.items - The array of items to display.
 * @param {number} props.currentPage - The current page of items.
 * @param {number} props.itemsPerPage - The number of items to display per page.
 * @param {Function} props.setCurrentPage - Function to set the current page.
 * @param {Function} props.onItemAction - Function to handle item action button click events.
 * @param {string} props.actionLabel - The label for the item action button (e.g., "add" or "remove").
 * @returns {JSX.Element} A React JSX element representing the ItemList.
 */
function ItemList({
  items,
  currentPage,
  itemsPerPage,
  setCurrentPage,
  onItemAction,
  actionLabel
}: ItemListProps): JSX.Element {

  const paginatedItems = items.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const handlePageChange = (_event: ChangeEvent<unknown>, page: number): void => {
    setCurrentPage(page);
  };

  return (
    <>
      <Pagination
        count={Math.ceil(items.length / itemsPerPage)}
        page={currentPage}
        onChange={handlePageChange}
        color="primary"
        sx={{ mb: 2, justifyContent: { xs: 'center', md: 'left' }, display: 'flex' }}
      />
      <Masonry columns={{ xs: 1, sm: 2, md: 3, lg: 4, xl: 5 }}>
        {paginatedItems.map((item) => (
          <ItemCard
            key={`${item.name}-${item.id}`}
            item={item}
            onActionClick={onItemAction(item)}
            actionLabel={actionLabel}
            assignedTo={item.assignedTo}
            count={item.count}
          />
        ))}
      </Masonry>
    </>
  );
}

export default ItemList;