/* eslint-disable complexity */
/* eslint-disable @typescript-eslint/no-unnecessary-condition */
import type { DraggableCharacterTokenProps } from '@interfaces/types';
import { useBattle } from '@contexts/BattleContext';
import { userId } from '@utils/auth';
import { useState } from 'react';
import { distance } from '@utils/battle';
import weaponsData from '@data/weapons_data.json';

import CharacterToken from './CharacterToken';
import ActionMenu from './ActionMenu';

/**
 * Renders a draggable token for a character.
 * @param {DraggableCharacterTokenProps} props - The props for the DraggableCharacterToken component.
 * @param {string} props.id - The ID of the character.
 * @param {string} props.userId - The ID of the user who owns the character.
 * @param {boolean} props.isOnBoard - Indicates whether the character is on the board.
 * @param {Function} props.handleTokenSelect - The function to handle token selection.
 * @param {string | null} props.selectedToken - The ID of the selected token.
 * @returns {JSX.Element} The rendered DraggableCharacterToken component.
 */
function DraggableCharacterToken({
  id, character, isOnBoard, handleTokenSelect, selectedToken, isCurrentUserTurn, enableAttackMode, openSpell
}: DraggableCharacterTokenProps): JSX.Element {
  const { tokenPositions } = useBattle();
  const isUserToken = character.userId === userId();
  const [enemiesAdjacent, setEnemiesAdjacent] = useState(false);

  const hasMoved = tokenPositions[id]?.hasMoved ?? false;
  const hasAttacked = tokenPositions[id]?.hasAttacked ?? false;
  const hasUsedItem = tokenPositions[id]?.hasUsedItem ?? false;
  const hasUsedSpell = tokenPositions[id]?.hasUsedSpell ?? false;
  const hasWeapon = character.weapon !== '';

  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const handleTokenClick = (event: React.MouseEvent<HTMLDivElement>): void => {
    if (isUserToken && isCurrentUserTurn) {
      setAnchorEl(event.currentTarget);
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
      if (tokenPositions && tokenPositions[id]) {
        const currentTokenPosition = tokenPositions[id];
        const weapon = weaponsData.find(w => w.name === character.weapon);
        const adjacentEnemies = Object.values(tokenPositions).some(position =>
          position.id?.startsWith('enemy') && distance(position, currentTokenPosition) <= (weapon?.range ?? 0)
        );
        setEnemiesAdjacent(adjacentEnemies);
      } else {
        setEnemiesAdjacent(false);
      }
    }
  };

  const handleClose = (): void => {
    setAnchorEl(null);
  };

  const handleMoveSelect = (): void => {
    handleTokenSelect(id);
  };

  return (
    <div style={{ boxShadow: selectedToken === id ? '0px 0px 10px 5px rgba(0,0,0,0.5)' : 'none', lineHeight: 0 }}>
      <div onClick={handleTokenClick}>
        <CharacterToken id={id} isOnBoard={isOnBoard} />
      </div>
      {isUserToken && isCurrentUserTurn && (
        <ActionMenu
          onMoveSelect={handleMoveSelect}
          onAttackSelect={enableAttackMode}
          onSpellSelect={openSpell}
          disableMove={hasMoved}
          disableAttack={hasWeapon && !hasAttacked && !hasUsedItem && !hasUsedSpell}
          disableSpell={!hasAttacked && !hasUsedItem && !hasUsedSpell}
          enemiesAdjacent={enemiesAdjacent}
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleClose}
        />
      )}
    </div>
  );
}

export default DraggableCharacterToken;