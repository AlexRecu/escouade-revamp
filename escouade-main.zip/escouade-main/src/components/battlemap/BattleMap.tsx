/* eslint-disable no-case-declarations */
/* eslint-disable @typescript-eslint/no-unnecessary-condition */
/* eslint-disable complexity */
import { useCallback, useEffect, useState } from 'react';
import { useCharacters } from '@contexts/CharacterContext';
import { useBattle } from '@contexts/BattleContext';
import { useGameInfo } from '@contexts/GameInfoContext';
import { useNotification } from '@contexts/NotificationContext';
import type { SelectChangeEvent } from '@mui/material';
import {
  Unstable_Grid2 as Grid,
  Box,
  Stack,
  Button,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  IconButton,
  Typography,
  Tooltip,
  Modal,
  useTheme,
} from '@mui/material';
import { isUserAuthorized, userId } from '@utils/auth';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import spellsData from '@data/spells_data.json';
import bestiaryData from '@data/bestiary_data.json';
import weaponsData from '@data/weapons_data.json';
import type { Classes, Creature, Spell, SpellLevel, TokenPosition } from '@interfaces/interfaces';
import type { SpellDetail, ValidPositions, Zones } from '@interfaces/types';
import {
  distance,
  findShortestPath,
  getRandomCreatures,
  isAdjacent
} from '@utils/battle';
import {
  commonAttack,
  attackGobelin,
  generateNewCreature,
  attackVautour,
  attackOursElastique,
  attackBombo,
  calculateDamageMultiplier,
  selectRandomTrashTalk,
  attackMageGobelin,
  attackAhriman,
  attackChimere,
  attackDragonRouge,
  attackDragonBleu,
  attackDragonGlace,
  attackCoeurl,
  attackDragonnet,
  attackGriffon,
  attackBruleur,
  attackDullahan,
  attackChevalierMortVivant,
  attackYeti,
  attackTroll
} from '@utils/attack';
import classesData from '@data/classes_data.json';
import levelsData from '@data/level_data.json';
import { calculateNewXpAndLevel } from '@utils/calculs';

import DraggableCharacterToken from './DraggableCharacterToken';
import RenderBoard from './RenderBoard';

/**
 * 
 * @returns 
 */
function BattleMap(): JSX.Element {
  const theme = useTheme();
  const { characters, updateCharacter } = useCharacters();
  const {
    tokenPositions,
    handleSetTokenPositions,
    currentTurn,
    advanceTurn,
    resetTurns,
    isPreBattlePlacementAllowed,
    handlePreBattlePlacementToggle,
    handleEnemiesGeneratedToggle,
    enemiesGenerated,
    setEnemiesGenerated,
    advanceTurnOrder,
    turnOrder
  } = useBattle();
  const { gameInfo, updateGameInfo } = useGameInfo();
  const [selectedToken, setSelectedToken] = useState<string | null>(null);
  const [validMovePositions, setValidMovePositions] = useState<ValidPositions>({});
  const [validAttackPositions, setValidAttackPositions] = useState<ValidPositions>({});
  const [validSpellAttackPositions, setValidSpellAttackPositions] = useState<ValidPositions>({});
  const isCharacterPlaced = (id: string): boolean => Object.keys(tokenPositions).includes(id);
  const currentUserCharacterId = turnOrder.length > 0 ? turnOrder[0] : null;
  const isCurrentUserTurn = characters.some(
    character => character.id === currentUserCharacterId && character.userId === userId());
  const currentCharacterTurn = turnOrder.length > 0 ?
    characters.find(character => character.id === turnOrder[0]) : null;
  const [selectedZone, setSelectedZone] = useState<Zones>('forest');
  const [numberOfEnemies, setNumberOfEnemies] = useState<number>(1);
  const [allCharactersOnBoard, setAllCharactersOnBoard] = useState<boolean>(false);
  const [allCharactersDead, setAllCharactersDead] = useState(false);
  const { sendNotification } = useNotification();
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [lastClickedPosition, setLastClickedPosition] = useState<string | null>(null);
  const [attackMode, setAttackMode] = useState(false);
  const [spellMode, setSpellMode] = useState(false);
  const [spellDetail, setSpellDetail] = useState<SpellDetail | null>(null);
  const [isSpellModalOpen, setIsSpellModalOpen] = useState(false);
  const [showVictoryMessage, setShowVictoryMessage] = useState(false);

  const getAvailableSpellsForCurrentCharacter = (classOfCharacter: string, characterLevel: number): SpellLevel => {
    const classInfo = classesData[classOfCharacter as keyof Classes];
    if (!classInfo) {
      return {};
    }

    const availableSpells: SpellLevel = {};
    Object.entries(classInfo.spells).forEach(([spell, levelRequired]) => {
      if (characterLevel >= levelRequired) {
        availableSpells[spell] = levelRequired;
      }
    });

    return availableSpells;
  };

  const availableSpells = getAvailableSpellsForCurrentCharacter(currentCharacterTurn?.classe ?? '', gameInfo.level);

  const enableAttackMode = (): void => {
    setAttackMode(true);
    if (currentUserCharacterId) {
      const characterPosition = tokenPositions[currentUserCharacterId];
      const characterWeaponName = currentCharacterTurn?.weapon;
      const characterWeapon = weaponsData.find(weapon => weapon.name === characterWeaponName);
      const weaponRange = characterWeapon?.range || 0;

      const validAttackPositions: { [key: string]: boolean } = {};
      Object.entries(tokenPositions).forEach(([key, pos]) => {
        if (key.startsWith('enemy') && distance(characterPosition, pos) <= weaponRange) {
          validAttackPositions[`${pos.row}-${pos.col}`] = true;
        }
      });
      setValidAttackPositions(validAttackPositions);
    }
  };

  const enableSpellMode = (spell: Spell, characterId: string): void => {
    setSpellMode(true);
    setSpellDetail({ spell: spell, characterId: characterId });
    if (currentUserCharacterId) {
      const validAttackPositions: { [key: string]: boolean } = {};
      Object.entries(tokenPositions).forEach(([key, pos]) => {
        if (spell.target === 'enemy' && key.startsWith('enemy')) {
          validAttackPositions[`${pos.row}-${pos.col}`] = true;
        } else if (spell.target === 'ally' && !key.startsWith('enemy')) {
          validAttackPositions[`${pos.row}-${pos.col}`] = true;
        }
      });
      setValidSpellAttackPositions(validAttackPositions);
    }
    closeModal();
  };

  const openSpell = (): void => {
    setIsSpellModalOpen(true);
  };

  const closeModal = (): void => {
    setIsSpellModalOpen(false);
  };

  const performSpellAttack = (characterId: string, enemyId: string, spell: Spell): void => {
    if (currentCharacterTurn) {
      const updatedCharacters = [...characters];
      const characterIndex = updatedCharacters.findIndex(c => c.id === characterId);
      updateCharacter(characterIndex, 'currentMana', currentCharacterTurn?.currentMana - spell.cost);
      const roll = Math.floor(Math.random() * 6) + 1;
      const target = tokenPositions[enemyId];
      const creature = bestiaryData.find(c => c.name === target.creatureName) as Creature;
      const message = `${currentCharacterTurn.name} lance ${spell.name} sur ${target.creatureName}`;
      if (currentCharacterTurn && roll > 1) {
        if (roll >= (spell.power - currentCharacterTurn.stats.intelligence)) {
          if (target.creatureName) {
            let damage = 0;
            const critThreshold = 6;
            damage += (spell.power + currentCharacterTurn.stats.intelligence) *
              calculateDamageMultiplier(spell.element, creature);

            if (roll >= critThreshold) {
              const critRoll = Math.floor(Math.random() * 6) + 1;
              damage += (5 + critRoll) * calculateDamageMultiplier(spell.element, creature);
            }
            sendNotification(message, 'info');
            handleEnemyDamage(damage, enemyId, creature);
          } else {
            alert('Vous ciblez un allié enculé');
          }
        } else {
          sendNotification(`${message} mais n'a pas compris sa description`, 'error');
        }
      } else {
        sendNotification(`${currentCharacterTurn.name} n'a pas trouvé le quai 9 3/4`, 'error');
      }
      if (currentUserCharacterId) {
        const newTokenPositions = {
          ...tokenPositions,
          [currentUserCharacterId]: { ...tokenPositions[currentUserCharacterId], hasUsedSpell: true }
        };
        handleSetTokenPositions(newTokenPositions);
      }
      setSpellMode(false);
      setValidSpellAttackPositions({});
    }
  };

  const performAttack = (enemyId: string): void => {
    const weapon = weaponsData.find(weapon => weapon.name === currentCharacterTurn?.weapon);
    let characterMainStatValue = 0;
    let characterSubStatValue = 0;
    const critThreshold = weapon?.status === 'Crit+' ? 5 : 6;

    if (weapon) {
      switch (weapon.mainStat) {
        case 'Force':
          characterMainStatValue = currentCharacterTurn?.stats.strength ?? 0;
          characterSubStatValue = currentCharacterTurn?.stats.dexterity ?? 0;
          break;
        case 'Dextérité':
          characterMainStatValue = currentCharacterTurn?.stats.dexterity ?? 0;
          characterSubStatValue = currentCharacterTurn?.stats.strength ?? 0;
          break;
      }

      const roll = weapon.status === 'No roll' ? 6 : Math.floor(Math.random() * 6) + 1;
      const result = (characterMainStatValue + roll) - weapon.weaponStat;
      const { creatureName } = tokenPositions[enemyId];
      const creature = bestiaryData.find(c => c.name === creatureName) as Creature;

      if (roll === 1) {
        sendNotification(selectRandomTrashTalk(currentCharacterTurn?.name ?? ''), 'error');
      } else if (result >= 0) {
        let damage = 0;
        if (roll >= (weapon.weaponStat - characterMainStatValue)) {
          damage += (characterMainStatValue + roll) * weapon.weaponStat *
            calculateDamageMultiplier(weapon.element as string, creature);

          if (roll >= (weapon.weaponStat - characterSubStatValue)) {
            damage += weapon.weaponSubStat * characterSubStatValue;
          }

          if (roll >= critThreshold) {
            damage += 5 + (Math.floor(Math.random() * 6) + 1);
          }

          damage = damage * calculateDamageMultiplier(weapon.element as string, creature);

          if (['Morphée', 'Poison'].includes(weapon.status ?? '') && Math.random() < 0.3) {
            handleEnemyDamage(damage, enemyId, creature, weapon.status ?? '');
          } else if (weapon.status === 'Argent+') {
            handleEnemyDamage(damage, enemyId, creature, weapon.status);
          } else {
            handleEnemyDamage(damage, enemyId, creature);
          }
        }
      } else {
        sendNotification(`Vous n'avez pas réussi à toucher ${creatureName}`, 'error');
      }
      if (currentUserCharacterId) {
        const newTokenPositions = {
          ...tokenPositions,
          [currentUserCharacterId]: { ...tokenPositions[currentUserCharacterId], hasAttacked: true }
        };
        handleSetTokenPositions(newTokenPositions);
      }
      setAttackMode(false);
      setValidAttackPositions({});
    }
  };

  const handleEnemyDamage = (damage: number, enemyId: string, enemy: Creature, status?: string): void => {
    const updatedTokenPositions = { ...tokenPositions };
    const enemyToken = updatedTokenPositions[enemyId];

    let message = `Vous infligez ${damage} points de dégats à ${enemy.name}`;

    if (enemyToken && enemyToken.currentHealth) {
      enemyToken.currentHealth -= damage;

      if (enemyToken.currentHealth <= 0 || enemyToken.creatureName === 'Teddy Bear') {
        let goldMultiplicator = 1;
        if (status === 'Argent+') {
          goldMultiplicator = 2;
        }
        enemyDeath(enemy, enemyId, goldMultiplicator);
      } else {
        if (enemyToken.status && status && !enemyToken.status.includes(status) && status !== 'Argent+') {
          enemyToken.status.push(status);
          message = `${message} et est maintenant affecté par ${status}`;
        }
        handleSetTokenPositions(updatedTokenPositions);

        sendNotification(message, 'error');
      }
    }
  };

  const handleZoneChange = (event: SelectChangeEvent<Zones>): void => {
    setSelectedZone(event.target.value as Zones);
  };

  const handleIncrement = (): void => {
    setNumberOfEnemies(prevCount => prevCount < 10 ? prevCount + 1 : prevCount);
  };

  const handleDecrement = (): void => {
    setNumberOfEnemies(prevCount => prevCount > 1 ? prevCount - 1 : prevCount);
  };

  const generateAndPlaceEnemies = (): void => {
    if (numberOfEnemies > 0) {
      const newEnemies = { ...tokenPositions };
      const occupiedPositions = new Set<string>();

      for (const token of Object.values(tokenPositions)) {
        const positionKey = `${token.row}-${token.col}`;
        occupiedPositions.add(positionKey);
      }

      for (let i = 0; i < numberOfEnemies; i++) {
        const creatures = getRandomCreatures(selectedZone, numberOfEnemies);
        const availablePositions = [];

        for (let row = 2; row < 8; row++) {
          for (let col = 0; col < 8; col++) {
            const positionKey = `${row}-${col}`;

            if (!occupiedPositions.has(positionKey)) {
              availablePositions.push(positionKey);
            }
          }
        }

        const randomPositionKey = availablePositions[Math.floor(Math.random() * availablePositions.length)];

        const creature = creatures[i];

        newEnemies[`enemy_${i + 1}`] = {
          id: `enemy_${i + 1}`,
          row: parseInt(randomPositionKey.split('-')[0], 10),
          col: parseInt(randomPositionKey.split('-')[1], 10),
          creatureName: creature.name,
          currentHealth: creature.pv[gameInfo.zoneLevel - 1],
          maxHealth: creature.pv[gameInfo.zoneLevel - 1],
          alreadyCall: false,
          isDead: false,
          status: []
        };

        occupiedPositions.add(randomPositionKey);
      }

      handleSetTokenPositions(newEnemies);
      setEnemiesGenerated(true);
      handleEnemiesGeneratedToggle();
      handlePreBattlePlacementToggle();
    }
  };

  const handleResetTurn = useCallback((): void => {
    resetTurns();
    setNumberOfEnemies(1);
    setEnemiesGenerated(false);
    setShowVictoryMessage(false);

    if (isPreBattlePlacementAllowed) {
      handlePreBattlePlacementToggle();
      handleEnemiesGeneratedToggle();
    }
    setAllCharactersOnBoard(false);
    setAllCharactersDead(false);
    handleSetTokenPositions({});
  }, [
    handleEnemiesGeneratedToggle,
    handlePreBattlePlacementToggle,
    handleSetTokenPositions,
    isPreBattlePlacementAllowed,
    resetTurns,
    setEnemiesGenerated
  ]);

  const handleTokenSelect = (id: string): void => {
    if (turnOrder[0] !== id) { return; }

    setSelectedToken(id);

    const validPositions: ValidPositions = {};
    if (!isCharacterPlaced(id)) {
      for (let row = 0; row < 2; row++) {
        for (let col = 0; col < 8; col++) {
          if (!Object.values(tokenPositions).some(pos => pos.row === row && pos.col === col)) {
            validPositions[`${row}-${col}`] = true;
          }
        }
      }
    } else {
      const { row, col } = tokenPositions[id];
      for (let r = row - 1; r <= row + 1; r++) {
        for (let c = col - 1; c <= col + 1; c++) {
          if (r >= 0 && r < 8 && c >= 0 && c < 8 && (r !== row || c !== col)) {
            if (!Object.values(tokenPositions).some(pos => pos.row === r && pos.col === c)) {
              validPositions[`${r}-${c}`] = true;
            }
          }
        }
      }
    }

    setValidMovePositions(validPositions);
  };

  const handleSquareClick = (row: number, col: number): void => {
    const positionKey = `${row}-${col}`;
    setLastClickedPosition(positionKey);
    if (attackMode) {
      const enemyId = Object.keys(tokenPositions).find(key => {
        const position = tokenPositions[key];

        return position.row === row && position.col === col && key.startsWith('enemy');
      });

      if (enemyId) {
        performAttack(enemyId);

        return;
      } else {
        setAttackMode(false);
        setValidAttackPositions({});
      }
    }
    if (spellMode) {
      const targetId = Object.keys(tokenPositions).find(key => {
        const position = tokenPositions[key];

        return position.row === row && position.col === col;
      });

      if (targetId && spellDetail) {
        performSpellAttack(spellDetail.characterId, targetId, spellDetail.spell);

        return;
      } else {
        setSpellMode(false);
        setValidSpellAttackPositions({});
      }
    }
    if (selectedToken && validMovePositions[positionKey]) {
      handleDrop(row, col, selectedToken);
      setSelectedToken(null);
      setValidMovePositions({});
    }
  };

  const handleDrop = (row: number, col: number, characterId: string): void => {
    const currentPosition = tokenPositions[characterId];
    const newPositionKey = `${row}-${col}`;

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (currentPosition && currentPosition.hasMoved) {
      return;
    }

    if (!validMovePositions[newPositionKey]) {
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (!currentPosition || (currentPosition && !currentPosition.hasMoved)) {
      const newTokenPosition: TokenPosition = { row, col, hasAttacked: false, hasMoved: true, turnPass: false };
      const newTokenPositions = { ...tokenPositions, [characterId]: newTokenPosition };
      handleSetTokenPositions(newTokenPositions);
      playSpellSoundIfMageBleu(characterId);
    }
  };

  const playSpellSoundIfMageBleu = (characterId: string): void => {
    const character = characters.find(c => c.id === characterId);
    if (character?.classe === 'mageBleu') {
      const randomNumber = Math.floor(Math.random() * 100) + 1;
      if (randomNumber <= 4) {
        void new Audio('/secret/wololo.mp3').play();
      }
    }
  };

  const boardElements = RenderBoard(
    tokenPositions,
    characters,
    validMovePositions,
    validAttackPositions,
    validSpellAttackPositions,
    handleSquareClick,
    isCharacterPlaced,
    handleTokenSelect,
    selectedToken,
    enableAttackMode,
    openSpell
  );

  useEffect(() => {
    if (selectedToken && lastClickedPosition && !validMovePositions[lastClickedPosition]) {
      const currentPosition = tokenPositions[selectedToken];
      const currentPositionKey = `${currentPosition.row}-${currentPosition.col}`;

      if (lastClickedPosition !== currentPositionKey) {
        setSelectedToken(null);
        setValidMovePositions({});
        setLastClickedPosition(null);
      }
    }
  }, [lastClickedPosition, selectedToken, validMovePositions, tokenPositions]);

  useEffect(() => {
    const handleClickOutside = (event: Event): void => {
      const targetElement = event.target as Element;
      if (selectedToken && !targetElement.closest('#board')) {
        setSelectedToken(null);
        setValidMovePositions({});
      }
    };

    const eventListener: EventListener = (event: Event) => {
      handleClickOutside(event);
    };

    document.addEventListener('mousedown', eventListener);

    return () => {
      document.removeEventListener('mousedown', eventListener);
    };
  }, [selectedToken]);

  useEffect(() => {
    const characterIdsOnBoard = Object.keys(tokenPositions).filter((id) => !id.includes('enemy'));

    if (characterIdsOnBoard.length > 0) {
      const hisAllCharactersOnBoard = characters.every((character) => characterIdsOnBoard.includes(character.id));

      if (hisAllCharactersOnBoard) {
        setAllCharactersOnBoard(hisAllCharactersOnBoard);
      }
    }
  }, [characters, tokenPositions]);

  useEffect(() => {
    const characterIdsOnBoard = Object.keys(tokenPositions).filter((id) => !id.includes('enemy'));

    if (characterIdsOnBoard.length > 0) {
      const hisAllCharactersOnBoard = characters.every((character) => characterIdsOnBoard.includes(character.id));

      if (hisAllCharactersOnBoard) {
        setAllCharactersOnBoard(hisAllCharactersOnBoard);
      }
    }

    if (characters.length > 0) {
      setIsDataLoaded(true);
    }
  }, [characters, tokenPositions]);

  useEffect(() => {
    if (isDataLoaded) {
      const allDead = characters.every(character => character.isDead);
      setAllCharactersDead(allDead);

      characters.forEach(character => {
        if (character.isDead && tokenPositions[character.id]) {
          const updatedTokenPositions = { ...tokenPositions };
          delete updatedTokenPositions[character.id];
          handleSetTokenPositions(updatedTokenPositions);
        }
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [characters, isDataLoaded]);

  useEffect(() => {
    const allEnemiesDead = Object.entries(tokenPositions).every(([key, value]) =>
      !key.startsWith('enemy') || value.isDead);

    if (allEnemiesDead && enemiesGenerated) {
      setShowVictoryMessage(true);
    }
  }, [enemiesGenerated, tokenPositions]);

  useEffect(() => {
    let timer: string | number | NodeJS.Timeout | undefined;
    if (showVictoryMessage) {
      timer = setTimeout(() => {
        handleResetTurn();
        setShowVictoryMessage(false);
      }, 4000);
    }

    return () => clearTimeout(timer);
  }, [showVictoryMessage, handleResetTurn]);

  const enemyDeath = useCallback((enemy: Creature, enemyId: string, goldMultiplicator: number = 1): void => {
    const updatedTokenPositions = { ...tokenPositions };
    const enemyToken = updatedTokenPositions[enemyId];
    if (enemyToken) {
      enemyToken.isDead = true;
      enemyToken.col = 100;
      enemyToken.row = 100;
      handleSetTokenPositions(updatedTokenPositions);

      const xpGained = enemy.xp[gameInfo.zoneLevel - 1];
      const goldGained = enemy.gold[gameInfo.zoneLevel - 1];

      const { newLevel, newTotalXp, levelIncreased } =
        calculateNewXpAndLevel(gameInfo.xp, xpGained, gameInfo.level, levelsData[levelsData.length - 1].level);

      void updateGameInfo({
        ...gameInfo,
        level: newLevel,
        xp: newTotalXp,
        gold: gameInfo.gold + (goldGained * goldMultiplicator)
      });

      if (enemy.name === 'Teddy Bear') {
        sendNotification(
          `${enemy.name} vous donne ${xpGained} points d'expérience et ${goldGained} pièces d'or, 
          heureux d'avoir reçu un câlin avant de s'en aller.`,
          'info'
        );
      } else {
        sendNotification(
          `${enemy.name} succombe et vous gagnez ${xpGained} d'expériences et ${goldGained} d'or.`,
          'info'
        );
      }

      if (levelIncreased) {
        sendNotification(`Félicitations ! Vous avez atteint le niveau ${newLevel} !`, 'success');
      }
    }
  }, [gameInfo, handleSetTokenPositions, sendNotification, tokenPositions, updateGameInfo]);

  useEffect(() => {
    const updatedTokenPositions = { ...tokenPositions };
    Object.entries(tokenPositions).forEach(([id, token]) => {
      if (id.startsWith('enemy') && token.status?.includes('Morphée')) {
        sendNotification(`${token.creatureName} n'est plus paralysé !`, 'info');
        updatedTokenPositions[id] = {
          ...token,
          status: token.status.filter(status => status !== 'Morphée')
        };
        handleSetTokenPositions(updatedTokenPositions);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTurn]);

  const playSpellSoundIfExplosion = (): void => {
    const randomNumber = Math.floor(Math.random() * 100) + 1;
    if (randomNumber <= 50) {
      void new Audio('/assets/secret/alexandre-explosion.mp3').play();
    } else {
      void new Audio('/assets/secret/megumin-explosion.mp3').play();
    }
  };

  const performEnemyAttack = useCallback(
    (enemy: Creature,
      characterId: string,
      attackName: string,
      options?: {
        status?: { name: string; chance: number };
        damage?: number;
        enemyId?: string;
      }) => {
      const updatedCharacters = [...characters];
      const characterIndex = updatedCharacters.findIndex(c => c.id === characterId);

      if (characterIndex >= 0) {
        const character = updatedCharacters[characterIndex];
        let attackDamage = options?.damage ?? enemy.atk[gameInfo.zoneLevel - 1];

        if (['Loup', 'Ours élastique', 'Lézard ailé'].includes(enemy.name) && attackName === 'Morsure') {
          attackDamage = enemy.atk[gameInfo.zoneLevel - 1] * 2;
        } else if (attackName === 'Souffle gelé') {
          attackDamage = character.maxHealth * 0.2;
        } else if (attackName === 'Souffle putride') {
          attackDamage = character.maxHealth * 0.18;
          if (character.status.includes('Poison')) {
            attackDamage *= 2;
          }
        }

        character.currentHealth -= attackDamage;

        let death = false;
        let message = `${enemy.name} attaque ${character.name} avec ${attackName} 
        et prend ${attackDamage} de dégâts`;

        if (character.currentHealth <= 0) {
          character.isDead = true;
          delete tokenPositions[characterId];
        } else {
          if (options?.status && !character.status.some(statusCharacter => statusCharacter === options.status?.name)) {
            if (Math.random() < options.status.chance / 100) {
              if (options.status.name === 'Mort') {
                character.isDead = true;
                delete tokenPositions[characterId];
                message = `${enemy.name} a montré à ${character.name} 
                que les Reliques de la Mort existent bel et bien.`;
                death = true;
              } else {
                character.status.push(options.status.name);
                message = `${message} et est affecté par ${options.status.name}`;
              }
            }
          }
        }

        if (options?.enemyId && attackName === 'Explosion') {
          enemyDeath(enemy, options?.enemyId);
          playSpellSoundIfExplosion();
        }

        sendNotification(message, death ? 'error' : 'warning');

        if (options && options.status && options.status.name === 'Mort') {
          updateCharacter(
            characterIndex, 'currentHealth', character.currentHealth, attackName, options.status.name
          );
        } else {
          updateCharacter(
            characterIndex, 'currentHealth', character.currentHealth, attackName
          );
        }
      }
    }, [characters, enemyDeath, gameInfo.zoneLevel, sendNotification, tokenPositions, updateCharacter]);

  const enemyTurn = useCallback(async (): Promise<void> => {
    if (currentTurn > 0) {
      characters.forEach((character, index) => {
        const paralysisIndex = character.status.findIndex(status => status === 'Paralysie');
        if (paralysisIndex >= 0) {
          character.status.splice(paralysisIndex, 1);
          sendNotification(`${character.name} n'est plus paralysé !`, 'info');
          updateCharacter(index, 'status', character.status);
        }
      });

      const updatedPositions = { ...tokenPositions };

      const enemyData = Object.entries(updatedPositions)
        .filter(([id, value]) => id.startsWith('enemy') && !value.isDead)
        .map(([id, value]) => {
          const creatureData = bestiaryData.find(creature => creature.name === value.creatureName);

          return { id, ...value, ...creatureData };
        });

      for (const enemy of enemyData) {
        if (enemy.status && enemy.status.includes('Morphée')) {
          sendNotification(`${enemy.name} est paralysé et passe son tour`, 'info');
          continue;
        } else {
          if (enemy.type === 'Physique') {
            let nearestCharacter = null;
            let minDistance = Infinity;
            let nearestCharacterId = null;

            Object.entries(updatedPositions).forEach(([id, position]) => {
              if (!id.startsWith('enemy')) {
                const character = characters.find(c => c.id === id);
                if (character && !character.isDead) {
                  const dist = distance(position, enemy);
                  if (dist < minDistance) {
                    minDistance = dist;
                    nearestCharacter = position;
                    nearestCharacterId = id;
                  }
                }
              }
            });

            if (nearestCharacter && nearestCharacterId) {
              if (!isAdjacent(enemy, nearestCharacter)) {
                const path = findShortestPath(enemy, nearestCharacter, updatedPositions);
                if (path.length > 0) {
                  const nextStep = path[0];
                  updatedPositions[enemy.id] = {
                    ...updatedPositions[enemy.id],
                    row: nextStep.row,
                    col: nextStep.col
                  };
                }
              }
              handleSetTokenPositions(updatedPositions);
              const updatedEnemyPosition = updatedPositions[enemy.id];

              await new Promise(resolve => setTimeout(resolve, 500));

              switch (enemy.name) {
                case 'Frelon':
                case 'Veuve noire':
                case 'Loup':
                case 'Bandit':
                case 'Lézard ailé':
                case 'Géant de fer':
                case 'Dragon squelette':
                  if (updatedEnemyPosition.currentHealth &&
                    updatedEnemyPosition.maxHealth &&
                    updatedEnemyPosition.currentHealth <
                    (updatedEnemyPosition.maxHealth / 3) &&
                    !updatedEnemyPosition.alreadyCall &&
                    ['Loup', 'Bandit'].includes(enemy.name)) {
                    const newCreaturePosition = generateNewCreature(enemy.name, tokenPositions, gameInfo.zoneLevel - 1);
                    if (newCreaturePosition !== null) {
                      sendNotification(`${enemy.name} fait un coup de bigot à une proximité.`, 'info');
                      const newEnemyKey = `enemy_${Object.keys(updatedPositions).filter(
                        key => key.startsWith('enemy')).length + 1}`;
                      updatedEnemyPosition.alreadyCall = true;
                      newCreaturePosition.id = newEnemyKey;
                      const newTokenPositions = { ...updatedPositions, [newEnemyKey]: newCreaturePosition };
                      handleSetTokenPositions(newTokenPositions);
                    }
                  } else {
                    commonAttack(
                      enemy as Creature,
                      updatedEnemyPosition,
                      updatedPositions,
                      nearestCharacterId,
                      performEnemyAttack
                    );
                  }
                  break;
                case 'Gobelin':
                  attackGobelin(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Vautour':
                  const newVulturePosition = attackVautour(
                    enemy as Creature,
                    updatedEnemyPosition,
                    updatedPositions,
                    characters,
                    performEnemyAttack
                  );
                  if (newVulturePosition) {
                    updatedPositions[enemy.id] = newVulturePosition;
                    handleSetTokenPositions(updatedPositions);
                  }
                  break;
                case 'Ours élastique':
                  attackOursElastique(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Coeurl':
                  attackCoeurl(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Dragonnet':
                  attackDragonnet(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Griffon':
                  attackGriffon(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Brûleur':
                  attackBruleur(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Dullahan':
                  attackDullahan(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Troll':
                  attackTroll(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  break;
                case 'Chevalier mort vivant':
                  const newChevialierPosition = attackChevalierMortVivant(
                    enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                  );
                  if (newChevialierPosition) {
                    updatedPositions[enemy.id] = newChevialierPosition;
                    handleSetTokenPositions(updatedPositions);
                  }
                  break;
              }
            }
          } else {
            const updatedEnemyPosition = updatedPositions[enemy.id];
            switch (enemy.name) {
              case 'Bombo Feu':
              case 'Bombo Glace':
              case 'Bombo Terre':
              case 'Bombo Air':
              case 'Bombo Foudre':
              case 'Cendre Bombo':
                attackBombo(
                  enemy as Creature,
                  updatedEnemyPosition,
                  updatedPositions,
                  characters,
                  performEnemyAttack
                );
                break;
              case 'Mage gobelin':
                attackMageGobelin(
                  enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                );
                break;
              case 'Ahriman':
                attackAhriman(
                  enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                );
                break;
              case 'Chimère':
                attackChimere(
                  enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                );
                break;
              case 'Dragon rouge':
                attackDragonRouge(
                  enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                );
                break;
              case 'Dragon bleu':
                attackDragonBleu(
                  enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                );
                break;
              case 'Dragon de glace':
                attackDragonGlace(
                  enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                );
                break;
              case 'Yéti':
                const newYetiPosition = attackYeti(
                  enemy as Creature, updatedEnemyPosition, updatedPositions, characters, performEnemyAttack
                );
                if (newYetiPosition) {
                  updatedPositions[enemy.id] = newYetiPosition;
                  handleSetTokenPositions(updatedPositions);
                }
                break;
              case 'Teddy Bear':
                let isCharacterAdjacent = false;

                Object.entries(updatedPositions).forEach(([id, position]) => {
                  if (!id.startsWith('enemy')) {
                    const character = characters.find(c => c.id === id);
                    if (character && !character.isDead && isAdjacent(enemy, position)) {
                      isCharacterAdjacent = true;
                    }
                  }
                });

                if (isCharacterAdjacent) {
                  handleEnemyDamage(0, enemy.id, enemy as Creature);
                } else {
                  sendNotification('Teddy Bear manque d\'amour.', 'info');
                }
                break;
            }
          }
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    }
    advanceTurn();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    currentTurn,
    characters,
    tokenPositions,
    advanceTurn,
    sendNotification,
    updateCharacter,
    handleSetTokenPositions,
    performEnemyAttack,
    gameInfo.zoneLevel
  ]);

  const handleAdvanceTurnOrder = useCallback((): void => {
    const charactersList = Object.keys(tokenPositions).filter((id) => !id.includes('enemy'));

    let characterIdForCurrentUser = null;
    for (const characterId of charactersList) {
      const character = characters.find((character) => character.id === characterId);
      if (character && character.userId === userId()) {
        characterIdForCurrentUser = characterId;
      }
    }

    if (characterIdForCurrentUser) {
      const updatedCharacter = { ...tokenPositions[characterIdForCurrentUser], turnPass: true };
      const newTokenPositions = { ...tokenPositions, [characterIdForCurrentUser]: updatedCharacter };
      handleSetTokenPositions(newTokenPositions);

      const allCharactersPassedTurn = characters.every(
        (character) => character.isDead || newTokenPositions[character.id]?.turnPass === true);
      if (allCharactersPassedTurn) {
        void enemyTurn();
      }
    }

    advanceTurnOrder();
  }, [advanceTurnOrder, characters, enemyTurn, handleSetTokenPositions, tokenPositions]);

  useEffect(() => {
    if (isCurrentUserTurn) {
      const currentCharacterId = turnOrder[0];

      const currentCharacterIndex = characters.findIndex((character) => character.id === currentCharacterId);

      if (currentCharacterIndex !== -1 && characters[currentCharacterIndex].status.includes('Paralysie')) {
        sendNotification(`${characters[currentCharacterIndex].name} est paralysé et passe son tour`, 'info');

        handleAdvanceTurnOrder();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [characters]);

  if (allCharactersDead) {
    return (
      <Typography
        variant="h6"
        color="error"
        textAlign={'center'}
        style={{
          width: '80%',
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)'
        }}
      >
        Votre équipe a succombé, malheureusement votre aventure s&apos;arrête là. La sentence de votre mort est
        irrévocable. Le monde est ravagé par le chaos à cause de votre incompétence. L&apos;enfer en a ouvert un
        nouveau cercle, vos âmes y sont envoyées dans un éternel tourment.
      </Typography>
    );
  }

  const VictoryMessage = (): JSX.Element => (
    <Box
      sx={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 2,
      }}
    >
      <Typography
        variant="h4"
        color="white"
        textAlign={'center'}
      >
        GG EASY NOOB
      </Typography>
    </Box>
  );

  return (
    <Grid container justifyContent="center" alignItems={'center'} sx={{ height: 'calc(100vh - 100px)' }}>
      <Grid xs={10} sm={8} md={6} lg={4}>
        {isPreBattlePlacementAllowed && !allCharactersOnBoard && (
          <Stack direction="row" spacing={2} justifyContent="center" sx={{ mb: 2, mt: 2 }}>
            {characters.map((character) => (
              !isCharacterPlaced(character.id) && character.currentHealth > 0 && !character.isDead && (
                <DraggableCharacterToken
                  key={character.id}
                  id={character.id}
                  character={character}
                  isOnBoard={isCharacterPlaced(character.id)}
                  handleTokenSelect={handleTokenSelect}
                  selectedToken={selectedToken ?? ''}
                  isCurrentUserTurn={isCurrentUserTurn}
                  enableAttackMode={enableAttackMode}
                  openSpell={openSpell}
                />
              )
            ))}
          </Stack>
        )}
        <Stack direction="row" spacing={1} justifyContent="center" mb={1} mt={1} alignItems={'center'}>
          <Chip
            label={`Tour: ${currentTurn}`}
            color="secondary"
          />
          <Chip
            label={`Joueur: ${currentCharacterTurn?.name}`}
            color="primary"
          />
        </Stack>
        <Box
          id="board"
          sx={{
            position: 'relative', // Assurez-vous que le parent est relatif pour la position absolue du message
            display: 'grid',
            gridTemplateColumns: 'repeat(8, 1fr)',
            gridTemplateRows: 'repeat(8, 1fr)',
            aspectRatio: '1 / 1',
            backgroundImage: `url(${gameInfo.map})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          {showVictoryMessage && <VictoryMessage />}
          {boardElements}
        </Box>
        <Grid container xs={12} mt={2} mb={2} justifyContent={'center'}>
          <Button variant="outlined"
            sx={{ m: 1 }}
            disabled={
              !isCurrentUserTurn ||
              !isCharacterPlaced(currentUserCharacterId as string) ||
              !isPreBattlePlacementAllowed ||
              (tokenPositions[currentUserCharacterId as string].turnPass === true)
            } onClick={handleAdvanceTurnOrder}>
            Passer mon tour
          </Button>
          {isUserAuthorized(userId()) && (
            <>
              {!enemiesGenerated && (
                <>
                  <FormControl sx={{ m: 1 }}>
                    <InputLabel id="zone">Zone</InputLabel>
                    <Select size='small' labelId="zone" label='Zone'
                      sx={{ width: 150 }} value={selectedZone} onChange={handleZoneChange}>
                      <MenuItem value="forest">Forêt</MenuItem>
                      <MenuItem value="cave">Grotte</MenuItem>
                      <MenuItem value="tower">Tour</MenuItem>
                      <MenuItem value="castle">Chateau</MenuItem>
                      <MenuItem value="gorge">Canyon</MenuItem>
                      <MenuItem value="frozenEarth">Terre Gelée</MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl sx={{ m: 1 }}>
                    <Stack direction="row" justifyContent={'center'}>
                      <IconButton
                        size="small"
                        onClick={handleDecrement}
                        disabled={numberOfEnemies === 1}
                      >
                        <RemoveIcon fontSize="small" />
                      </IconButton>
                      <TextField
                        label='Ennemis'
                        variant="outlined"
                        size="small"
                        value={numberOfEnemies}
                        disabled
                        sx={{
                          width: 80,
                        }}
                        inputProps={{
                          style: {
                            textAlign: 'center',
                            paddingLeft: 0,
                            paddingRight: 0
                          }
                        }}
                      />
                      <IconButton
                        disabled={numberOfEnemies === 10}
                        size="small"
                        onClick={handleIncrement}
                      >
                        <AddIcon fontSize="small" />
                      </IconButton>
                    </Stack>
                  </FormControl>
                  <Tooltip
                    title={!gameInfo.battleMapAvailable ? 'Le mode combat doit être activé pour lancer le combat.' : ''}
                    arrow
                    PopperProps={{
                      modifiers: [
                        {
                          name: 'offset',
                          options: {
                            offset: [0, -10],
                          },
                        },
                      ],
                    }}
                  >
                    <span>
                      <Button
                        sx={{ m: 1 }}
                        variant="outlined"
                        onClick={generateAndPlaceEnemies}
                        disabled={numberOfEnemies <= 0 || !gameInfo.battleMapAvailable}
                      >
                        Démarrer
                      </Button>
                    </span>
                  </Tooltip>
                </>
              )}
              <Button
                sx={{ m: 1 }}
                variant="outlined"
                onClick={handleResetTurn}
                disabled={!enemiesGenerated}>
                Réinitialiser
              </Button>
            </>
          )}
        </Grid>
      </Grid>
      <Modal
        open={isSpellModalOpen}
        onClose={closeModal}
      >
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            bgcolor: 'background.paper',
            border: '2px solid #000',
            boxShadow: 24,
            p: 4,
            [theme.breakpoints.down('sm')]: {
              width: '90%'
            }
          }}
        >
          <Typography variant="h5" mb={3} textAlign={'center'}>Magie</Typography>
          {Object.keys(availableSpells).length === 0 ? (
            <Typography>Vous ne connaissez aucune magie. Sale moldu.</Typography>
          ) : (
            <Grid container spacing={2} justifyContent="center">
              {Object.keys(availableSpells).map(spellKey => {
                const spell = spellsData.find(s => s.name === spellKey) as unknown as Spell;
                const spellActivate = (currentCharacterTurn?.currentMana &&
                  spell.cost > currentCharacterTurn?.currentMana) === true || currentCharacterTurn?.currentMana === 0;

                return spell && currentCharacterTurn ? (
                  <Grid key={spell.name}>
                    <Tooltip
                      title={spellActivate ? 'Vous n\'avez pas assez de mana' : ''}
                      arrow
                    >
                      <span>
                        <Button
                          disabled={spellActivate}
                          variant="outlined" onClick={() => enableSpellMode(spell, currentCharacterTurn?.id)}>
                          {spell.name}
                        </Button>
                      </span>
                    </Tooltip>
                  </Grid>
                ) : null;
              })}
            </Grid>
          )}
        </Box>
      </Modal>
    </Grid >
  );
}

export default BattleMap;