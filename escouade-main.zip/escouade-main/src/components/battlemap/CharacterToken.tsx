import { useCharacters } from '@contexts/CharacterContext';
import type { CharacterTokenProps } from '@interfaces/types';

/**
 * Renders a token for a character.
 * @param {CharacterTokenProps} props - The props for the CharacterToken component.
 * @param {string} props.id - The ID of the character.
 * @param {boolean} props.isOnBoard - Indicates whether the character is on the board.
 * @returns {JSX.Element} The rendered CharacterToken component.
 */
function CharacterToken({ id, isOnBoard }: CharacterTokenProps): JSX.Element {
  const { characters } = useCharacters();

  const character = characters.find(c => c.id === id);
  const className = character?.classe;

  let imageSrc = `assets/tokens/${className}.png`;
  if (character?.name === 'Flantier') {
    imageSrc = 'assets/secret/flantier.png';
  }

  return (
    <div style={{ position: 'relative', display: 'inline-block' }}>
      <img
        src={imageSrc}
        alt={`Token pour ${id}`}
        style={{
          width: isOnBoard ? '100%' : 48,
        }} />
      <div style={{ position: 'absolute', right: 0, top: 0, display: 'flex' }}>
        {character?.status.map((status, index) => (
          <img
            key={index}
            src={`assets/status/${status.toLocaleLowerCase()}.png`}
            alt={`${status}`}
            style={{
              width: 14,
              marginLeft: index > 0 ? 4 : 0,
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default CharacterToken;