import type { Character, TokenPosition } from '@interfaces/interfaces';

import RenderSquare from './RenderSquare';

/**
 * Renders the game board.
 * @param {Record<string, TokenPosition>} tokenPositions - The positions of the tokens on the board.
 * @param {Character[]} characters - The characters in the game.
 * @param {Record<string, boolean>} validMovePositions - The valid move positions on the board.
 * @param {(row: number, col: number) => void} handleSquareClick - Function to handle square click event.
 * @param {(id: string) => boolean} isCharacterPlaced - Function to check if a character is placed.
 * @param {(id: string) => void} handleTokenSelect - Function to handle token selection.
 * @param {string | null} selectedToken - The currently selected token.
 * @returns {JSX.Element[]} An array of JSX elements representing the board.
 */
function RenderBoard(
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  validMovePositions: Record<string, boolean>,
  validAttackPositions: Record<string, boolean>,
  validSpellAttackPositions: Record<string, boolean>,
  handleSquareClick: (row: number, col: number) => void,
  isCharacterPlaced: (id: string) => boolean,
  handleTokenSelect: (id: string) => void,
  selectedToken: string | null,
  enableAttackMode: () => void,
  enableSpellMode: () => void
): JSX.Element[] {
  const board = [];
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      board.push(
        RenderSquare(
          row,
          col,
          tokenPositions,
          characters,
          validMovePositions,
          validAttackPositions,
          validSpellAttackPositions,
          handleSquareClick,
          isCharacterPlaced,
          handleTokenSelect,
          selectedToken,
          enableAttackMode,
          enableSpellMode
        )
      );
    }
  }

  return board;
}

export default RenderBoard;