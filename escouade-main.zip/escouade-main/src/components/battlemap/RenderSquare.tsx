/* eslint-disable @typescript-eslint/no-unnecessary-condition */
import type { Character, TokenPosition } from '@interfaces/interfaces';

import DroppableSquare from './DroppableSquare';
import DraggableCharacterToken from './DraggableCharacterToken';
import CreatureToken from './CreatureToken';

/**
 * Renders a square on the game board.
 * @param {number} row - The row index of the square.
 * @param {number} col - The column index of the square.
 * @param {Record<string, TokenPosition>} tokenPositions - The positions of the tokens on the board.
 * @param {Character[]} characters - The characters in the game.
 * @param {Record<string, boolean>} validMovePositions - The valid move positions on the board.
 * @param {(row: number, col: number) => void} handleSquareClick - Function to handle square click event.
 * @param {(id: string) => boolean} isCharacterPlaced - Function to check if a character is placed.
 * @param {(id: string) => void} handleTokenSelect - Function to handle token selection.
 * @param {string | null} selectedToken - The currently selected token.
 * @returns {JSX.Element} The JSX element representing the square.
 */
function RenderSquare(
  row: number,
  col: number,
  tokenPositions: Record<string, TokenPosition>,
  characters: Character[],
  validMovePositions: Record<string, boolean>,
  validAttackPositions: Record<string, boolean>,
  validSpellAttackPositions: Record<string, boolean>,
  handleSquareClick: (row: number, col: number) => void,
  isCharacterPlaced: (id: string) => boolean,
  handleTokenSelect: (id: string) => void,
  selectedToken: string | null,
  enableAttackMode: () => void,
  openSpell: () => void
): JSX.Element {
  const characterId = Object.keys(tokenPositions).find(
    id => tokenPositions[id].row === row && tokenPositions[id].col === col
  );
  const character = characters.find(c => c.id === characterId);

  const creatureTokenId = Object.keys(tokenPositions)
    .find(id => id.startsWith('enemy') && tokenPositions[id].row === row && tokenPositions[id].col === col);

  const creatureToken = tokenPositions[creatureTokenId as string];

  return (
    <DroppableSquare
      key={`${row}-${col}`}
      row={row}
      col={col}
      onDrop={() => handleSquareClick(row, col)}
      validMovePositions={validMovePositions}
      validAttackPositions={validAttackPositions}
      validSpellAttackPositions={validSpellAttackPositions}
    >
      {character && !character.isDead && (
        <DraggableCharacterToken
          id={character.id}
          character={character}
          isOnBoard={isCharacterPlaced(character.id)}
          handleTokenSelect={handleTokenSelect}
          selectedToken={selectedToken ?? ''}
          isCurrentUserTurn
          enableAttackMode={enableAttackMode}
          openSpell={openSpell}
        />
      )}
      {creatureToken && creatureToken.creatureName && !creatureToken.isDead && (
        <CreatureToken
          key={`creature-${creatureToken.creatureName}`}
          creature={creatureToken}
        />
      )}
    </DroppableSquare>
  );
}

export default RenderSquare;