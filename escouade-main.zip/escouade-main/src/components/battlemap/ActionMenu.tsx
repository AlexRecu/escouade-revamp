import { useBattle } from '@contexts/BattleContext';
import type { ActionMenuProps } from '@interfaces/types';
import { Divider } from '@mui/material';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

/**
 */
function ActionMenu({
  onMoveSelect,
  onAttackSelect,
  onSpellSelect,
  disableMove,
  disableAttack,
  disableSpell,
  enemiesAdjacent,
  anchorEl,
  open,
  onClose
}: ActionMenuProps): JSX.Element {
  const { currentTurn } = useBattle();
  const handleMenuClick = (event: React.MouseEvent<HTMLLIElement>, action: () => void): void => {
    event.stopPropagation();
    action();
    onClose();
  };

  return (
    <Menu
      anchorEl={anchorEl}
      open={open}
      onClose={onClose}
    >
      <MenuItem onClick={(event) => handleMenuClick(event, onMoveSelect)}
        disabled={disableMove}>Se déplacer</MenuItem>
      <Divider />
      <MenuItem onClick={(event) => handleMenuClick(event, onAttackSelect)}
        disabled={currentTurn === 0 || !disableAttack || !enemiesAdjacent}>Attaquer</MenuItem>
      <Divider />
      <MenuItem onClick={(event) => handleMenuClick(event, onSpellSelect)}
        disabled={currentTurn === 0 || !disableSpell}>Magie</MenuItem>
    </Menu>
  );
}

export default ActionMenu;