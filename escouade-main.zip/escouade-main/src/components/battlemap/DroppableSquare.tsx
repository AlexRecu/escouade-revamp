import { Box } from '@mui/material';
import type { DroppableSquareProps } from '@interfaces/types';

/**
 * Renders a droppable square component.
 * @param {DroppableSquareProps} props - The props for the DroppableSquare component.
 * @param {number} props.row - The row index of the square.
 * @param {number} props.col - The column index of the square.
 * @param {Function} props.onDrop - The function to handle dropping on the square.
 * @param {ReactNode} props.children - The content to be rendered inside the square.
 * @param {Record<string, boolean>} props.validMovePositions - Object containing valid move positions.
 * @returns {JSX.Element} The rendered DroppableSquare component.
 */
function DroppableSquare(
  {
    row,
    col,
    onDrop,
    children,
    validMovePositions,
    validAttackPositions,
    validSpellAttackPositions
  }: DroppableSquareProps
): JSX.Element {
  const handleClick = (): void => {
    onDrop(row, col);
  };

  const isMovePosition = validMovePositions[`${row}-${col}`];
  const isAttackPosition = validAttackPositions[`${row}-${col}`];
  const isSpellAttackPosition = validSpellAttackPositions[`${row}-${col}`];

  let backgroundColor = 'transparent';
  if (isAttackPosition || isSpellAttackPosition) {
    backgroundColor = 'rgba(255, 0, 0, 0.3)';
  } else if (isMovePosition) {
    backgroundColor = 'rgba(0, 255, 0, 0.3)';
  }

  return (
    <Box onClick={handleClick} sx={{
      flexGrow: 1,
      flexBasis: '12.5%',
      border: '1px solid white',
      position: 'relative',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: backgroundColor
    }}>
      {children}
    </Box>
  );
}

export default DroppableSquare;