import type { CreatureTokenProps } from '@interfaces/types';
import { Tooltip } from '@mui/material';
import { useState } from 'react';

/**
 * Renders a token for a creature.
 * @param {CreatureTokenProps} props - The props for the CreatureToken component.
 * @param {string} props.creatureName - The name of the creature.
 * @returns {JSX.Element} The rendered CreatureToken component.
 */
function CreatureToken({ creature }: CreatureTokenProps): JSX.Element {
  const [imageSrc, setImageSrc] = useState(`assets/tokens/${creature.creatureName}.png`);

  const handleError = (): void => {
    setImageSrc('assets/tokens/default.png');
  };

  if (creature.creatureName && creature.status) {
    return (
      <Tooltip
        title={creature.creatureName}
        enterTouchDelay={0}
        leaveTouchDelay={1000}
        PopperProps={{
          modifiers: [
            {
              name: 'offset',
              options: {
                offset: [0, -10],
              },
            },
          ],
        }}
      >
        <div style={{ display: 'flex', position: 'relative' }}>
          <img
            src={imageSrc}
            alt={`Token for ${creature.creatureName}`}
            onError={handleError}
            style={{
              width: '100%',
              cursor: 'pointer'
            }}
          />
          <div style={{ position: 'absolute', right: 0, top: 0, display: 'flex' }}>
            {creature.status.map((status, index) => (
              <img
                key={index}
                src={`assets/status/${status.toLocaleLowerCase()}.png`}
                alt={`${status}`}
                style={{
                  width: 14,
                  marginLeft: index > 0 ? 4 : 0,
                }}
              />
            ))}
          </div>
        </div>
      </Tooltip>
    );
  } else {
    return <></>;
  }

}

export default CreatureToken;