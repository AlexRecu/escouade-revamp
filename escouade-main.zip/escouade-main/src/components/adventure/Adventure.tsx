import { Unstable_Grid2 as Grid, Typography } from '@mui/material';
import { useCharacters } from '@contexts/CharacterContext';

import CardCharacter from './character/CharacterCard';
import Panel from './Panel';

/**
 * Renders the main adventure component, displaying character cards and a panel.
 *
 * @returns {JSX.Element} The adventure component.
 */
function Adventure(): JSX.Element {
  const { characters } = useCharacters();

  return (
    <Grid container mt={2} justifyContent={'center'}>
      <Panel />
      {characters.length === 0 ? (
        <Typography
          variant="h6"
          color="textSecondary"
          textAlign={'center'}
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 'max-content'
          }}
        >
          Aucun personnage à afficher
        </Typography>
      ) : (
        characters.map((character, index) => (
          <Grid xs={12} sm={6} lg={4} xl={3} key={index} display={'flex'} justifyContent={'center'}>
            <CardCharacter character={character} index={index} />
          </Grid>
        ))
      )}
    </Grid>
  );
}

export default Adventure;