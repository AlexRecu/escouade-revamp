import { Box, Unstable_Grid2 as Grid, IconButton, Stack, Switch, TextField, Typography, } from '@mui/material';
import levelsData from '@data/level_data.json';
import { useEffect, useMemo, useState } from 'react';
import { useGameInfo } from '@contexts/GameInfoContext';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { isUserAuthorized, userId } from '@utils/auth';
import { calculateXpToNextLevel } from '@utils/calculs';

/**
 * 
 * @returns 
 */
function Panel(): JSX.Element {
  const { gameInfo, updateGameInfo } = useGameInfo();

  const [level, setLevel] = useState(gameInfo.level);
  const [zoneLevel, setZoneLevel] = useState(gameInfo.zoneLevel);
  const [currentXp, setCurrentXp] = useState(gameInfo.xp);
  const [gold, setGold] = useState(gameInfo.gold);

  const maxLevel = useMemo(() => levelsData[levelsData.length - 1].level, []);
  const xpToNextLevel = useMemo(() => calculateXpToNextLevel(level), [level]);

  useEffect(() => {
    setLevel(gameInfo.level);
    setCurrentXp(gameInfo.xp);
    setZoneLevel(gameInfo.zoneLevel);
  }, [gameInfo]);

  const handleLevelChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const newLevel = Math.max(1, Number(event.target.value));
    setLevel(newLevel);
    setCurrentXp(0);
    void updateGameInfo({ ...gameInfo, level: newLevel, xp: 0, zoneLevel: 1 });
  };

  const handleZoneLevelChange = (increment: number): void => {
    const newZoneLevel = Math.min(6, Math.max(1, zoneLevel + increment));
    setZoneLevel(newZoneLevel);
    void updateGameInfo({ ...gameInfo, zoneLevel: newZoneLevel });
  };

  const handleMerchantAvailableChange = (): void => {
    const newMarchantAvailable = !gameInfo.merchantAvailable;
    const newBattleMapAvailable = newMarchantAvailable === true ? false : true;
    void updateGameInfo(
      { ...gameInfo, merchantAvailable: newMarchantAvailable, battleMapAvailable: newBattleMapAvailable });
  };

  const handleBattleMapAvailableChange = (): void => {
    const newBattleMapAvailable = !gameInfo.battleMapAvailable;
    const newmerchantAvailable = newBattleMapAvailable === true ? false : true;
    void updateGameInfo(
      { ...gameInfo, battleMapAvailable: newBattleMapAvailable, merchantAvailable: newmerchantAvailable });
  };

  useEffect(() => {
    setGold(gameInfo.gold);
  }, [gameInfo.gold]);

  return (
    <Grid container justifyContent={'center'} xs={10} mb={1}>
      <Grid container xs={12} md={12} lg={8} xl={6} rowSpacing={2}>
        <Grid xs={4} sm={3} md={2}>
          <Stack alignItems={'center'}>
            <Typography textAlign={'center'} variant="body2" mb={1}>Niveau</Typography>
            <TextField
              value={level}
              onChange={handleLevelChange}
              variant="outlined"
              size="small"
              disabled
              sx={{
                width: '40px',
              }}
              inputProps={{
                style: {
                  textAlign: 'center',
                  paddingRight: 1,
                  paddingLeft: 1
                }
              }}
            />
          </Stack>
        </Grid>
        <Grid xs={4} sm={3} md={2} justifyContent={'center'}>
          <Stack alignItems={'center'}>
            <Typography textAlign={'center'} variant="body2" mb={1}>Expérience</Typography>
            <Box display={'flex'}>
              <TextField
                value={level >= maxLevel ? 'Niv. max' : `${currentXp} / ${xpToNextLevel}`}
                variant="outlined"
                size='small'
                disabled
                sx={{
                  width: 100
                }}
                inputProps={{ style: { textAlign: 'center' } }}
              />
            </Box>
          </Stack>
        </Grid>
        <Grid xs={4} sm={3} md={2}>
          <Stack>
            <Typography textAlign={'center'} variant="body2" mb={1}>Or du groupe</Typography>
            <Box display={'flex'} justifyContent={'center'}>
              <TextField
                value={gold.toFixed(2)}
                variant="outlined"
                size='small'
                disabled
                sx={{ width: 100 }}
                inputProps={{ style: { textAlign: 'center' } }}
              />
            </Box>
          </Stack>
        </Grid>
        {isUserAuthorized(userId()) && (
          <Grid xs={4} sm={3} md={2}>
            <Stack direction={'column'} justifyContent={'center'} alignItems={'center'}>
              <Typography variant="body2" mb={1}>Niveau de zone</Typography>
              <Box display={'flex'}>
                <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                  <IconButton
                    size="small"
                    onClick={() => handleZoneLevelChange(-1)}
                    disabled={zoneLevel <= 1}
                  >
                    <RemoveIcon fontSize="small" />
                  </IconButton>
                  <TextField
                    value={zoneLevel}
                    variant="outlined"
                    size="small"
                    disabled
                    sx={{
                      width: '40px',
                    }}
                    inputProps={{
                      style: {
                        textAlign: 'center',
                        paddingLeft: 0,
                        paddingRight: 0
                      }
                    }}
                  />
                  <IconButton
                    size="small"
                    onClick={() => handleZoneLevelChange(1)}
                    disabled={zoneLevel >= 6}
                  >
                    <AddIcon fontSize="small" />
                  </IconButton>
                </div>
              </Box>
            </Stack>
          </Grid>
        )}
        {isUserAuthorized(userId()) && (
          <Grid container xs={8} sm={6} smOffset={3} md={4} mdOffset={0} lg={4}>
            <Grid
              display={'flex'} flexDirection={'column'} alignItems={'center'} justifyContent={'space-between'} xs={6}>
              <Typography variant="body2">Marchand</Typography>
              <Switch
                checked={gameInfo.merchantAvailable}
                onChange={handleMerchantAvailableChange}
              />
            </Grid>
            <Grid
              display={'flex'} flexDirection={'column'} alignItems={'center'} justifyContent={'space-between'} xs={6}>
              <Typography variant="body2">Combat</Typography>
              <Switch
                checked={gameInfo.battleMapAvailable}
                onChange={handleBattleMapAvailableChange}
              />
            </Grid>
          </Grid>
        )}
      </Grid>
    </Grid>
  );
}

export default Panel;