import { useEffect, useRef } from 'react';
import { Modal, Button, Box } from '@mui/material';
import type { EasterEggModalProps } from '@interfaces/types';

/**
 * Renders an Easter Egg modal component that plays audio and displays an image when open.
 *
 * @param {Object} param0 - The props for the Easter Egg modal.
 * @param {boolean} param0.isOpen - A boolean indicating whether the modal is open.
 * @param {Function} param0.handleClose - A function to close the modal.
 * @returns {JSX.Element} The Easter Egg modal component.
 */
function EasterEggModal({ isOpen, handleClose }: EasterEggModalProps): JSX.Element {
  const audioRef = useRef(new Audio('assets/secret/Hotline Miami Main Menu.mp3'));

  useEffect(() => {
    if (isOpen) {
      void audioRef.current.play();
    } else {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  }, [isOpen]);

  return (
    <Modal
      open={isOpen}
      onClose={handleClose}
      aria-labelledby="modal-title"
      aria-describedby="modal-description"
      style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
    >
      <Box
        position={'fixed'}
        top={0}
        left={0}
        width={'100%'}
        height={'100%'}
        display={'flex'}
        alignItems={'center'}
        justifyContent={'center'}
        style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
      >
        <img src="assets/secret/ludo.jpg" alt="Easter Egg" style={{ width: '100%', height: '100%' }} />
        <Button
          onClick={handleClose}
          variant="contained"
          style={{ position: 'absolute', bottom: '20px', left: '50%', transform: 'translateX(-50%)' }}
        >
          Fermer
        </Button>
      </Box>
    </Modal>
  );
}

export default EasterEggModal;