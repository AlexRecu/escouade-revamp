import {
  Box,
  Card,
  CardContent,
  Divider,
  Unstable_Grid2 as Grid,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import { useState } from 'react';
import type { CardCharacterProps } from '@interfaces/types';
import { userId } from '@utils/auth';

import ClassAndWeaponSelector from './ClassAndWeaponSelector';
import CharacterCharacteristics from './CharacterCharacteristics';
import EasterEggModal from './EasterEggModal';

/**
 * Renders a character card component.
 *
 * @param {Object} param0 - The props for the character card.
 * @param {Object} param0.character - The character data to display.
 * @param {number} param0.index - The index of the character in the list.
 * @returns {JSX.Element} The character card component.
 */
function CardCharacter({ character, index }: CardCharacterProps): JSX.Element {
  const [isEasterEggOpen, setIsEasterEggOpen] = useState(false);
  const [clickCount, setClickCount] = useState(0);

  const handleEasterEggTrigger = (): void => {
    if (userId() === 'bhnLW4pJnNgJ6eOd0Ti8uicf2QK2') {
      setClickCount(prevCount => prevCount + 1);
      if (clickCount === 9) {
        setIsEasterEggOpen(true);
        setClickCount(0);
      }
    }
  };

  return (
    <Grid container xs={12} md={10}>
      <Card sx={{ width: '100%', margin: 2, position: 'relative' }}>
        {character.isDead && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              backgroundColor: 'rgba(0, 0, 0, 0.7)',
              zIndex: 2,
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              color: 'white',
              pointerEvents: 'none',
            }}
          >
            <Typography variant="h4">Repose en pièce</Typography>
          </Box>
        )}
        <CardContent>
          <Stack direction="row" alignItems="center" justifyContent="center" width="100%">
            <Typography variant="h5" textAlign={'center'} mb={1}
              onClick={() => handleEasterEggTrigger()}>
              {character.name}
            </Typography>
          </Stack>
          <Divider />
          <ClassAndWeaponSelector character={character} index={index} />
          <Box sx={{ width: '100%' }}>
            <CharacterCharacteristics character={character} index={index} />
          </Box>
        </CardContent>
        {character.status.length > 0 && !character.isDead && (
          <>
            <Divider sx={{ mt: 2 }} />
            <Stack direction="row" spacing={1} sx={{ m: 1, justifyContent: 'center' }}>
              {character.status.map((status, index) => (
                <Tooltip key={index} title={status}>
                  <img
                    src={`assets/status/${status.toLocaleLowerCase()}.png`}
                    alt={`${status}`}
                    style={{ width: 30 }}
                  />
                </Tooltip>
              ))}
            </Stack>
          </>
        )}
      </Card>
      <EasterEggModal
        isOpen={isEasterEggOpen}
        handleClose={() => setIsEasterEggOpen(false)}
      />
    </Grid>
  );
}

export default CardCharacter;