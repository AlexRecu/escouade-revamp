import {
  Box, Button, Unstable_Grid2 as Grid, IconButton, Stack, TextField, Tooltip, Typography
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import type { Classes, Stats } from '@interfaces/interfaces';
import type { CharacterCharacteristicsProps } from '@interfaces/types';
import { useCharacters } from '@contexts/CharacterContext';
import { useGameInfo } from '@contexts/GameInfoContext';
import classesData from '@data/classes_data.json';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { enqueueSnackbar } from 'notistack';
import { isUserAuthorizedCharacter, userId } from '@utils/auth';
import { statLabels } from '@utils/const';

import CharacterStatsBar from './CharacterBar';
import CharacterStats from './CharacterStats';

/**
 * Renders character statistics and stat allocation for a given character.
 *
 * @param {Object} param0 - The props for character statistics.
 * @param {Object} param0.character - The character data for which statistics are displayed.
 * @param {number} param0.index - The index of the character in the list.
 * @returns {JSX.Element} The character statistics component.
 */
function CharacterCharacteristics({ character, index }: CharacterCharacteristicsProps): JSX.Element {
  const isAuthorized = isUserAuthorizedCharacter(userId(), character.userId, enqueueSnackbar, false);
  const { updateCharacter } = useCharacters();
  const { gameInfo } = useGameInfo();
  const [tempStats, setTempStats] = useState(character.tempStats);
  const [isCommitted, setIsCommitted] = useState(character.isCommitted);

  const getTotalTempPointsUsed = useCallback((): number => {
    const classDefaultStats = classesData[character.classe as keyof Classes].defaultStats;

    return Object.keys(tempStats).reduce((total, statKey) => {
      const statValue = tempStats[statKey as keyof Stats];
      const defaultStatValue = classDefaultStats[statKey as keyof Stats];

      return total + (statValue - defaultStatValue);
    }, 0);
  }, [character.classe, tempStats]);

  const handleTempStatChange = useCallback((statKey: string, delta: number): void => {
    setTempStats(prevStats => {
      const newStatValue = (prevStats[statKey as keyof Stats] || 0) + delta;
      const totalTempPointsUsed = getTotalTempPointsUsed() + delta;

      if (newStatValue >= classesData[character.classe as keyof Classes].defaultStats[statKey as keyof Stats]
        && totalTempPointsUsed <= gameInfo.level) {
        return { ...prevStats, [statKey]: newStatValue };
      }

      return prevStats;
    });
  }, [getTotalTempPointsUsed, gameInfo.level, character.classe]);

  useEffect(() => {
    setTempStats(character.tempStats);
  }, [character]);

  useEffect(() => {
    if (gameInfo.level - getTotalTempPointsUsed() > 0) {
      setIsCommitted(false);
    }
  }, [gameInfo.level, getTotalTempPointsUsed]);

  const handleStatCommit = useCallback((): void => {
    Object.entries(tempStats).forEach(([statKey, statValue]) => {
      updateCharacter(index, statKey, statValue);
    });
    setIsCommitted(true);
    updateCharacter(index, 'isCommitted', true);
  }, [index, tempStats, updateCharacter]);

  const pointsAvailable = gameInfo.level - getTotalTempPointsUsed();
  const canCommit = getTotalTempPointsUsed() === gameInfo.level;
  const shouldDisplayStack = useMemo(() => {
    const totalCharacterStats = Object.values(character.stats).reduce((total, stat) => total + stat, 0);
    const totalTempStats = Object.values(tempStats).reduce((total, stat) => total + stat, 0);

    return (pointsAvailable > 0 || !isCommitted) &&
      (totalTempStats + gameInfo.level) >= totalCharacterStats;
  }, [pointsAvailable, isCommitted, character.stats, tempStats, gameInfo.level]);

  return (
    <>
      <CharacterStatsBar character={character} />
      {shouldDisplayStack && isAuthorized ? (
        <Grid container spacing={1} mt={3}>
          {Object.entries(statLabels).map(([statKey, label]) => (
            <Grid xs={4} key={statKey} style={{ textAlign: 'center' }}>
              <Typography variant="body2">{label}</Typography>
              <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                <IconButton
                  onClick={() => handleTempStatChange(statKey, -1)}
                  size="small"
                  disabled={
                    tempStats[statKey as keyof Stats] <= character.stats[statKey as keyof Stats] ||
                    getTotalTempPointsUsed() <= 0
                  }
                >
                  <RemoveIcon fontSize="small" />
                </IconButton>
                <TextField
                  value={tempStats[statKey as keyof Stats]}
                  variant="outlined"
                  size="small"
                  disabled
                  sx={{
                    width: '40px',
                    mt: 0.5,
                    mb: 1
                  }}
                  inputProps={{
                    style: {
                      textAlign: 'center',
                      paddingLeft: 0,
                      paddingRight: 0
                    }
                  }}
                />
                <IconButton
                  onClick={() => handleTempStatChange(statKey, 1)}
                  size="small"
                  disabled={
                    tempStats[statKey as keyof Stats] >= 10 ||
                    getTotalTempPointsUsed() + 1 > gameInfo.level
                  }
                >
                  <AddIcon fontSize="small" />
                </IconButton>
              </div>
            </Grid>
          ))}
        </Grid>
      ) : (
        <Grid container spacing={1} mt={3}>
          {Object.entries(statLabels).map(([statKey, label]) => (
            <CharacterStats key={statKey} statKey={statKey} label={label} tempStats={tempStats} />
          ))}
        </Grid>
      )}
      {shouldDisplayStack && (
        <Stack direction="row" justifyContent="center" alignItems="center" spacing={1} mt={2}>
          <Typography variant="body2" textAlign={'center'}>
            Points à répartir
          </Typography>
          <Box
            sx={{
              borderRadius: '10px',
              backgroundColor: '#303030',
              padding: '2px 10px',
            }}>
            <Typography variant="body1">{pointsAvailable}</Typography>
          </Box>
          {isAuthorized && (
            <Tooltip title={!canCommit ? 'Vous devez assigner tous vos points avant de valider.' : ''}>
              <span>
                <Button variant='outlined' onClick={handleStatCommit} disabled={!canCommit}>
                  Valider
                </Button>
              </span>
            </Tooltip>
          )}
        </Stack>
      )}
    </>
  );
}

export default CharacterCharacteristics;