import { useCallback, useState } from 'react';
import { Unstable_Grid2 as Grid, MenuItem, Typography, Stack, Tooltip, Menu } from '@mui/material';
import type { Classes, Item, Weapon } from '@interfaces/interfaces';
import type { ClassAndWeaponSelectorProps } from '@interfaces/types';
import { useCharacters } from '@contexts/CharacterContext';
import { useInventory } from '@contexts/ItemContext';
import classesData from '@data/classes_data.json';
import weaponsData from '@data/weapons_data.json';
import { isUserAuthorizedCharacter, userId } from '@utils/auth';
import { enqueueSnackbar } from 'notistack';
import { InfoOutlined } from '@mui/icons-material';

/**
 * React component that allows selecting a weapon for a character based on their class.
 *
 * @param {Object} props - The props for the component.
 * @param {Character} props.character - The character object for which the weapon is selected.
 * @param {number} props.index - The index of the character in the list.
 * @returns {JSX.Element} A React JSX element representing the ClassAndWeaponSelector.
 */
function ClassAndWeaponSelector({ character, index }: ClassAndWeaponSelectorProps): JSX.Element {
  const isAuthorized = isUserAuthorizedCharacter(userId(), character.userId, enqueueSnackbar, false);
  const { characters, updateCharacter } = useCharacters();
  const { inventory, assignWeaponToCharacter, unassignWeapon } = useInventory();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const menuOpen = Boolean(anchorEl);

  const generateSummaryList = (weapon: Weapon | null): JSX.Element => {
    let liste = '';
    if (weapon) {
      liste += `Nom : ${weapon.name}\n`;
      liste += `Type : ${weapon.type}\n`;
      liste += `Stats principale : ${weapon.mainStat} (${weapon.weaponStat})\n`;
      if (weapon.subStat !== null) {
        liste += `Stats secondaire : ${weapon.subStat} (${weapon.weaponSubStat})\n`;
      }
      liste += `Portée : ${weapon.range} cases\n`;

      if (weapon.status !== null) {
        liste += `Status : ${weapon.status}\n`;
      }

      if (weapon.element !== null) {
        liste += `Élément : ${weapon.element}\n`;
      }
    }

    return <pre style={{ fontFamily: 'inherit', whiteSpace: 'pre-wrap' }}>{liste}</pre>;
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>): void => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = (): void => {
    setAnchorEl(null);
  };

  const getAvailableWeapons = (classKey: string, characterName: string): Item[] => {
    if (!classKey) {
      return [];
    }

    const characterClass = classesData[classKey as keyof Classes];

    return Array.from(inventory.keys()).filter(item =>
      item.type === 'Arme' &&
      characterClass.weapons.includes(weaponsData.find(weapon => weapon.name === item.name)?.type || '') &&
      (!inventory.get(item)?.assignedTo || inventory.get(item)?.assignedTo === characterName)
    );
  };

  const handleWeaponChange = useCallback((index: number, weaponId: string) => {
    if (!isAuthorized) {
      return;
    }
    const characterName = characters[index].name;

    const currentAssignedWeapon = Array.from(inventory.entries())
      .find(([, data]) => data.assignedTo === characterName)?.[0];

    if (currentAssignedWeapon && currentAssignedWeapon.id !== weaponId) {
      unassignWeapon(currentAssignedWeapon.id ?? '');
    }

    if (weaponId === '') {
      updateCharacter(index, 'weapons', '');
    } else {
      const selectedWeapon = Array.from(inventory.keys()).find(item => item.id === weaponId);
      if (selectedWeapon) {
        assignWeaponToCharacter(weaponId, characterName);
        updateCharacter(index, 'weapons', selectedWeapon.name);
      }
    }
  }, [isAuthorized, characters, inventory, unassignWeapon, updateCharacter, assignWeaponToCharacter]);

  const getWeaponTypesText = (classKey: string): string => {
    if (!classKey) {
      return 'Aucun type d\'arme disponible';
    }

    const characterClass = classesData[classKey as keyof Classes];
    const weaponTypes = characterClass.weapons;

    return weaponTypes.length > 0 ? weaponTypes.join(', ') : '';
  };

  const availableWeapons = getAvailableWeapons(character.classe, character.name);
  const weaponName = Array.from(inventory.entries())
    .find(([, data]) => data.assignedTo === character.name)?.[0].name || 'Aucune Arme';
  const hasAvailableWeapons = availableWeapons.length > 0;

  return (
    <Grid container spacing={1} mt={1} justifyContent={'left'}>
      <Grid xs={12}>
        <Stack direction={'row'} justifyContent={'space-between'}>
          <Stack>
            <Typography
              variant="body1"
              className="typographyMetal"
              textAlign={'center'}
              mb={1}
              height={'fit-content'}
            >
              {classesData[character.classe as keyof Classes].name}
            </Typography>
            <Typography
              variant="body2"
              sx={{
                textAlign: 'center',
                fontSize: '0.6rem',
                color: 'gray'
              }}
            >
              {getWeaponTypesText(character.classe)}
            </Typography>
          </Stack>
          {hasAvailableWeapons ? (
            <Stack direction={'row'} alignItems={'flex-start'}>
              <Typography
                onClick={handleMenuClick}
                variant="body1"
                className="typographyMetal"
                textAlign={'center'}
                mb={1}
                height={'fit-content'}
                sx={{ cursor: 'pointer' }}
              >
                {weaponName}
              </Typography>
              <Tooltip
                title={generateSummaryList(weaponsData.find(weapon => weapon.name === weaponName) as unknown as Weapon)}
                enterTouchDelay={0}
                leaveTouchDelay={1000}
                sx={{ mt: 0 }}
                PopperProps={{
                  modifiers: [
                    {
                      name: 'offset',
                      options: {
                        offset: [0, -10],
                      },
                    },
                  ],
                }}
              >
                <InfoOutlined sx={{ cursor: 'pointer', ml: 1 }} />
              </Tooltip>
            </Stack>
          ) : (
            <Tooltip
              title="Aucune arme n'est sélectionnable"
              arrow
              enterTouchDelay={0}
              leaveTouchDelay={1000}
              PopperProps={{
                modifiers: [
                  {
                    name: 'offset',
                    options: {
                      offset: [0, -10],
                    },
                  },
                ],
              }}
            >
              <Typography
                variant="body1"
                className="typographyMetal"
                textAlign={'center'}
                mb={1}
                height={'fit-content'}
              >
                {weaponName}
              </Typography>
            </Tooltip>
          )}
          <Menu
            id="weapon-menu"
            anchorEl={anchorEl}
            open={menuOpen}
            onClose={handleMenuClose}
          >
            <MenuItem value="" onClick={() => {
              handleWeaponChange(index, '');
              handleMenuClose();
            }}>
              Aucune Arme
            </MenuItem>
            {availableWeapons.map(weapon => (
              <MenuItem key={weapon.id} value={weapon.id} onClick={() => {
                handleWeaponChange(index, weapon.id ?? '');
                handleMenuClose();
              }}>
                {weapon.name}
              </MenuItem>
            ))}
          </Menu>
        </Stack>
      </Grid>
    </Grid >
  );
}

export default ClassAndWeaponSelector;