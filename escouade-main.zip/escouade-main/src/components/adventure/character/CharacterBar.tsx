import type { CharacterBarProps } from '@interfaces/types';
import { Unstable_Grid2 as Grid, LinearProgress, Typography } from '@mui/material';

/**
 * 
 * @param param0 
 * @returns 
 */
function CharacterBar({ character }: CharacterBarProps): JSX.Element {
  return (
    <Grid container spacing={1} mt={3}>
      <Grid xs={6} style={{ textAlign: 'center', position: 'relative' }}>
        <Typography
          variant="body2"
          style={{ position: 'absolute', width: '100%', zIndex: 1, top: '50%', transform: 'translateY(-50%)' }}
        >
          PV: {character.currentHealth}/{character.maxHealth}
        </Typography>
        <LinearProgress
          variant="determinate"
          color='error'
          value={(Math.min(character.currentHealth, character.maxHealth) / character.maxHealth) * 100}
          sx={{ height: '20px', borderRadius: '4px', width: '100%' }}
        />
      </Grid>
      <Grid xs={6} style={{ textAlign: 'center', position: 'relative' }}>
        <Typography
          variant="body2"
          style={{ position: 'absolute', width: '100%', zIndex: 1, top: '50%', transform: 'translateY(-50%)' }}
        >
          PM: {character.currentMana}/{character.maxMana}
        </Typography>
        <LinearProgress
          variant="determinate"
          color='info'
          value={(Math.min(character.currentMana, character.maxMana) / character.maxMana) * 100}
          sx={{ height: '20px', borderRadius: '4px', width: '100%' }}
        />
      </Grid>
    </Grid>
  );
}

export default CharacterBar;