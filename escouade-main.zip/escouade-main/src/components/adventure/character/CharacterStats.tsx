import { Button, Unstable_Grid2 as Grid, Stack, Tooltip } from '@mui/material';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import SpeedIcon from '@mui/icons-material/Speed';
import DirectionsRunIcon from '@mui/icons-material/DirectionsRun';
import AutoGraphIcon from '@mui/icons-material/AutoGraph';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EmojiPeopleIcon from '@mui/icons-material/EmojiPeople';
import type { CharacterStatsProps } from '@interfaces/types';
import type { Stats } from '@interfaces/interfaces';

/**
 * 
 * @param param0 
 * @returns 
 */
function CharacterStats({ statKey, label, tempStats }: CharacterStatsProps): JSX.Element {
  return (
    <Grid xs={4} key={statKey} display={'flex'} justifyContent={'center'}>
      <Stack
        direction={'row'}
        justifyContent={'center'}
        spacing={2}
        mb={1}
        width={'fit-content'}
        p={1.5}
      >
        <Tooltip
          title={label}
          enterTouchDelay={0}
          leaveTouchDelay={1000}
          PopperProps={{
            modifiers: [
              {
                name: 'offset',
                options: {
                  offset: [0, -10],
                },
              },
            ],
          }}
        >
          <Button
            color='inherit'
            variant="outlined"
            startIcon={
              {
                'strength': <FitnessCenterIcon />,
                'dexterity': <SpeedIcon />,
                'endurance': <DirectionsRunIcon />,
                'mana': <AutoGraphIcon />,
                'intelligence': <LightbulbIcon />,
                'perception': <VisibilityIcon />,
                'charisma': <EmojiPeopleIcon />
              }[statKey]
            }
          >
            {tempStats[statKey as keyof Stats]}
          </Button>
        </Tooltip>
      </Stack>
    </Grid>
  );
}

export default CharacterStats;