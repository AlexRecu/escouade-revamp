import { lazy, useCallback, useMemo, useState } from 'react';
import { Unstable_Grid2 as Grid, Typography } from '@mui/material';
import { useInventory } from '@contexts/ItemContext';
import { useNotification } from '@contexts/NotificationContext';
import { useCharacters } from '@contexts/CharacterContext';
import { isUserAuthorized, userId } from '@utils/auth';
import type { Item } from '@interfaces/interfaces';
import { useGameInfo } from '@contexts/GameInfoContext';

const ItemListSearchBar = lazy(() => import('../item/ItemListSearchBar'));
const ItemList = lazy(() => import('../item/ItemList'));

/**
 * React component representing the inventory screen where players can view and manage their items.
 *
 * @returns {JSX.Element} A React JSX element representing the Inventory screen.
 */
function Inventory(): JSX.Element {
  const { characters } = useCharacters();
  const { gameInfo, updateGameInfo } = useGameInfo();
  const { inventory, removeFromInventory, filterItems } = useInventory();
  const { sendNotification } = useNotification();
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const handleSellFromInventory = useCallback(
    (item: Item) => () => {
      if (isUserAuthorized(userId())) {
        removeFromInventory(item);
      } else {
        const currentUserCharacter = characters.find(character => character.userId === userId());
        removeFromInventory(item);
        sendNotification(`${currentUserCharacter?.name} a vendu ${item.name} pour ${item.purchasePrice}.`, 'warning');
        void updateGameInfo({ ...gameInfo, gold: gameInfo.gold + item.purchasePrice });
      }
    },
    [characters, gameInfo, removeFromInventory, sendNotification, updateGameInfo]
  );

  const inventoryItems = useMemo(() => Array.from(inventory.entries()).map(([item, itemData]) => ({
    ...item,
    count: itemData.count,
    assignedTo: itemData.assignedTo
  })), [inventory]);

  const filteredItems = useMemo(() => {
    const searchFiltered = filterItems(inventoryItems, searchTerm);

    if (filterType.length === 0) {
      return searchFiltered;
    }

    return searchFiltered.filter(item => filterType.includes(item.type));
  }, [filterItems, inventoryItems, searchTerm, filterType]);

  const isEmpty = inventoryItems.length === 0;

  return (
    <Grid container mt={2} justifyContent={'center'}>
      <Grid xs={10}>
        {isEmpty ? (
          <Typography
            variant="h6"
            color="textSecondary"
            textAlign={'center'}
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)'
            }}
          >
            Vous n&apos;avez aucun objet, vous êtes communiste.
          </Typography>
        ) : (
          <>
            <ItemListSearchBar
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              filterType={filterType}
              setFilterType={setFilterType}
              setCurrentPage={setCurrentPage}
            />
            <ItemList
              items={filteredItems}
              currentPage={currentPage}
              itemsPerPage={16}
              setCurrentPage={setCurrentPage}
              onItemAction={handleSellFromInventory}
              actionLabel='inventory'
            />
          </>
        )}
      </Grid>
    </Grid>
  );
}

export default Inventory;