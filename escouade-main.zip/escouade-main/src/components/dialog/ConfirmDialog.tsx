import type { ConfirmDialogProps } from '@interfaces/types';
import { Dialog, DialogActions, DialogContent, DialogTitle, Button } from '@mui/material';

/**
 * Renders a confirmation dialog with a message and options to confirm or cancel an action.
 *
 * @component
 * @param {Object} param0 - The props for the ConfirmDialog.
 * @param {boolean} param0.open - Whether the dialog is open or closed.
 * @param {Function} param0.onClose - A function to handle closing the dialog.
 * @param {Function} param0.onConfirm - A function to handle confirming the action.
 * @param {string} param0.message - The message displayed in the dialog to confirm the action.
 * @returns {JSX.Element} The ConfirmDialog component.
 */
function ConfirmDialog({ open, onClose, onConfirm, message }: ConfirmDialogProps): JSX.Element {
  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Confirmer la suppression</DialogTitle>
      <DialogContent>
        {message}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Annuler</Button>
        <Button onClick={onConfirm} color="error">Supprimer</Button>
      </DialogActions>
    </Dialog>
  );
}

export default ConfirmDialog;