import { Unstable_Grid2 as Grid } from '@mui/material';
import itemsData from '@data/items_data.json';
import { lazy, useMemo, useState } from 'react';
import { useInventory } from '@contexts/ItemContext';
import { useGameInfo } from '@contexts/GameInfoContext';
import { useNotification } from '@contexts/NotificationContext';
import { useCharacters } from '@contexts/CharacterContext';
import { useSnackbar } from 'notistack';
import { isUserAuthorized, userId } from '@utils/auth';
import type { Item } from '@interfaces/interfaces';

const ItemListSearchBar = lazy(() => import('../item/ItemListSearchBar'));
const ItemList = lazy(() => import('../item/ItemList'));

/**
 * React component representing the merchant screen where players can buy items.
 *
 * @returns {JSX.Element} A React JSX element representing the Merchant screen.
 */
function Merchant(): JSX.Element {
  const { characters } = useCharacters();
  const { gameInfo, updateGameInfo } = useGameInfo();
  const { addToInventory, filterItems } = useInventory();
  const { sendNotification } = useNotification();
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const { enqueueSnackbar } = useSnackbar();

  const handleAddToInventory = (item: Item) => () => {
    const currentUserCharacter = characters.find(character => character.userId === userId());
    if (item.purchasePrice <= gameInfo.gold && !isUserAuthorized(userId())) {
      addToInventory(item);
      void updateGameInfo({ ...gameInfo, gold: gameInfo.gold - item.purchasePrice });
      sendNotification(
        `${currentUserCharacter?.name} a acheté ${item.name}.`,
        'success'
      );
    } else if (isUserAuthorized(userId())) {
      addToInventory(item);
    } else {
      enqueueSnackbar(
        `${currentUserCharacter?.name}, vous êtes trop PAUVRE pour acheter ${item.name}.`,
        { variant: 'error' }
      );
    }
  };

  const filteredItems = useMemo(() => {
    const itemsFilteredByLevel = itemsData.filter(item =>
      item.zoneThreshold <= gameInfo.zoneLevel && item.zoneThreshold !== 0
    );
  
    const itemsFilteredBySearch = filterItems(itemsFilteredByLevel, searchTerm);
  
    if (filterType.length > 0) {
      return itemsFilteredBySearch.filter(item => filterType.includes(item.type));
    }
  
    return itemsFilteredBySearch;
  }, [filterItems, searchTerm, gameInfo.zoneLevel, filterType]);

  return (
    <Grid container mt={2} justifyContent={'center'}>
      <Grid xs={10} md={10}>
        <ItemListSearchBar
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          filterType={filterType}
          setFilterType={setFilterType}
          setCurrentPage={setCurrentPage}
        />

        <ItemList
          items={filteredItems}
          currentPage={currentPage}
          itemsPerPage={10}
          setCurrentPage={setCurrentPage}
          onItemAction={handleAddToInventory}
          actionLabel='merchant'
        />
      </Grid>
    </Grid>
  );
}

export default Merchant;