import { Box, Card, Divider, IconButton, LinearProgress, Stack, Typography } from '@mui/material';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import PauseIcon from '@mui/icons-material/Pause';
import StopIcon from '@mui/icons-material/Stop';
import DeleteIcon from '@mui/icons-material/Delete';
import type { MusicCardProps } from '@interfaces/types';

/**
 * Renders a card component for displaying and controlling music playback.
 *
 * @param {Object} param0 - The props for the MusicCard.
 * @param {Object} param0.music - The music information to display.
 * @param {boolean} param0.isPlaying - A boolean indicating if the music is currently playing.
 * @param {string} param0.currentTrack - The current music track being played.
 * @param {number} param0.progress - The progress of the currently playing music.
 * @param {Function} param0.playMusic - A function to start playing the music.
 * @param {Function} param0.pauseMusic - A function to pause the currently playing music.
 * @param {Function} param0.stopMusic - A function to stop the currently playing music.
 * @param {Function} param0.handleOpenDeleteDialog - A function to open a dialog for deleting the music.
 * @returns {JSX.Element} The MusicCard component.
 */
function MusicCard(
  { music, isPlaying, currentTrack, progress, playMusic, pauseMusic, stopMusic, handleOpenDeleteDialog }: MusicCardProps
): JSX.Element {
  return (
    <Card sx={{ mb: 2, p: 2 }}>
      <Stack direction={'row'} alignItems={'center'} justifyContent={'space-between'}>
        <Typography variant="subtitle1">{music.name.replace(/\.[^/.]+$/, '')}</Typography>
        <IconButton
          size="small"
          onClick={handleOpenDeleteDialog(music.name, 'music')}
        >
          <DeleteIcon />
        </IconButton>
      </Stack>
      <Divider sx={{ mt: 1, mb: 1 }} />
      <Box display="flex" alignItems="center">
        <IconButton color="primary"
          onClick={() => playMusic(music.file)} disabled={isPlaying && currentTrack === music.file}>
          <PlayArrowIcon />
        </IconButton>
        <IconButton color="secondary" onClick={pauseMusic}
          disabled={!isPlaying || currentTrack !== music.file}>
          <PauseIcon />
        </IconButton>
        <IconButton onClick={stopMusic} disabled={!isPlaying || currentTrack !== music.file}>
          <StopIcon />
        </IconButton>
        {currentTrack === music.file && (
          <LinearProgress variant="determinate" value={progress} sx={{ ml: 1, width: '100%' }} />
        )}
      </Box>
    </Card>
  );
}

export default MusicCard;