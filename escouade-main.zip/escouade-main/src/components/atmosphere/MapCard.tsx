import type { MapCardProps } from '@interfaces/types';
import { Box, IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

/**
 * Renders a card component for displaying a map image.
 *
 * @param {Object} param0 - The props for the MapCard.
 * @param {Object} param0.image - The map image information to display.
 * @param {Object} param0.gameInfo - The game information including the currently selected map.
 * @param {Function} param0.handleImageClick - A function to handle when the map image is clicked.
 * @param {Function} param0.handleOpenDeleteDialog - A function to open a dialog for deleting the map image.
 * @returns {JSX.Element} The MapCard component.
 */
function MapCard({ image, gameInfo, handleImageClick, handleOpenDeleteDialog }: MapCardProps): JSX.Element {
  return (
    <Box position="relative">
      <img
        src={image.url}
        alt={image.name}
        style={{
          borderRadius: 10,
          width: '100%',
          height: 'auto',
          border: gameInfo.map === image.url ? '2px solid blue' : 'none'
        }}
        onClick={() => handleImageClick(image.url)}
      />
      <IconButton
        size="small"
        style={{ position: 'absolute', top: 10, right: 0 }}
        onClick={handleOpenDeleteDialog(image.name, 'map')}
      >
        <DeleteIcon />
      </IconButton>
      <Box
        style={{
          position: 'absolute',
          bottom: 7,
          left: 0,
          right: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          color: 'white',
          padding: '4px',
          textAlign: 'center',
          wordWrap: 'break-word'
        }}
      >
        {image.name.replace(/\.[^/.]+$/, '')}
      </Box>
    </Box>
  );
}

export default MapCard;