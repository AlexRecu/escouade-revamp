import { useState } from 'react';
import { useAudio } from '@contexts/AudioContext';
import {
  Stack,
  TextField,
  Button,
  Unstable_Grid2 as Grid,
  Typography,
  Divider
} from '@mui/material';
import UploadIcon from '@mui/icons-material/Upload';
import { useGameInfo } from '@contexts/GameInfoContext';
import { useMapImages } from '@contexts/MapImageContext';

import ConfirmDialog from '../dialog/ConfirmDialog';

import MusicCard from './MusicCard';
import MapCard from './MapCard';

/**
 * Composant de l'atmosphère audio pour la lecture de musique.
 * @returns {JSX.Element} - Le composant de l'atmosphère audio.
 */
function Atmosphere(): JSX.Element {
  const {
    playMusic, pauseMusic, stopMusic, currentTrack, isPlaying, musicList, progress, uploadMusic, deleteMusic
  } = useAudio();
  const { gameInfo, updateGameInfo } = useGameInfo();
  const { imageList, uploadMap, deleteMap } = useMapImages();
  const [searchQuery, setSearchQuery] = useState('');
  const [imageSearchQuery, setImageSearchQuery] = useState('');
  const [openDeleteDialogMusic, setOpenDeleteDialogMusic] = useState(false);
  const [openDeleteDialogMap, setOpenDeleteDialogMap] = useState(false);
  const [deleteMapName, setDeleteImageName] = useState('');
  const [deleteMusicName, setDeleteMusicName] = useState('');

  const handleMusicUpload = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const { files } = event.target;
    if (files) {
      Array.from(files).forEach(file => uploadMusic(file));
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const { files } = event.target;
    if (files) {
      Array.from(files).forEach(file => uploadMap(file));
    }
  };
  const handleImageClick = (imageUrl: string): void => {
    void updateGameInfo({ ...gameInfo, map: imageUrl });
  };

  const handleOpenDeleteDialog = (name: string, type: string) => () => {
    switch (type) {
      case 'music':
        setDeleteMusicName(name);
        setOpenDeleteDialogMusic(true);
        break;
      case 'map':
        setDeleteImageName(name);
        setOpenDeleteDialogMap(true);
        break;
      default:
        break;
    }
  };

  const handleCloseDeleteDialogMusic = (): void => {
    setOpenDeleteDialogMusic(false);
  };

  const handleCloseDeleteDialogMap = (): void => {
    setOpenDeleteDialogMap(false);
  };

  const handleDeleteMusic = (): void => {
    deleteMusic(deleteMusicName);
    handleCloseDeleteDialogMusic();
  };

  const handleDeleteMap = (): void => {
    deleteMap(deleteMapName);
    handleCloseDeleteDialogMap();
  };

  const reactMap = {
    name: 'React',
    url: 'assets/secret/react.png',
  };

  const bgMap = {
    name: 'Bg du 31',
    url: 'assets/secret/big-bro.png',
  };

  const filteredMusicList =
    musicList.filter(music => music.name.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredImageList =
    imageList.filter(image => image.name.toLowerCase().includes(imageSearchQuery.toLowerCase()));

  let displayedImageList = filteredImageList;
  if (imageSearchQuery.toLowerCase() === 'react') {
    displayedImageList = [reactMap];
  } else if (imageSearchQuery.toLowerCase() === 'bgdu31') {
    displayedImageList = [bgMap];
  }

  return (
    <Grid container mt={2} justifyContent={'center'}>
      <Grid container xs={10} justifyContent={'space-evenly'} alignItems={'flex-start'}>
        <Grid container xs={12} md={5}>
          <Grid xs={12} mt={4} mb={2}>
            <Typography variant='h4' textAlign={'center'}>MUSIQUE</Typography>
            <Divider sx={{ m: 2 }} />
          </Grid>
          <Grid xs={12} mb={4}>
            <Stack direction="row" spacing={2} justifyContent="center" alignItems="center">
              <TextField
                label="Rechercher une musique"
                type='search'
                size='small'
                variant="outlined"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button
                variant="contained"
                component="label"
                startIcon={<UploadIcon />}
              >
                Upload
                <input
                  type="file"
                  hidden
                  multiple
                  accept="audio/mpeg"
                  onChange={handleMusicUpload}
                />
              </Button>
            </Stack>
          </Grid>
          <Grid container xs={12} spacing={2}>
            {filteredMusicList.length > 0 ? (
              filteredMusicList.map((music, index) => (
                <Grid key={index} xs={12} sm={6} md={12} xl={6}>
                  <MusicCard
                    key={index}
                    music={music}
                    isPlaying={isPlaying}
                    currentTrack={currentTrack}
                    progress={progress}
                    playMusic={playMusic}
                    pauseMusic={pauseMusic}
                    stopMusic={stopMusic}
                    handleOpenDeleteDialog={handleOpenDeleteDialog}
                  />
                </Grid>
              ))
            ) : (
              <Typography variant="subtitle1" sx={{ width: '100%', textAlign: 'center', mt: 2 }}>
                Aucune musique trouvée
              </Typography>
            )}
          </Grid>
        </Grid>
        <Grid container xs={12} md={5}>
          <Grid xs={12} mt={4} mb={2}>
            <Typography variant='h4' textAlign={'center'}>CARTE</Typography>
            <Divider sx={{ m: 2 }} />
          </Grid>
          <Grid xs={12} mb={4}>
            <Stack direction="row" spacing={2} justifyContent="center" alignItems="center">
              <TextField
                label="Rechercher une carte"
                type='search'
                size='small'
                variant="outlined"
                value={imageSearchQuery}
                onChange={(e) => setImageSearchQuery(e.target.value)}
              />
              <Button
                variant="contained"
                component="label"
                startIcon={<UploadIcon />}
              >
                Upload
                <input
                  type="file"
                  hidden
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                />
              </Button>
            </Stack>
          </Grid>
          <Grid container xs={12} spacing={2} mb={2}>
            {displayedImageList.length > 0 ? (
              displayedImageList.map((image, index) => (
                <Grid key={index} xs={6} lg={4}>
                  <MapCard
                    key={index}
                    image={image}
                    gameInfo={gameInfo}
                    handleImageClick={handleImageClick}
                    handleOpenDeleteDialog={handleOpenDeleteDialog}
                  />
                </Grid>
              ))
            ) : (
              <Typography variant="subtitle1" sx={{ width: '100%', textAlign: 'center', mt: 2, mb: 3 }}>
                Aucune carte trouvée
              </Typography>
            )}
          </Grid>
        </Grid>
      </Grid>
      <ConfirmDialog
        open={openDeleteDialogMusic}
        onClose={handleCloseDeleteDialogMusic}
        onConfirm={handleDeleteMusic}
        message="Êtes-vous sûr de vouloir supprimer cette musique ?"
      />
      <ConfirmDialog
        open={openDeleteDialogMap}
        onClose={handleCloseDeleteDialogMap}
        onConfirm={handleDeleteMap}
        message="Êtes-vous sûr de vouloir supprimer cette map ?"
      />
    </Grid>
  );
}

export default Atmosphere;