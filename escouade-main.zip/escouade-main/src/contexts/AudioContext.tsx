import { createContext, useContext, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useGameInfo } from '@contexts/GameInfoContext';
import { getStorage, ref as storageRef, listAll, getDownloadURL, uploadBytes, deleteObject } from 'firebase/storage';
import type { AudioContextProps, ProviderProps } from '@interfaces/types';
import type { MusicFile } from '@interfaces/interfaces';

// eslint-disable-next-line @typescript-eslint/naming-convention
const AudioContext = createContext<AudioContextProps | undefined>(undefined);

/**
 * Provides audio-related functionality including volume control, music playback, and music management.
 * 
 * @component
 * @param {Object} param0 - The props for the AudioProvider.
 * @param {React.ReactNode} param0.children - The child components to be wrapped by the AudioProvider.
 * @returns {JSX.Element} The AudioProvider component.
 */
export function AudioProvider({ children }: ProviderProps): JSX.Element {
  const { gameInfo, updateGameInfo } = useGameInfo();
  const savedVolume = localStorage.getItem('volume');
  const initialVolume = savedVolume !== null ? parseInt(savedVolume, 10) : 50;
  const [volume, setVolumeState] = useState(initialVolume);
  const [musicList, setMusicList] = useState<MusicFile[]>([]);
  const audioRef = useRef(new Audio());
  const [progress, setProgress] = useState(0);

  const uploadMusic = useCallback(async (file: File) => {
    const storage = getStorage();
    const musicFileRef = storageRef(storage, `music/${file.name}`);

    await uploadBytes(musicFileRef, file);
    const url = await getDownloadURL(musicFileRef);
    setMusicList(prev => [...prev, { name: file.name, file: url }]);
  }, []);

  useEffect(() => {
    const audioElement = audioRef.current;

    const handleTimeUpdate = (): void => {
      if (audioElement.duration > 0) {
        const currentProgress = (audioElement.currentTime / audioElement.duration) * 100;
        setProgress(currentProgress);
      }
    };

    audioElement.addEventListener('timeupdate', handleTimeUpdate);

    return () => {
      audioElement.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, []);

  useEffect(() => {
    const savedVolume = localStorage.getItem('volume');
    if (savedVolume !== null) {
      const savedVolumeNumber = parseInt(savedVolume, 10);
      setVolumeState(savedVolumeNumber);
      audioRef.current.volume = savedVolumeNumber / 100;
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('volume', volume.toString());
    audioRef.current.volume = volume / 100;
  }, [volume]);

  useEffect(() => {
    const fetchMusicFiles = async (): Promise<void> => {
      const storage = getStorage();
      const musicFolderRef = storageRef(storage, 'music');

      const result = await listAll(musicFolderRef);
      const files = await Promise.all(
        result.items.map(async itemRef => {
          const url = await getDownloadURL(itemRef);

          return { name: itemRef.name, file: url };
        })
      );
      setMusicList(files);
    };

    void fetchMusicFiles();
  }, []);

  useEffect(() => {
    const audioElement = audioRef.current;

    if (gameInfo.currentMusic) {
      const elapsedTime = gameInfo.startTimestamp ? (Date.now() - gameInfo.startTimestamp) / 1000 : 0;
      audioElement.src = gameInfo.currentMusic;
      audioElement.currentTime = elapsedTime;

      const handleAudioEnd = (): void => {
        void updateGameInfo({
          ...gameInfo,
          musicStatus: 'stop',
          currentMusic: '',
          musicTime: 0,
          startTimestamp: 0
        });
      };

      audioElement.addEventListener('ended', handleAudioEnd);

      if (gameInfo.musicStatus === 'play') {
        void audioElement.play();
      } else {
        audioElement.pause();
      }

      return () => {
        audioElement.removeEventListener('ended', handleAudioEnd);
      };
    }
  }, [gameInfo, updateGameInfo]);

  useEffect(() => {
    const audioElement = audioRef.current;
    if (gameInfo.currentMusic) {
      audioElement.src = gameInfo.currentMusic;
      if (gameInfo.musicStatus === 'play') {
        void audioElement.play();
      } else if (gameInfo.musicStatus === 'pause') {
        audioElement.pause();
      } else {
        audioElement.pause();
        audioElement.currentTime = 0;
      }
    } else {
      audioElement.pause();
      audioElement.currentTime = 0;
    }
  }, [gameInfo.currentMusic, gameInfo.musicStatus]);

  const initializeAudio = useCallback(() => {
    const audioElement = audioRef.current;

    if (gameInfo.currentMusic && gameInfo.musicStatus === 'play') {
      audioElement.src = gameInfo.currentMusic;
      void audioElement.play();
    } else {
      audioElement.pause();
    }
  }, [gameInfo.currentMusic, gameInfo.musicStatus]);

  useEffect(() => {
    initializeAudio();
  }, [initializeAudio]);

  const playMusic = useCallback((track: string) => {
    if (gameInfo.currentMusic === track) {
      const adjustedStartTimestamp = Date.now() - (gameInfo.musicTime * 1000);
      void updateGameInfo({
        ...gameInfo,
        musicStatus: 'play',
        startTimestamp: adjustedStartTimestamp
      });
    } else {
      const startTimestamp = Date.now();
      void updateGameInfo({
        ...gameInfo,
        currentMusic: track,
        musicStatus: 'play',
        startTimestamp,
        musicTime: 0
      });
      audioRef.current.src = track;
      audioRef.current.currentTime = 0;
    }

    void audioRef.current.play();
  }, [gameInfo, updateGameInfo]);

  const pauseMusic = useCallback(() => {
    void updateGameInfo({
      ...gameInfo,
      musicStatus: 'pause',
      musicTime: audioRef.current.currentTime
    });
    audioRef.current.pause();
  }, [gameInfo, updateGameInfo]);

  const stopMusic = useCallback(() => {
    void updateGameInfo({ ...gameInfo, currentMusic: '', musicStatus: 'stop', musicTime: 0, startTimestamp: 0 });
    audioRef.current.pause();
    audioRef.current.currentTime = 0;
  }, [gameInfo, updateGameInfo]);

  const setVolume = useCallback((newVolume: number) => {
    setVolumeState(newVolume);
    localStorage.setItem('volume', newVolume.toString());
    audioRef.current.volume = newVolume / 100;
  }, []);

  const deleteMusic = useCallback(async (name: string) => {
    const storage = getStorage();
    const imageRef = storageRef(storage, `music/${name}`);

    await deleteObject(imageRef);

    setMusicList(prev => prev.filter(music => music.name !== name));
  }, []);

  const contextValue = useMemo(() => ({
    volume,
    setVolume,
    currentTrack: gameInfo.currentMusic || '',
    isPlaying: gameInfo.musicStatus === 'play',
    playMusic,
    pauseMusic,
    stopMusic,
    musicList,
    progress,
    uploadMusic,
    deleteMusic
  }), [
    volume,
    setVolume,
    gameInfo.currentMusic,
    gameInfo.musicStatus,
    playMusic,
    pauseMusic,
    stopMusic,
    musicList,
    progress,
    uploadMusic,
    deleteMusic
  ]);

  return (
    <AudioContext.Provider value={contextValue}>
      {children}
      <audio ref={audioRef} />
    </AudioContext.Provider>
  );
}

/**
 * Custom hook for accessing audio-related functionality and state.
 * 
 * @returns {AudioContextProps} The audio context with audio-related functions and state.
 */
export const useAudio = (): AudioContextProps => {
  const context = useContext(AudioContext);
  if (context === undefined) {
    throw new Error('useAudio must be used within an AudioProvider');
  }

  return context;
};