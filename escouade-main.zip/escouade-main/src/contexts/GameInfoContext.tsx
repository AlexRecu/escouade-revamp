import { createContext, useState, useContext, useCallback, useMemo, useEffect } from 'react';
import { onSnapshot, setDoc } from 'firebase/firestore';
import type { GameInfo } from '@interfaces/interfaces';
import type { GameInfoContextProps, ProviderProps } from '@interfaces/types';

import { getGameUserDataDocument } from '../services/firestore';

// eslint-disable-next-line @typescript-eslint/naming-convention
const GameInfoContext = createContext<GameInfoContextProps | undefined>(undefined);

/**
 * Provides game-related information and functionality, including game state and music management.
 * 
 * @component
 * @param {Object} param0 - The props for the GameInfoProvider.
 * @param {React.ReactNode} param0.children - The child components to be wrapped by the GameInfoProvider.
 * @returns {JSX.Element} The GameInfoProvider component.
 */
export function GameInfoProvider({ children }: ProviderProps): JSX.Element {
  const [gameInfo, setGameInfo] = useState<GameInfo>({
    level: 1,
    xp: 0,
    zoneLevel: 1,
    currentMusic: '',
    musicStatus: 'stop',
    musicTime: 0,
    startTimestamp: 0,
    map: '',
    merchantAvailable: false,
    battleMapAvailable: false,
    gold: 0
  });

  useEffect(() => {
    const gameInfoRef = getGameUserDataDocument('gameInfo');
    const unsubscribe = onSnapshot(gameInfoRef, (snapshot) => {
      if (snapshot.exists()) {
        const newGameInfo = snapshot.data() as GameInfo;
        setGameInfo(newGameInfo);
      }
    });

    return () => unsubscribe();
  }, []);

  const updateGameInfo = useCallback(async (newGameInfo: GameInfo) => {
    const gameInfoRef = getGameUserDataDocument('gameInfo');
    await setDoc(gameInfoRef, newGameInfo);
  }, []);

  const setGameInfoFromImport = useCallback((importedGameInfo: GameInfo) => {
    setGameInfo(importedGameInfo);
  }, []);

  const contextValue = useMemo(() => ({
    gameInfo,
    updateGameInfo,
    setGameInfoFromImport
  }), [gameInfo, updateGameInfo, setGameInfoFromImport]);

  return (
    <GameInfoContext.Provider value={contextValue}>
      {children}
    </GameInfoContext.Provider>
  );
}

/**
 * Custom hook for accessing game-related information and functionality.
 * 
 * @returns {GameInfoContextProps} The game info context with game-related functions and state.
 */
export const useGameInfo = (): GameInfoContextProps => {
  const context = useContext(GameInfoContext);
  if (context === undefined) {
    throw new Error('useGameInfo must be used within a GameInfoProvider');
  }

  return context;
};