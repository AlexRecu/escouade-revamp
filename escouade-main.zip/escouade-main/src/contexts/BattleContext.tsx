import { createContext, useState, useContext, useEffect, useCallback, useMemo } from 'react';
import { getDoc, onSnapshot, setDoc } from 'firebase/firestore';
import type { TokenPosition, BattleDataUpdate, Character, TokenPositions } from '@interfaces/interfaces';
import type { BattleContextProps, ProviderProps } from '@interfaces/types';

import { getGameUserDataDocument } from '../services/firestore';

import { useNotification } from './NotificationContext';

// eslint-disable-next-line @typescript-eslint/naming-convention
const BattleContext = createContext<BattleContextProps | undefined>(undefined);

/**
 * 
 * @param param0 
 * @returns 
 */
export function BattleProvider({ children }: ProviderProps): JSX.Element {
  const [tokenPositions, setTokenPositions] = useState<{ [characterId: string]: TokenPosition }>({});
  const [currentTurn, setCurrentTurn] = useState<number>(0);
  const [turnOrder, setTurnOrder] = useState<string[]>([]);
  const [isPreBattlePlacementAllowed, setIsPreBattlePlacementAllowed] = useState(true);
  const [enemiesGenerated, setEnemiesGenerated] = useState(false);
  const { sendNotification } = useNotification();

  useEffect(() => {
    const battleRef = getGameUserDataDocument('battle');

    const unsubscribe = onSnapshot(battleRef, (snapshot) => {
      if (snapshot.exists()) {
        const battleData = snapshot.data();
        setTokenPositions(battleData.tokenPositions as { [characterId: string]: TokenPosition });
        setCurrentTurn(battleData.currentTurn as number);
        if (battleData.turnOrder && battleData.turnOrder.length > 0) {
          setTurnOrder(battleData.turnOrder as string[]);
        }
        setIsPreBattlePlacementAllowed(battleData.isPreBattlePlacementAllowed ?? false);
        setEnemiesGenerated(battleData.enemiesGenerated ?? false);
      } else {
        void setDoc(
          battleRef, {
          tokenPositions: {},
          currentTurn: 0,
          turnOrder: [],
          isPreBattlePlacementAllowed: false,
          enemiesGenerated: false
        }
        );
      }
    });

    return () => unsubscribe();
  }, []);

  const handlePreBattlePlacementToggle = useCallback(async () => {
    const newValue = !isPreBattlePlacementAllowed;
    setIsPreBattlePlacementAllowed(newValue);

    const battleRef = getGameUserDataDocument('battle');
    await setDoc(battleRef, { isPreBattlePlacementAllowed: newValue }, { merge: true });
  }, [isPreBattlePlacementAllowed]);

  const handleEnemiesGeneratedToggle = useCallback(async () => {
    const newValue = !enemiesGenerated;
    setEnemiesGenerated(newValue);

    const battleRef = getGameUserDataDocument('battle');
    await setDoc(battleRef, { enemiesGenerated: newValue }, { merge: true });
  }, [enemiesGenerated]);

  useEffect(() => {
    const charactersRef = getGameUserDataDocument('characters');
    const unsubscribe = onSnapshot(charactersRef, (snapshot) => {
      if (snapshot.exists()) {
        const charactersData = snapshot.data().characters as Character[];
        const sortedCharacters = charactersData
          .filter(character => !character.isDead)
          .sort((a, b) => b.creationDate - a.creationDate);
        setTurnOrder(sortedCharacters.map(character => character.id));
      }
    });

    return () => unsubscribe();
  }, []);

  const updateBattleDataInFirestore = useCallback(async (
    newTokenPositions: { [characterId: string]: TokenPosition },
    newCurrentTurn?: number,
    newTurnOrder?: string[],
  ): Promise<void> => {
    const battleRef = getGameUserDataDocument('battle');
    const dataToUpdate: BattleDataUpdate = {
      tokenPositions: newTokenPositions,
      turnOrder: newTurnOrder
    };

    if (typeof newCurrentTurn === 'number') {
      dataToUpdate.currentTurn = newCurrentTurn;
    }

    await setDoc(battleRef, dataToUpdate, { merge: true });
  }, []);

  const handleSetTokenPositions = useCallback(async (newPositions: {
    [characterId: string]: TokenPosition;
  }): Promise<void> => {
    setTokenPositions(newPositions);
    await updateBattleDataInFirestore(newPositions, currentTurn, turnOrder);
  }, [currentTurn, turnOrder, updateBattleDataInFirestore]);

  const advanceTurn = useCallback(async (): Promise<void> => {
    const charactersRef = getGameUserDataDocument('characters');

    const characterSnapshot = await getDoc(charactersRef);
    const battleSnapshot = await getDoc(getGameUserDataDocument('battle'));
    if (battleSnapshot.exists()) {
      const battleData = battleSnapshot.data();
      const updatedTokenPositions = battleData.tokenPositions as TokenPositions;

      await updateBattleDataInFirestore(updatedTokenPositions, currentTurn, turnOrder);
    }

    if (characterSnapshot.exists() && battleSnapshot.exists()) {
      let charactersData = characterSnapshot.data().characters as Character[];
      const battleData = battleSnapshot.data();

      charactersData = charactersData.map(character => {
        if (character.status.some(status => status === 'Poison')) {
          const poisonDamage = Math.ceil(character.maxHealth / 16);
          character.currentHealth = Math.max(character.currentHealth - poisonDamage, 0);

          if (!character.isDead) {
            if (character.currentHealth <= 0) {
              character.isDead = true;
              sendNotification(
                `Oh non, ${character.name} vient de terminer son dernier tour... 
                en buvant un 'shot' de poison !`, 'error'
              );
            } else {
              sendNotification(`${character.name} prend ${poisonDamage} de dégâts de poison`, 'warning');
            }
          }
        }

        return character;
      });

      await setDoc(charactersRef, { characters: charactersData }, { merge: true });

      const sortedCharacters = charactersData.sort((a, b) => b.creationDate - a.creationDate);
      const updatedTurnOrder = sortedCharacters.map(character => character.id);
      setTurnOrder(updatedTurnOrder);

      const nextTurn = currentTurn + 1;
      setCurrentTurn(nextTurn);

      const latestTokenPositions = battleData.tokenPositions as { [characterId: string]: TokenPosition };
      Object.keys(latestTokenPositions).forEach(key => {
        if (!latestTokenPositions[key].creatureName) {
          latestTokenPositions[key].hasMoved = false;
          latestTokenPositions[key].hasAttacked = false;
          latestTokenPositions[key].turnPass = false;
          latestTokenPositions[key].hasUsedItem = false;
          latestTokenPositions[key].hasUsedSpell = false;
        }
      });

      await updateBattleDataInFirestore(latestTokenPositions, nextTurn, updatedTurnOrder);
    }
  }, [currentTurn, sendNotification, turnOrder, updateBattleDataInFirestore]);

  const advanceTurnOrder = useCallback((): void => {
    setTurnOrder(prevOrder => {
      const newOrder = [...prevOrder.slice(1), prevOrder[0]];

      setTokenPositions(currentTokenPositions => {
        void updateBattleDataInFirestore(currentTokenPositions, currentTurn, newOrder);

        return currentTokenPositions;
      });

      return newOrder;
    });
  }, [currentTurn, updateBattleDataInFirestore]);

  const resetTurns = useCallback(async (): Promise<void> => {
    setCurrentTurn(1);
    const charactersRef = getGameUserDataDocument('characters');

    const characterSnapshot = await getDoc(charactersRef);

    if (characterSnapshot.exists()) {
      const charactersData = characterSnapshot.data().characters as Character[];

      const updatedCharacters = charactersData.map(character => ({
        ...character,
        status: []
      }));

      const sortedCharacters = charactersData
        .filter(character => !character.isDead)
        .sort((a, b) => b.creationDate - a.creationDate);

      await setDoc(charactersRef, { characters: updatedCharacters }, { merge: true });

      await updateBattleDataInFirestore({}, 0, sortedCharacters.map(character => character.id));
    }
  }, [updateBattleDataInFirestore]);


  const contextValue = useMemo(() => ({
    tokenPositions,
    setTokenPositions,
    handleSetTokenPositions,
    updateBattleDataInFirestore,
    currentTurn,
    advanceTurn,
    resetTurns,
    turnOrder,
    advanceTurnOrder,
    isPreBattlePlacementAllowed,
    handlePreBattlePlacementToggle,
    handleEnemiesGeneratedToggle,
    enemiesGenerated,
    setEnemiesGenerated
  }), [
    tokenPositions,
    handleSetTokenPositions,
    updateBattleDataInFirestore,
    currentTurn,
    advanceTurn,
    resetTurns,
    turnOrder,
    advanceTurnOrder,
    isPreBattlePlacementAllowed,
    handlePreBattlePlacementToggle,
    handleEnemiesGeneratedToggle,
    enemiesGenerated,
    setEnemiesGenerated
  ]);

  return (
    <BattleContext.Provider value={contextValue}>
      {children}
    </BattleContext.Provider>
  );
}

export const useBattle = (): BattleContextProps => {
  const context = useContext(BattleContext);
  if (!context) {
    throw new Error('useBattle must be used within a BattleProvider');
  }

  return context;
};

export default BattleProvider;
