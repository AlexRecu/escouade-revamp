/* eslint-disable complexity */
import { createContext, useState, useContext, useCallback, useMemo, useEffect } from 'react';
import { onSnapshot, setDoc } from 'firebase/firestore';
import { useSnackbar } from 'notistack';
import type { Character, Classes, Stats, TokenPositions } from '@interfaces/interfaces';
import type { CharacterContextProps, ProviderProps } from '@interfaces/types';
import classesData from '@data/classes_data.json';
import itemsData from '@data/items_data.json';
import { isUserAuthorizedCharacter, userId } from '@utils/auth';
import { calculateMaxHealthAndMana } from '@utils/calculs';
import { deathMessage } from '@utils/attack';

import { getGameUserDataDocument } from '../services/firestore';

import { useGameInfo } from './GameInfoContext';
import { useNotification } from './NotificationContext';
import { useBattle } from './BattleContext';
import { useInventory } from './ItemContext';

// eslint-disable-next-line @typescript-eslint/naming-convention
const CharacterContext = createContext<CharacterContextProps | undefined>(undefined);

/**
 * Provides character-related data and functionality, including character management and stats.
 * 
 * @component
 * @param {Object} param0 - The props for the CharacterProvider.
 * @param {React.ReactNode} param0.children - The child components to be wrapped by the CharacterProvider.
 * @returns {JSX.Element} The CharacterProvider component.
 */
export function CharacterProvider({ children }: ProviderProps): JSX.Element {
  const { enqueueSnackbar } = useSnackbar();
  const { sendNotification } = useNotification();
  const { inventory, unassignWeapon, addToInventory } = useInventory();
  const { updateGameInfo, gameInfo } = useGameInfo();
  const { setTokenPositions, updateBattleDataInFirestore, currentTurn, turnOrder } = useBattle();
  const [characters, setCharacters] = useState<Character[]>([]);

  useEffect(() => {
    const charactersRef = getGameUserDataDocument('characters');
    const unsubscribe = onSnapshot(charactersRef, (snapshot) => {
      if (snapshot.exists()) {
        const charactersData = snapshot.data().characters as Character[];
        setCharacters(charactersData);
      } else {
        setCharacters([]);
      }
    });

    return () => unsubscribe();
  }, []);

  const updateCharactersInFirestore = useCallback(async (newCharacters: Character[]): Promise<void> => {
    const charactersRef = getGameUserDataDocument('characters');
    await setDoc(charactersRef, { characters: newCharacters });
  }, []);

  const addCharacter = useCallback((character: Character) => {
    const classData = classesData[character.classe as keyof Classes];
    character.stats = { ...classData.defaultStats };
    character.tempStats = { ...classData.defaultStats };
    const { maxHealth, maxMana } = calculateMaxHealthAndMana(character.stats);
    character.maxHealth = maxHealth;
    character.maxMana = maxMana;
    character.currentHealth = maxHealth;
    character.currentMana = maxMana;
    character.creationDate = Date.now();
    const startItems = itemsData.filter(item => classData.item.includes(item.name));

    const startWeapons = startItems.filter(item => item.type === 'Arme').map(item => item.name);
    character.weapon = startWeapons[0] ?? '';

    const uniqueId = `${character.name}_${character.userId}`;
    setCharacters(prevCharacters => {
      const newCharacters = [...prevCharacters, { ...character, id: uniqueId }];
      void updateCharactersInFirestore(newCharacters);

      return newCharacters;
    });

    void updateGameInfo({ ...gameInfo, gold: gameInfo.gold + classData.gold });
    startItems.forEach(item => {
      addToInventory(item, character.name);
    });

    sendNotification(`${character.name} a rejoint l'aventure !`, 'success');
  }, [addToInventory, gameInfo, sendNotification, updateCharactersInFirestore, updateGameInfo]);

  const deleteCharacter = useCallback((index: number) => {
    const characterToDelete = characters[index];
    if (!isUserAuthorizedCharacter(userId(), characterToDelete.userId, enqueueSnackbar)) {
      return;
    }
    const characterToDeleteId = `${characterToDelete.name}_${characterToDelete.userId}`;

    Array.from(inventory.keys()).forEach((item) => {
      const itemData = inventory.get(item);
      if (itemData && itemData.assignedTo === characterToDelete.name) {
        unassignWeapon(item.id ?? '');
      }
    });

    setTokenPositions(prevTokenPositions => {
      const newTokenPositions = Object.keys(prevTokenPositions).reduce((acc: TokenPositions, characterId) => {
        if (characterId !== characterToDeleteId) {
          acc[characterId] = prevTokenPositions[characterId];
        }

        return acc;
      }, {} as TokenPositions);

      const newTurnOrder = turnOrder.filter(id => id !== characterToDeleteId);

      void updateBattleDataInFirestore(newTokenPositions, currentTurn, newTurnOrder);

      return newTokenPositions;
    });

    setCharacters(prevCharacters => {
      const newCharacters = prevCharacters.filter(
        character => `${character.name}_${character.userId}` !== characterToDeleteId);
      void updateCharactersInFirestore(newCharacters);

      sendNotification(`${characterToDelete.name} nous a quittés !`, 'error');

      return newCharacters;
    });
  }, [
    characters,
    enqueueSnackbar,
    inventory,
    setTokenPositions,
    sendNotification,
    unassignWeapon,
    updateBattleDataInFirestore,
    currentTurn,
    turnOrder,
    updateCharactersInFirestore
  ]);

  const updateCharacter = useCallback(
    (index: number,
      field: string,
      value: string | number | boolean | string[] | Stats,
      attackName?: string,
      status?: string) => {
      const character = characters[index];

      if (!isUserAuthorizedCharacter(userId(), character.userId, enqueueSnackbar)) {
        return;
      }

      setCharacters(prevCharacters => {
        const updatedCharacters = [...prevCharacters];
        const updatedCharacter = { ...updatedCharacters[index] };

        if (field === 'classe') {
          const classData = classesData[value as keyof Classes];
          updatedCharacter.classe = value as keyof Classes;
          updatedCharacter.stats = { ...classData.defaultStats };
          updatedCharacter.tempStats = { ...classData.defaultStats };
          const { maxHealth, maxMana } = calculateMaxHealthAndMana(updatedCharacter.stats);
          updatedCharacter.maxHealth = maxHealth;
          updatedCharacter.maxMana = maxMana;
          updatedCharacter.currentHealth = maxHealth;
          updatedCharacter.currentMana = maxMana;
          inventory.forEach((inventoryItem, key) => {
            if (inventoryItem.assignedTo === updatedCharacter.name) {
              unassignWeapon(key.id ?? '');
            }
          });
        } else if (field === 'weapons') {
          updatedCharacter.weapon = value as string;
        } else if (field === 'endurance') {
          const newValue = 10 + Number(value);
          const healthDifference = newValue - updatedCharacter.maxHealth;
          updatedCharacter.maxHealth = newValue;
          updatedCharacter.currentHealth =
            Math.min(updatedCharacter.currentHealth + healthDifference, updatedCharacter.maxHealth);
          updatedCharacter.stats.endurance = Number(value);
          updatedCharacter.tempStats.endurance = Number(value);
        } else if (field === 'currentMana') {
          const newMana = Math.max(0, value as number);
          updatedCharacter.currentMana = newMana;
        } else if (field === 'isCommitted') {
          updatedCharacter.isCommitted = value as boolean;
        } else if (field === 'currentHealth') {
          const newHealth = Math.max(0, value as number);
          updatedCharacter.currentHealth = newHealth;
          if (newHealth <= 0 && attackName) {
            if (status !== 'Mort') {
              sendNotification(deathMessage(attackName, updatedCharacter.name), 'error');
            }
            updatedCharacter.isDead = true;
          }
        } else if (field === 'status') {
          updatedCharacter.status = value as string[];
        } else if (field === 'isDead') {
          updatedCharacter.isDead = false;
          updatedCharacter.currentHealth = Math.floor(updatedCharacter.maxHealth / 2);
          updatedCharacter.currentMana = Math.floor(updatedCharacter.maxMana / 2);
        } else {
          const newValue = parseInt(value as string);
          if (newValue <= 10 && newValue >= 0) {
            updatedCharacter.stats = { ...updatedCharacter.stats, [field]: newValue };
            updatedCharacter.tempStats = { ...updatedCharacter.tempStats, [field]: newValue };
            const { maxHealth, maxMana } = calculateMaxHealthAndMana(updatedCharacter.stats);
            updatedCharacter.maxHealth = maxHealth;
            updatedCharacter.maxMana = maxMana;
            updatedCharacter.currentHealth = maxHealth;
            updatedCharacter.currentMana = maxMana;
          }
        }

        updatedCharacters[index] = updatedCharacter;
        void updateCharactersInFirestore(updatedCharacters);

        return updatedCharacters;
      });
    }, [characters, enqueueSnackbar, inventory, sendNotification, unassignWeapon, updateCharactersInFirestore]);

  const updateCurrentHealth = useCallback((index: number, newHealth: number) => {
    setCharacters(prevCharacters => {
      const updatedCharacters = [...prevCharacters];
      if (!isUserAuthorizedCharacter(userId(), updatedCharacters[index].userId, enqueueSnackbar)) {
        return prevCharacters;
      }
      const updatedCharacter = { ...updatedCharacters[index] };

      updatedCharacter.currentHealth = Math.min(newHealth, updatedCharacter.maxHealth);

      updatedCharacters[index] = updatedCharacter;
      void updateCharactersInFirestore(updatedCharacters);

      return updatedCharacters;
    });
  }, [enqueueSnackbar, updateCharactersInFirestore]);

  const updateCurrentMana = useCallback((index: number, newMana: number) => {
    setCharacters(prevCharacters => {
      const updatedCharacters = [...prevCharacters];
      if (!isUserAuthorizedCharacter(userId(), updatedCharacters[index].userId, enqueueSnackbar)) {
        return prevCharacters;
      }
      const updatedCharacter = { ...updatedCharacters[index] };

      updatedCharacter.currentMana = Math.min(newMana, updatedCharacter.maxMana);

      updatedCharacters[index] = updatedCharacter;
      void updateCharactersInFirestore(updatedCharacters);

      return updatedCharacters;
    });
  }, [enqueueSnackbar, updateCharactersInFirestore]);

  const setCharactersFromImport = useCallback((importedCharacters: Character[]) => {
    setCharacters(importedCharacters);
  }, []);

  const contextValue = useMemo(() => ({
    characters,
    addCharacter,
    deleteCharacter,
    updateCharacter,
    setCharactersFromImport,
    updateCurrentHealth,
    updateCurrentMana
  }), [
    addCharacter,
    characters,
    deleteCharacter,
    setCharactersFromImport,
    updateCharacter,
    updateCurrentHealth,
    updateCurrentMana
  ]);

  return (
    <CharacterContext.Provider value={contextValue}>
      {children}
    </CharacterContext.Provider>
  );
}

/**
 * Custom hook for accessing character-related data and functionality.
 * 
 * @returns {CharacterContextProps} The character context with character-related functions and state.
 */
export const useCharacters = (): CharacterContextProps => {
  const context = useContext(CharacterContext);
  if (context === undefined) {
    throw new Error('useCharacters must be used within a CharacterProvider');
  }

  return context;
};