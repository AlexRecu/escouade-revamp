import { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { getStorage, ref as storageRef, listAll, getDownloadURL, uploadBytes, deleteObject } from 'firebase/storage';
import type { MapImageContextProps, ProviderProps } from '@interfaces/types';
import type { MapImage } from '@interfaces/interfaces';

// eslint-disable-next-line @typescript-eslint/naming-convention
export const MapImageContext = createContext<MapImageContextProps | undefined>(undefined);

/**
 * Provides functionality for managing map images, including uploading and deleting map images.
 * 
 * @component
 * @param {Object} param0 - The props for the MapImageProvider.
 * @param {React.ReactNode} param0.children - The child components to be wrapped by the MapImageProvider.
 * @returns {JSX.Element} The MapImageProvider component.
 */
export function MapImageProvider({ children }: ProviderProps): JSX.Element {
  const [imageList, setImageList] = useState<MapImage[]>([]);

  useEffect(() => {
    const fetchMapImages = async (): Promise<void> => {
      const storage = getStorage();
      const mapFolderRef = storageRef(storage, 'map');

      const result = await listAll(mapFolderRef);
      const files: MapImage[] = await Promise.all(
        result.items.map(async itemRef => {
          const url = await getDownloadURL(itemRef);

          return { name: itemRef.name, url };
        })
      );
      setImageList(files);
    };

    void fetchMapImages();
  }, []);

  const uploadMap = useCallback(async (file: File) => {
    const storage = getStorage();
    const imageRef = storageRef(storage, `map/${file.name}`);

    await uploadBytes(imageRef, file);
    const url = await getDownloadURL(imageRef);
    setImageList(prev => [...prev, { name: file.name, url }]);
  }, []);

  const deleteMap = useCallback(async (imageName: string) => {
    const storage = getStorage();
    const imageRef = storageRef(storage, `map/${imageName}`);

    await deleteObject(imageRef);

    setImageList(prev => prev.filter(image => image.name !== imageName));
  }, []);

  const contextValue = useMemo(() => ({ imageList, uploadMap, deleteMap }), [imageList, uploadMap, deleteMap]);

  return (
    <MapImageContext.Provider value={contextValue}>
      {children}
    </MapImageContext.Provider>
  );
}

/**
 * Custom hook for accessing map image management functionality.
 * 
 * @returns {MapImageContextProps} The map image context with map image-related functions and state.
 */
export const useMapImages = (): MapImageContextProps => {
  const context = useContext(MapImageContext);
  if (context === undefined) {
    throw new Error('useMapImages must be used within a MapImageProvider');
  }

  return context;
};
