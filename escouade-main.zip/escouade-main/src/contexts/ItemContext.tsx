import { createContext, useState, useContext, useCallback, useMemo, useEffect } from 'react';
import { onSnapshot, setDoc } from 'firebase/firestore';
import type { Item, ItemData } from '@interfaces/interfaces';
import type { FirestoreItem, ItemContextProps, ProviderProps } from '@interfaces/types';

import { getGameUserDataDocument } from '../services/firestore';

// eslint-disable-next-line @typescript-eslint/naming-convention
const ItemContext = createContext<ItemContextProps | undefined>(undefined);

/**
 * Provides functionality for managing the player's inventory, including items and weapons.
 * 
 * @component
 * @param {Object} param0 - The props for the ItemProvider.
 * @param {React.ReactNode} param0.children - The child components to be wrapped by the ItemProvider.
 * @returns {JSX.Element} The ItemProvider component.
 */
export function ItemProvider({ children }: ProviderProps): JSX.Element {
  const [inventory, setInventory] = useState<Map<Item, ItemData>>(new Map());

  useEffect(() => {
    const inventoryRef = getGameUserDataDocument('inventory');
    const unsubscribe = onSnapshot(inventoryRef, (snapshot) => {
      if (snapshot.exists()) {
        const items = snapshot.data().items as Array<FirestoreItem>;
        const inventoryData = new Map<Item, ItemData>();
        items.forEach(itemWithItemData => {
          const { itemData, ...itemProps } = itemWithItemData;
          const item = itemProps as Item;
          inventoryData.set(item, itemData);
        });
        setInventory(inventoryData);
      } else {
        setInventory(new Map());
      }
    });

    return () => unsubscribe();
  }, []);

  const updateInventoryInFirestore = useCallback(async (newInventory: Map<Item, ItemData>): Promise<void> => {
    const inventoryRef = getGameUserDataDocument('inventory');
    const itemsArray = Array.from(newInventory).map(([item, itemData]) => {
      const cleanedItemData = { ...itemData };
      Object.keys(cleanedItemData).forEach(key => {
        const value = cleanedItemData[key as keyof typeof cleanedItemData];
        if (value === undefined) {
          delete cleanedItemData[key as keyof typeof cleanedItemData];
        }
      });

      return {
        ...item,
        itemData: cleanedItemData,
      };
    });

    await setDoc(inventoryRef, { items: itemsArray });
  }, []);

  const addToInventory = useCallback((item: Item, characterName: string | undefined) => {
    setInventory(prevInventory => {
      const newInventory = new Map(prevInventory);
      if (item.type !== 'Arme') {
        const existingItem = Array.from(newInventory.keys()).find(existingItem => (
          existingItem.name === item.name
        ));

        if (existingItem) {
          const existingData = newInventory.get(existingItem) || { count: 0 };
          newInventory.set(existingItem, { ...existingData, count: existingData.count + 1 });
        } else {
          newInventory.set(item, { count: 1 });
        }
      } else {
        const newId = new Date().toISOString();
        if (characterName) {
          newInventory.set({ ...item, id: newId }, { assignedTo: characterName, count: 1 });
        } else {
          newInventory.set({ ...item, id: newId }, { count: 1 });
        }
      }
      void updateInventoryInFirestore(newInventory);

      return newInventory;
    });
  }, [updateInventoryInFirestore]);

  const removeFromInventory = useCallback((item: Item) => {
    setInventory(prevInventory => {
      const newInventory = new Map(prevInventory);
  
      let existingItem;
      if (item.type === 'Arme') {
        existingItem = Array.from(newInventory.keys()).find(existingItem => existingItem.id === item.id);
      } else {
        existingItem = Array.from(newInventory.keys()).find(existingItem => existingItem.name === item.name);
      }
  
      if (existingItem) {
        const existingData = newInventory.get(existingItem) || { count: 0 };
        const newCount = existingData.count - 1;
        if (newCount > 0) {
          newInventory.set(existingItem, { ...existingData, count: newCount });
        } else {
          newInventory.delete(existingItem);
        }
      }
  
      void updateInventoryInFirestore(newInventory);
  
      return newInventory;
    });
  }, [updateInventoryInFirestore]);

  const assignWeaponToCharacter = useCallback((weaponId: string, characterName: string) => {
    setInventory(prevInventory => {
      const newInventory = new Map(prevInventory);
      const item = Array.from(newInventory.keys()).find(item => item.id === weaponId);

      if (item) {
        const existingData = newInventory.get(item) || { count: 0 };
        newInventory.set(item, { ...existingData, assignedTo: characterName });
        void updateInventoryInFirestore(newInventory);
      }

      return newInventory;
    });
  }, [updateInventoryInFirestore]);

  const unassignWeapon = useCallback((weaponId: string) => {
    setInventory(prevInventory => {
      const newInventory = new Map(prevInventory);
      const item = Array.from(newInventory.keys()).find(item => item.id === weaponId);

      if (item) {
        const existingData = newInventory.get(item) || { count: 0 };
        newInventory.set(item, { ...existingData, assignedTo: undefined });
        void updateInventoryInFirestore(newInventory);
      }

      return newInventory;
    });
  }, [updateInventoryInFirestore]);

  const setInventoryFromImport = useCallback((importedInventory: Map<Item, ItemData>) => {
    setInventory(importedInventory);
  }, []);

  const filterItems = useCallback((items: Item[], searchTerm: string): Item[] => {
    const searchTermLower = searchTerm.toLowerCase();

    return items.filter(item => {
      const nameMatches = item.name.toLowerCase().includes(searchTermLower);
      const typeMatches = item.type && item.type.toLowerCase().includes(searchTermLower);
      const effectMatches = item.effect && item.effect.toLowerCase().includes(searchTermLower);

      return nameMatches || typeMatches || effectMatches;
    });
  }, []);

  const contextValue = useMemo(() => ({
    inventory,
    addToInventory,
    removeFromInventory,
    assignWeaponToCharacter,
    unassignWeapon,
    setInventoryFromImport,
    filterItems
  }), [
    inventory,
    addToInventory,
    removeFromInventory,
    assignWeaponToCharacter,
    unassignWeapon,
    setInventoryFromImport,
    filterItems
  ]);

  return (
    <ItemContext.Provider value={contextValue}>
      {children}
    </ItemContext.Provider>
  );
}

/**
 * Custom hook for accessing inventory management functionality.
 * 
 * @returns {ItemContextProps} The inventory context with inventory-related functions and state.
 */
export const useInventory = (): ItemContextProps => {
  const context = useContext(ItemContext);
  if (context === undefined) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }

  return context;
};