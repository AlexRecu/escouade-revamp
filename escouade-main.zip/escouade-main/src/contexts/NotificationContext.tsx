import { createContext, useContext, useCallback, useMemo, useEffect } from 'react';
import { collection, onSnapshot, addDoc, query, orderBy, limit } from 'firebase/firestore';
import { useSnackbar } from 'notistack';
import type { Notification } from '@interfaces/interfaces';
import type { NotificationContextProps, ProviderProps } from '@interfaces/types';

import { db } from '../services/firestore';

// eslint-disable-next-line @typescript-eslint/naming-convention
const NotificationContext = createContext<NotificationContextProps | undefined>(undefined);

/**
 * Provides functionality for sending and displaying notifications.
 * 
 * @component
 * @param {Object} param0 - The props for the NotificationProvider.
 * @param {React.ReactNode} param0.children - The child components to be wrapped by the NotificationProvider.
 * @returns {JSX.Element} The NotificationProvider component.
 */
export function NotificationProvider({ children }: ProviderProps): JSX.Element {
  const { enqueueSnackbar } = useSnackbar();

  const sendNotification = useCallback(async (message: string, variant: Notification['variant']) => {
    const now = new Date();
    await addDoc(collection(db, 'notifications'), {
      message,
      variant,
      timestamp: now.getTime()
    });
  }, []);

  useEffect(() => {
    const notificationsQuery = query(
      collection(db, 'notifications'),
      orderBy('timestamp', 'desc'),
      limit(1)
    );

    const unsubscribe = onSnapshot(notificationsQuery, (snapshot) => {
      if (!snapshot.empty) {
        const doc = snapshot.docs[0];
        const notification = doc.data() as Notification;
        const currentTime = new Date().getTime();
        if (currentTime - notification.timestamp <= 1000) {
          enqueueSnackbar(notification.message, {
            variant: notification.variant, anchorOrigin: {
              vertical: notification.anchorOrigin?.vertical || 'top',
              horizontal: notification.anchorOrigin?.horizontal || 'left'
            }
          });
        }
      }
    });

    return () => unsubscribe();
  }, [enqueueSnackbar]);

  const contextValue = useMemo(() => ({
    sendNotification
  }), [sendNotification]);

  return (
    <NotificationContext.Provider value={contextValue}>
      {children}
    </NotificationContext.Provider>
  );
}

/**
 * Custom hook for sending notifications and accessing notification functionality.
 * 
 * @returns {NotificationContextProps} The notification context with notification-related functions.
 */
export const useNotification = (): NotificationContextProps => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }

  return context;
};