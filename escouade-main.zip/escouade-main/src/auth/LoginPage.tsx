import { useState } from 'react';
import { getAuth, sendPasswordResetEmail, signInWithEmailAndPassword } from 'firebase/auth';
import { Button, TextField, Box, Typography, Link, Stack } from '@mui/material';
import { useSnackbar } from 'notistack';

import app from '../services/firebase';

/**
 * Renders a login component for user authentication.
 *
 * @returns {JSX.Element} The login component.
 */
function LoginComponent(): JSX.Element {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { enqueueSnackbar } = useSnackbar();

  const auth = getAuth(app);

  const handleLogin = async (event: React.FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();

    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      let errorMessage = 'Une erreur inconnue est survenue.';
      if (error instanceof Error) {
        if (error.message.includes('user-not-found')) {
          errorMessage = 'Aucun utilisateur trouvé avec cet email.';
        } else if (error.message.includes('wrong-password')) {
          errorMessage = 'Mot de passe incorrect.';
        } else {
          errorMessage = error.message;
        }
      }
      enqueueSnackbar(errorMessage, { variant: 'error' });
    }
  };

  const handlePasswordReset = async (): Promise<void> => {
    if (!email) {
      enqueueSnackbar('Veuillez entrer votre email pour réinitialiser le mot de passe.', { variant: 'warning' });

      return;
    }

    try {
      await sendPasswordResetEmail(auth, email);
      enqueueSnackbar('Un lien de réinitialisation a été envoyé à votre adresse email.', { variant: 'success' });
    } catch (error) {
      if (error instanceof Error) {
        enqueueSnackbar(error.message, { variant: 'error' });
      }
    }
  };

  return (
    <Box sx={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      background: 'url(\'./assets/login/friends.png\') no-repeat center center fixed',
      backgroundSize: 'cover',
      zIndex: -1
    }}>
      <Box sx={{
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        width: '100%',
        height: '100%',
        position: 'absolute',
        top: 0,
        left: 0
      }} />
      <Box sx={{
        width: 300,
        margin: 'auto',
        mt: 10,
        position: 'relative',
        zIndex: 2
      }}>
        <Typography variant="h4" textAlign={'center'} sx={{ mb: 2 }}>
          L'escouade
        </Typography>

        <form onSubmit={handleLogin}>
          <TextField
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Mot de passe"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            fullWidth
            margin="normal"
            variant="outlined"
          />
          <Stack direction={'row'} justifyContent={'space-around'} alignItems={'center'} mt={2}>
            <Button type="submit" variant="contained" color="primary">
              Se Connecter
            </Button>
            <Link href="#" onClick={handlePasswordReset} variant="body2">
              Mot de passe oublié ?
            </Link>
          </Stack>
        </form>
      </Box>
    </Box>
  );
}

export default LoginComponent;